﻿namespace Facturador
{
    partial class bMarcas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(bMarcas));
            this.label11 = new System.Windows.Forms.Label();
            this.tbClave = new System.Windows.Forms.TextBox();
            this.button4 = new System.Windows.Forms.Button();
            this.cbPais = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.tbCasoid = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.tbDenominacion = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.tbreferencia = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.tbPrioridad = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.tbCliente = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tbInteresado = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tbregistro = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tbexpediente = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxCasonumero = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.cbTiposolicitud = new System.Windows.Forms.ComboBox();
            this.cbClase = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lbFiltroestatus = new System.Windows.Forms.Label();
            this.cbFiltroestatus = new System.Windows.Forms.ComboBox();
            this.button2 = new System.Windows.Forms.Button();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.tbLimitcasos = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.cbHolder = new System.Windows.Forms.ComboBox();
            this.tbAvisoprueba = new System.Windows.Forms.TextBox();
            this.dgvBuscamarca = new System.Windows.Forms.DataGridView();
            this.button25 = new System.Windows.Forms.Button();
            this.cbLogo = new System.Windows.Forms.CheckBox();
            this.bmPais = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bmClase = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bmCasoid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bmcaso = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bmTipo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tipomarcadescrip = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.leydescrip = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bmEstatus = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bmFechapresentacion = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bmExpediente = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bmFechaconcesion = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.declaestricta = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vigencia = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.renova = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bmRegistro = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bmInteresado = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Titulonombremarca = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Imagecolumn = new System.Windows.Forms.DataGridViewImageColumn();
            this.bmcliente = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bmprioridades = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bmReferencia = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bmHolder = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBuscamarca)).BeginInit();
            this.SuspendLayout();
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(440, 211);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(34, 13);
            this.label11.TabIndex = 57;
            this.label11.Text = "Clave";
            // 
            // tbClave
            // 
            this.tbClave.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbClave.Location = new System.Drawing.Point(480, 207);
            this.tbClave.Name = "tbClave";
            this.tbClave.Size = new System.Drawing.Size(46, 20);
            this.tbClave.TabIndex = 56;
            this.tbClave.TextChanged += new System.EventHandler(this.tbClave_TextChanged);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(12, 12);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 53;
            this.button4.Text = "Menu";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // cbPais
            // 
            this.cbPais.FormattingEnabled = true;
            this.cbPais.Location = new System.Drawing.Point(69, 205);
            this.cbPais.Name = "cbPais";
            this.cbPais.Size = new System.Drawing.Size(357, 21);
            this.cbPais.TabIndex = 52;
            this.cbPais.SelectedIndexChanged += new System.EventHandler(this.cbPais_SelectedIndexChanged);
            this.cbPais.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxCasonumero_KeyDown);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(34, 211);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(29, 13);
            this.label10.TabIndex = 51;
            this.label10.Text = "País";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(989, 70);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 50;
            this.button3.Text = "wp";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(989, 43);
            this.textBox10.Name = "textBox10";
            this.textBox10.ReadOnly = true;
            this.textBox10.Size = new System.Drawing.Size(75, 20);
            this.textBox10.TabIndex = 49;
            this.textBox10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(989, 14);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 47;
            this.button1.Text = "Consulta";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // tbCasoid
            // 
            this.tbCasoid.Location = new System.Drawing.Point(264, 174);
            this.tbCasoid.Name = "tbCasoid";
            this.tbCasoid.Size = new System.Drawing.Size(162, 20);
            this.tbCasoid.TabIndex = 46;
            this.tbCasoid.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxCasonumero_KeyDown);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(196, 181);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(40, 13);
            this.label9.TabIndex = 45;
            this.label9.Text = "CasoId";
            // 
            // tbDenominacion
            // 
            this.tbDenominacion.Location = new System.Drawing.Point(264, 112);
            this.tbDenominacion.Name = "tbDenominacion";
            this.tbDenominacion.Size = new System.Drawing.Size(162, 20);
            this.tbDenominacion.TabIndex = 44;
            this.tbDenominacion.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxCasonumero_KeyDown);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(139, 115);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(104, 13);
            this.label8.TabIndex = 43;
            this.label8.Text = "Denominación Titulo";
            // 
            // tbreferencia
            // 
            this.tbreferencia.Location = new System.Drawing.Point(758, 44);
            this.tbreferencia.Name = "tbreferencia";
            this.tbreferencia.Size = new System.Drawing.Size(162, 20);
            this.tbreferencia.TabIndex = 42;
            this.tbreferencia.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxCasonumero_KeyDown);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(672, 43);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(59, 13);
            this.label7.TabIndex = 41;
            this.label7.Text = "Referencia";
            // 
            // tbPrioridad
            // 
            this.tbPrioridad.Location = new System.Drawing.Point(758, 103);
            this.tbPrioridad.Name = "tbPrioridad";
            this.tbPrioridad.Size = new System.Drawing.Size(162, 20);
            this.tbPrioridad.TabIndex = 40;
            this.tbPrioridad.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxCasonumero_KeyDown);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(680, 106);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(51, 13);
            this.label6.TabIndex = 39;
            this.label6.Text = "Prioridad ";
            // 
            // tbCliente
            // 
            this.tbCliente.Location = new System.Drawing.Point(758, 13);
            this.tbCliente.Name = "tbCliente";
            this.tbCliente.Size = new System.Drawing.Size(162, 20);
            this.tbCliente.TabIndex = 38;
            this.tbCliente.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxCasonumero_KeyDown);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(692, 16);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(39, 13);
            this.label5.TabIndex = 37;
            this.label5.Text = "Cliente";
            // 
            // tbInteresado
            // 
            this.tbInteresado.Location = new System.Drawing.Point(758, 75);
            this.tbInteresado.Name = "tbInteresado";
            this.tbInteresado.Size = new System.Drawing.Size(162, 20);
            this.tbInteresado.TabIndex = 36;
            this.tbInteresado.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxCasonumero_KeyDown);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(672, 75);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 13);
            this.label4.TabIndex = 35;
            this.label4.Text = "Interesado";
            // 
            // tbregistro
            // 
            this.tbregistro.Location = new System.Drawing.Point(264, 144);
            this.tbregistro.Name = "tbregistro";
            this.tbregistro.Size = new System.Drawing.Size(162, 20);
            this.tbregistro.TabIndex = 34;
            this.tbregistro.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxCasonumero_KeyDown);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(190, 152);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(46, 13);
            this.label3.TabIndex = 33;
            this.label3.Text = "Registro";
            // 
            // tbexpediente
            // 
            this.tbexpediente.Location = new System.Drawing.Point(264, 81);
            this.tbexpediente.Name = "tbexpediente";
            this.tbexpediente.Size = new System.Drawing.Size(162, 20);
            this.tbexpediente.TabIndex = 32;
            this.tbexpediente.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxCasonumero_KeyDown);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(183, 79);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 13);
            this.label2.TabIndex = 31;
            this.label2.Text = "Expediente";
            // 
            // textBoxCasonumero
            // 
            this.textBoxCasonumero.Location = new System.Drawing.Point(264, 51);
            this.textBoxCasonumero.Name = "textBoxCasonumero";
            this.textBoxCasonumero.Size = new System.Drawing.Size(162, 20);
            this.textBoxCasonumero.TabIndex = 0;
            this.textBoxCasonumero.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxCasonumero_KeyDown);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(212, 54);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(31, 13);
            this.label1.TabIndex = 29;
            this.label1.Text = "Caso";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(164, 24);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(86, 13);
            this.label13.TabIndex = 61;
            this.label13.Text = "Tipo de Solicitud";
            // 
            // cbTiposolicitud
            // 
            this.cbTiposolicitud.FormattingEnabled = true;
            this.cbTiposolicitud.Location = new System.Drawing.Point(264, 20);
            this.cbTiposolicitud.Name = "cbTiposolicitud";
            this.cbTiposolicitud.Size = new System.Drawing.Size(162, 21);
            this.cbTiposolicitud.TabIndex = 62;
            this.cbTiposolicitud.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxCasonumero_KeyDown);
            // 
            // cbClase
            // 
            this.cbClase.FormattingEnabled = true;
            this.cbClase.Location = new System.Drawing.Point(758, 165);
            this.cbClase.Name = "cbClase";
            this.cbClase.Size = new System.Drawing.Size(162, 21);
            this.cbClase.TabIndex = 63;
            this.cbClase.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxCasonumero_KeyDown);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(698, 170);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(33, 13);
            this.label14.TabIndex = 64;
            this.label14.Text = "Clase";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Snow;
            this.groupBox1.Controls.Add(this.lbFiltroestatus);
            this.groupBox1.Controls.Add(this.cbFiltroestatus);
            this.groupBox1.Controls.Add(this.button2);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.tbLimitcasos);
            this.groupBox1.Location = new System.Drawing.Point(632, 202);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(448, 82);
            this.groupBox1.TabIndex = 172;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Consultar últimos casos";
            // 
            // lbFiltroestatus
            // 
            this.lbFiltroestatus.AutoSize = true;
            this.lbFiltroestatus.Location = new System.Drawing.Point(38, 47);
            this.lbFiltroestatus.Name = "lbFiltroestatus";
            this.lbFiltroestatus.Size = new System.Drawing.Size(85, 13);
            this.lbFiltroestatus.TabIndex = 174;
            this.lbFiltroestatus.Text = "Estatus Solicitud";
            // 
            // cbFiltroestatus
            // 
            this.cbFiltroestatus.FormattingEnabled = true;
            this.cbFiltroestatus.Location = new System.Drawing.Point(134, 44);
            this.cbFiltroestatus.Name = "cbFiltroestatus";
            this.cbFiltroestatus.Size = new System.Drawing.Size(180, 21);
            this.cbFiltroestatus.TabIndex = 173;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(341, 15);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 170;
            this.button2.Text = "Consulta";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(131, 21);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(102, 13);
            this.label15.TabIndex = 167;
            this.label15.Text = "Consultar los últimos";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(281, 21);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(36, 13);
            this.label16.TabIndex = 169;
            this.label16.Text = "Casos";
            // 
            // tbLimitcasos
            // 
            this.tbLimitcasos.Location = new System.Drawing.Point(239, 18);
            this.tbLimitcasos.MaxLength = 4;
            this.tbLimitcasos.Name = "tbLimitcasos";
            this.tbLimitcasos.Size = new System.Drawing.Size(36, 20);
            this.tbLimitcasos.TabIndex = 168;
            this.tbLimitcasos.Text = "10";
            this.tbLimitcasos.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbLimitcasos.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tbLimitcasos_KeyDown);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(690, 137);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(38, 13);
            this.label17.TabIndex = 174;
            this.label17.Text = "Holder";
            // 
            // cbHolder
            // 
            this.cbHolder.FormattingEnabled = true;
            this.cbHolder.Location = new System.Drawing.Point(758, 134);
            this.cbHolder.Name = "cbHolder";
            this.cbHolder.Size = new System.Drawing.Size(162, 21);
            this.cbHolder.TabIndex = 173;
            this.cbHolder.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cbHolder_KeyDown);
            // 
            // tbAvisoprueba
            // 
            this.tbAvisoprueba.BackColor = System.Drawing.Color.Red;
            this.tbAvisoprueba.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbAvisoprueba.Location = new System.Drawing.Point(971, 115);
            this.tbAvisoprueba.Name = "tbAvisoprueba";
            this.tbAvisoprueba.ReadOnly = true;
            this.tbAvisoprueba.Size = new System.Drawing.Size(100, 21);
            this.tbAvisoprueba.TabIndex = 175;
            this.tbAvisoprueba.Text = "Prueba";
            this.tbAvisoprueba.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // dgvBuscamarca
            // 
            this.dgvBuscamarca.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvBuscamarca.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.bmPais,
            this.bmClase,
            this.bmCasoid,
            this.bmcaso,
            this.bmTipo,
            this.tipomarcadescrip,
            this.leydescrip,
            this.bmEstatus,
            this.bmFechapresentacion,
            this.bmExpediente,
            this.bmFechaconcesion,
            this.declaestricta,
            this.vigencia,
            this.renova,
            this.bmRegistro,
            this.bmInteresado,
            this.Titulonombremarca,
            this.Imagecolumn,
            this.bmcliente,
            this.bmprioridades,
            this.bmReferencia,
            this.bmHolder});
            this.dgvBuscamarca.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dgvBuscamarca.Location = new System.Drawing.Point(0, 290);
            this.dgvBuscamarca.Name = "dgvBuscamarca";
            this.dgvBuscamarca.RowTemplate.Height = 90;
            this.dgvBuscamarca.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvBuscamarca.Size = new System.Drawing.Size(1398, 377);
            this.dgvBuscamarca.TabIndex = 176;
            this.dgvBuscamarca.DataError += new System.Windows.Forms.DataGridViewDataErrorEventHandler(this.dgvBuscamarca_DataError);
            this.dgvBuscamarca.DoubleClick += new System.EventHandler(this.dgvBuscamarca_DoubleClick);
            // 
            // button25
            // 
            this.button25.BackgroundImage = global::Facturador.Properties.Resources.descarga;
            this.button25.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button25.Location = new System.Drawing.Point(1013, 142);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(33, 33);
            this.button25.TabIndex = 177;
            this.button25.UseVisualStyleBackColor = true;
            this.button25.Click += new System.EventHandler(this.button25_Click);
            // 
            // cbLogo
            // 
            this.cbLogo.AutoSize = true;
            this.cbLogo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbLogo.Location = new System.Drawing.Point(264, 249);
            this.cbLogo.Name = "cbLogo";
            this.cbLogo.Size = new System.Drawing.Size(99, 20);
            this.cbLogo.TabIndex = 178;
            this.cbLogo.Text = "Con imagen";
            this.cbLogo.UseVisualStyleBackColor = true;
            // 
            // bmPais
            // 
            this.bmPais.HeaderText = "País";
            this.bmPais.Name = "bmPais";
            this.bmPais.Width = 54;
            // 
            // bmClase
            // 
            this.bmClase.HeaderText = "Clase";
            this.bmClase.Name = "bmClase";
            this.bmClase.Width = 58;
            // 
            // bmCasoid
            // 
            this.bmCasoid.HeaderText = "Casoid";
            this.bmCasoid.Name = "bmCasoid";
            this.bmCasoid.Width = 64;
            // 
            // bmcaso
            // 
            this.bmcaso.HeaderText = "Caso";
            this.bmcaso.Name = "bmcaso";
            this.bmcaso.Width = 56;
            // 
            // bmTipo
            // 
            this.bmTipo.HeaderText = "Tipo";
            this.bmTipo.Name = "bmTipo";
            this.bmTipo.Width = 53;
            // 
            // tipomarcadescrip
            // 
            this.tipomarcadescrip.HeaderText = "Tipo Marca";
            this.tipomarcadescrip.Name = "tipomarcadescrip";
            this.tipomarcadescrip.Width = 79;
            // 
            // leydescrip
            // 
            this.leydescrip.HeaderText = "Ley";
            this.leydescrip.Name = "leydescrip";
            // 
            // bmEstatus
            // 
            this.bmEstatus.HeaderText = "Estatus";
            this.bmEstatus.Name = "bmEstatus";
            this.bmEstatus.Width = 67;
            // 
            // bmFechapresentacion
            // 
            dataGridViewCellStyle1.Format = "d";
            dataGridViewCellStyle1.NullValue = null;
            this.bmFechapresentacion.DefaultCellStyle = dataGridViewCellStyle1;
            this.bmFechapresentacion.HeaderText = "Fecha Presentación";
            this.bmFechapresentacion.Name = "bmFechapresentacion";
            this.bmFechapresentacion.Width = 116;
            // 
            // bmExpediente
            // 
            this.bmExpediente.HeaderText = "Expediente";
            this.bmExpediente.Name = "bmExpediente";
            this.bmExpediente.Width = 85;
            // 
            // bmFechaconcesion
            // 
            dataGridViewCellStyle2.Format = "d";
            dataGridViewCellStyle2.NullValue = null;
            this.bmFechaconcesion.DefaultCellStyle = dataGridViewCellStyle2;
            this.bmFechaconcesion.HeaderText = "Fecha Concesión";
            this.bmFechaconcesion.Name = "bmFechaconcesion";
            this.bmFechaconcesion.Width = 105;
            // 
            // declaestricta
            // 
            dataGridViewCellStyle3.Format = "d";
            dataGridViewCellStyle3.NullValue = null;
            this.declaestricta.DefaultCellStyle = dataGridViewCellStyle3;
            this.declaestricta.HeaderText = "Decla Estricta";
            this.declaestricta.Name = "declaestricta";
            // 
            // vigencia
            // 
            dataGridViewCellStyle4.Format = "d";
            dataGridViewCellStyle4.NullValue = null;
            this.vigencia.DefaultCellStyle = dataGridViewCellStyle4;
            this.vigencia.HeaderText = "Vigencia";
            this.vigencia.Name = "vigencia";
            // 
            // renova
            // 
            dataGridViewCellStyle5.Format = "d";
            dataGridViewCellStyle5.NullValue = null;
            this.renova.DefaultCellStyle = dataGridViewCellStyle5;
            this.renova.HeaderText = "Renova";
            this.renova.Name = "renova";
            // 
            // bmRegistro
            // 
            this.bmRegistro.HeaderText = "Registro";
            this.bmRegistro.Name = "bmRegistro";
            this.bmRegistro.Width = 71;
            // 
            // bmInteresado
            // 
            this.bmInteresado.HeaderText = "Interesado";
            this.bmInteresado.Name = "bmInteresado";
            this.bmInteresado.Width = 82;
            // 
            // Titulonombremarca
            // 
            this.Titulonombremarca.HeaderText = "Marca";
            this.Titulonombremarca.Name = "Titulonombremarca";
            this.Titulonombremarca.Width = 62;
            // 
            // Imagecolumn
            // 
            this.Imagecolumn.HeaderText = "Marca(imagen)";
            this.Imagecolumn.ImageLayout = System.Windows.Forms.DataGridViewImageCellLayout.Stretch;
            this.Imagecolumn.Name = "Imagecolumn";
            this.Imagecolumn.Visible = false;
            // 
            // bmcliente
            // 
            this.bmcliente.HeaderText = "Cliente";
            this.bmcliente.Name = "bmcliente";
            this.bmcliente.Width = 64;
            // 
            // bmprioridades
            // 
            this.bmprioridades.HeaderText = "Prioridad";
            this.bmprioridades.Name = "bmprioridades";
            this.bmprioridades.Visible = false;
            // 
            // bmReferencia
            // 
            this.bmReferencia.HeaderText = "Referencia";
            this.bmReferencia.Name = "bmReferencia";
            this.bmReferencia.Width = 84;
            // 
            // bmHolder
            // 
            this.bmHolder.HeaderText = "Holder";
            this.bmHolder.Name = "bmHolder";
            this.bmHolder.Width = 63;
            // 
            // bMarcas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1398, 667);
            this.Controls.Add(this.cbLogo);
            this.Controls.Add(this.button25);
            this.Controls.Add(this.dgvBuscamarca);
            this.Controls.Add(this.tbAvisoprueba);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.cbHolder);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.cbClase);
            this.Controls.Add(this.cbTiposolicitud);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.tbClave);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.cbPais);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.textBox10);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.tbCasoid);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.tbDenominacion);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.tbreferencia);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.tbPrioridad);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.tbCliente);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.tbInteresado);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.tbregistro);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tbexpediente);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBoxCasonumero);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "bMarcas";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = " ";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.bMarcas_FormClosing);
            this.Load += new System.EventHandler(this.bMarcas_Load);
            this.Resize += new System.EventHandler(this.bMarcas_Resize);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBuscamarca)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox tbClave;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.ComboBox cbPais;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox textBox10;
        public System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox tbCasoid;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox tbDenominacion;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox tbreferencia;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox tbPrioridad;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tbCliente;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tbInteresado;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbregistro;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbexpediente;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBoxCasonumero;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox cbTiposolicitud;
        private System.Windows.Forms.ComboBox cbClase;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox tbLimitcasos;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.ComboBox cbHolder;
        private System.Windows.Forms.TextBox tbAvisoprueba;
        private System.Windows.Forms.DataGridView dgvBuscamarca;
        public System.Windows.Forms.Button button25;
        private System.Windows.Forms.Label lbFiltroestatus;
        private System.Windows.Forms.ComboBox cbFiltroestatus;
        private System.Windows.Forms.CheckBox cbLogo;
        private System.Windows.Forms.DataGridViewTextBoxColumn bmPais;
        private System.Windows.Forms.DataGridViewTextBoxColumn bmClase;
        private System.Windows.Forms.DataGridViewTextBoxColumn bmCasoid;
        private System.Windows.Forms.DataGridViewTextBoxColumn bmcaso;
        private System.Windows.Forms.DataGridViewTextBoxColumn bmTipo;
        private System.Windows.Forms.DataGridViewTextBoxColumn tipomarcadescrip;
        private System.Windows.Forms.DataGridViewTextBoxColumn leydescrip;
        private System.Windows.Forms.DataGridViewTextBoxColumn bmEstatus;
        private System.Windows.Forms.DataGridViewTextBoxColumn bmFechapresentacion;
        private System.Windows.Forms.DataGridViewTextBoxColumn bmExpediente;
        private System.Windows.Forms.DataGridViewTextBoxColumn bmFechaconcesion;
        private System.Windows.Forms.DataGridViewTextBoxColumn declaestricta;
        private System.Windows.Forms.DataGridViewTextBoxColumn vigencia;
        private System.Windows.Forms.DataGridViewTextBoxColumn renova;
        private System.Windows.Forms.DataGridViewTextBoxColumn bmRegistro;
        private System.Windows.Forms.DataGridViewTextBoxColumn bmInteresado;
        private System.Windows.Forms.DataGridViewTextBoxColumn Titulonombremarca;
        private System.Windows.Forms.DataGridViewImageColumn Imagecolumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn bmcliente;
        private System.Windows.Forms.DataGridViewTextBoxColumn bmprioridades;
        private System.Windows.Forms.DataGridViewTextBoxColumn bmReferencia;
        private System.Windows.Forms.DataGridViewTextBoxColumn bmHolder;
    }
}