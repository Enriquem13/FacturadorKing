﻿
namespace Facturador.Casos.Marcas
{
    partial class casoNuevomarcas_transferido
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(casoNuevomarcas_transferido));
            this.button3 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label32 = new System.Windows.Forms.Label();
            this.comboTipomarca1 = new System.Windows.Forms.ComboBox();
            this.groupProtocolo = new System.Windows.Forms.GroupBox();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.tbFecharegistrointernacional = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.tbNumregistrointernacional = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.tbEstatus_header = new System.Windows.Forms.TextBox();
            this.label61 = new System.Windows.Forms.Label();
            this.tbNumeroregistro = new System.Windows.Forms.TextBox();
            this.label44 = new System.Windows.Forms.Label();
            this.tbExpediente = new System.Windows.Forms.TextBox();
            this.label43 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.tbFechavigencia = new System.Windows.Forms.TextBox();
            this.label42 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.tbFechaInicioUso = new System.Windows.Forms.TextBox();
            this.label40 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.tbFechaconsecion = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.tbFechaprobouso = new System.Windows.Forms.TextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.tbFechalegal = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.cbMulticaso = new System.Windows.Forms.ComboBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.button7 = new System.Windows.Forms.Button();
            this.tbClavepaiscaso = new System.Windows.Forms.TextBox();
            this.cbPaiscaso = new System.Windows.Forms.ComboBox();
            this.label18 = new System.Windows.Forms.Label();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.label23 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.richTextBoxTitulo = new System.Windows.Forms.RichTextBox();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.textBoxReferencia = new System.Windows.Forms.TextBox();
            this.richTextBoxDireccliente = new System.Windows.Forms.RichTextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.comboBoxResponsable = new System.Windows.Forms.ComboBox();
            this.comboBoxFirma = new System.Windows.Forms.ComboBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.groupPrioridades = new System.Windows.Forms.GroupBox();
            this.cbCvpais = new System.Windows.Forms.ComboBox();
            this.label29 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.bEliminarprioridades = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.listViewPrioridades = new System.Windows.Forms.ListView();
            this.columnNumero = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnFecha = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnPais = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnTipo = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.comboBoxTipodos = new System.Windows.Forms.ComboBox();
            this.label15 = new System.Windows.Forms.Label();
            this.comboBoxPais = new System.Windows.Forms.ComboBox();
            this.textBoxFecha = new System.Windows.Forms.TextBox();
            this.textBoxNumero = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.textBoxPlazolegal = new System.Windows.Forms.TextBox();
            this.comboBoxIdioma = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.comboBoxClase = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.comboBoxInteresado = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.comboBoxContacto = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.comboBoxClientes = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.comboTiposolicitud = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textClientduedate = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.comboboxSubtipo = new System.Windows.Forms.ComboBox();
            this.TexboxFecha = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.groupProtocolo.SuspendLayout();
            this.groupPrioridades.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(12, 12);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 35;
            this.button3.Text = "Menú";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click_1);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label32);
            this.groupBox1.Controls.Add(this.comboTipomarca1);
            this.groupBox1.Controls.Add(this.groupProtocolo);
            this.groupBox1.Controls.Add(this.tbEstatus_header);
            this.groupBox1.Controls.Add(this.label61);
            this.groupBox1.Controls.Add(this.tbNumeroregistro);
            this.groupBox1.Controls.Add(this.label44);
            this.groupBox1.Controls.Add(this.tbExpediente);
            this.groupBox1.Controls.Add(this.label43);
            this.groupBox1.Controls.Add(this.label41);
            this.groupBox1.Controls.Add(this.tbFechavigencia);
            this.groupBox1.Controls.Add(this.label42);
            this.groupBox1.Controls.Add(this.label39);
            this.groupBox1.Controls.Add(this.tbFechaInicioUso);
            this.groupBox1.Controls.Add(this.label40);
            this.groupBox1.Controls.Add(this.label35);
            this.groupBox1.Controls.Add(this.tbFechaconsecion);
            this.groupBox1.Controls.Add(this.label36);
            this.groupBox1.Controls.Add(this.label37);
            this.groupBox1.Controls.Add(this.tbFechaprobouso);
            this.groupBox1.Controls.Add(this.label38);
            this.groupBox1.Controls.Add(this.label33);
            this.groupBox1.Controls.Add(this.tbFechalegal);
            this.groupBox1.Controls.Add(this.label34);
            this.groupBox1.Controls.Add(this.label27);
            this.groupBox1.Controls.Add(this.cbMulticaso);
            this.groupBox1.Controls.Add(this.label22);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.button7);
            this.groupBox1.Controls.Add(this.tbClavepaiscaso);
            this.groupBox1.Controls.Add(this.cbPaiscaso);
            this.groupBox1.Controls.Add(this.label18);
            this.groupBox1.Controls.Add(this.button5);
            this.groupBox1.Controls.Add(this.button6);
            this.groupBox1.Controls.Add(this.label23);
            this.groupBox1.Controls.Add(this.label21);
            this.groupBox1.Controls.Add(this.label20);
            this.groupBox1.Controls.Add(this.label19);
            this.groupBox1.Controls.Add(this.richTextBoxTitulo);
            this.groupBox1.Controls.Add(this.richTextBox1);
            this.groupBox1.Controls.Add(this.textBoxReferencia);
            this.groupBox1.Controls.Add(this.richTextBoxDireccliente);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.comboBoxResponsable);
            this.groupBox1.Controls.Add(this.comboBoxFirma);
            this.groupBox1.Controls.Add(this.label17);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.groupPrioridades);
            this.groupBox1.Controls.Add(this.comboBoxIdioma);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.comboBoxClase);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.comboBoxInteresado);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.comboBoxContacto);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.comboBoxClientes);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.comboTiposolicitud);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.textClientduedate);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.comboboxSubtipo);
            this.groupBox1.Controls.Add(this.TexboxFecha);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.groupBox1.Location = new System.Drawing.Point(11, 41);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1310, 900);
            this.groupBox1.TabIndex = 33;
            this.groupBox1.TabStop = false;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(378, 30);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(77, 16);
            this.label32.TabIndex = 91;
            this.label32.Text = "Tipo Marca";
            // 
            // comboTipomarca1
            // 
            this.comboTipomarca1.FormattingEnabled = true;
            this.comboTipomarca1.Location = new System.Drawing.Point(461, 26);
            this.comboTipomarca1.Name = "comboTipomarca1";
            this.comboTipomarca1.Size = new System.Drawing.Size(292, 24);
            this.comboTipomarca1.TabIndex = 90;
            // 
            // groupProtocolo
            // 
            this.groupProtocolo.BackColor = System.Drawing.Color.WhiteSmoke;
            this.groupProtocolo.Controls.Add(this.label31);
            this.groupProtocolo.Controls.Add(this.label30);
            this.groupProtocolo.Controls.Add(this.tbFecharegistrointernacional);
            this.groupProtocolo.Controls.Add(this.label28);
            this.groupProtocolo.Controls.Add(this.tbNumregistrointernacional);
            this.groupProtocolo.Controls.Add(this.textBox1);
            this.groupProtocolo.Location = new System.Drawing.Point(29, 488);
            this.groupProtocolo.Name = "groupProtocolo";
            this.groupProtocolo.Size = new System.Drawing.Size(1200, 100);
            this.groupProtocolo.TabIndex = 89;
            this.groupProtocolo.TabStop = false;
            this.groupProtocolo.Text = "Protocolo";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(576, 42);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(181, 16);
            this.label31.TabIndex = 65;
            this.label31.Text = "Fecha Vigencia Internacional";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(8, 39);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(91, 16);
            this.label30.TabIndex = 63;
            this.label30.Text = "Fecha Reg Int";
            // 
            // tbFecharegistrointernacional
            // 
            this.tbFecharegistrointernacional.Location = new System.Drawing.Point(100, 36);
            this.tbFecharegistrointernacional.Name = "tbFecharegistrointernacional";
            this.tbFecharegistrointernacional.Size = new System.Drawing.Size(121, 22);
            this.tbFecharegistrointernacional.TabIndex = 62;
            this.tbFecharegistrointernacional.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbFecharegistrointernacional_KeyPress);
            this.tbFecharegistrointernacional.Validating += new System.ComponentModel.CancelEventHandler(this.tbFecharegistrointernacional_Validating);
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(251, 39);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(137, 16);
            this.label28.TabIndex = 61;
            this.label28.Text = "No. Reg Internacional";
            // 
            // tbNumregistrointernacional
            // 
            this.tbNumregistrointernacional.Location = new System.Drawing.Point(394, 36);
            this.tbNumregistrointernacional.Name = "tbNumregistrointernacional";
            this.tbNumregistrointernacional.Size = new System.Drawing.Size(119, 22);
            this.tbNumregistrointernacional.TabIndex = 60;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(781, 36);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(131, 22);
            this.textBox1.TabIndex = 64;
            this.textBox1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox1_KeyPress);
            this.textBox1.Validating += new System.ComponentModel.CancelEventHandler(this.textBox1_Validating);
            // 
            // tbEstatus_header
            // 
            this.tbEstatus_header.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbEstatus_header.Location = new System.Drawing.Point(109, 331);
            this.tbEstatus_header.Name = "tbEstatus_header";
            this.tbEstatus_header.ReadOnly = true;
            this.tbEstatus_header.Size = new System.Drawing.Size(345, 21);
            this.tbEstatus_header.TabIndex = 87;
            this.tbEstatus_header.DoubleClick += new System.EventHandler(this.tbEstatus_header_DoubleClick);
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label61.Location = new System.Drawing.Point(30, 337);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(64, 15);
            this.label61.TabIndex = 86;
            this.label61.Text = "Estatus *";
            this.label61.Click += new System.EventHandler(this.label61_Click);
            this.label61.DoubleClick += new System.EventHandler(this.tbEstatus_header_DoubleClick);
            // 
            // tbNumeroregistro
            // 
            this.tbNumeroregistro.Location = new System.Drawing.Point(127, 446);
            this.tbNumeroregistro.MaxLength = 40;
            this.tbNumeroregistro.Name = "tbNumeroregistro";
            this.tbNumeroregistro.Size = new System.Drawing.Size(132, 22);
            this.tbNumeroregistro.TabIndex = 85;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.label44.Location = new System.Drawing.Point(30, 450);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(83, 16);
            this.label44.TabIndex = 84;
            this.label44.Text = "No. Registro";
            // 
            // tbExpediente
            // 
            this.tbExpediente.Location = new System.Drawing.Point(129, 412);
            this.tbExpediente.MaxLength = 40;
            this.tbExpediente.Name = "tbExpediente";
            this.tbExpediente.Size = new System.Drawing.Size(132, 22);
            this.tbExpediente.TabIndex = 83;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.label43.Location = new System.Drawing.Point(30, 415);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(76, 16);
            this.label43.TabIndex = 82;
            this.label43.Text = "Expediente";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.Location = new System.Drawing.Point(743, 432);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(57, 12);
            this.label41.TabIndex = 81;
            this.label41.Text = "dd-mm-yyyy";
            // 
            // tbFechavigencia
            // 
            this.tbFechavigencia.Location = new System.Drawing.Point(713, 447);
            this.tbFechavigencia.MaxLength = 10;
            this.tbFechavigencia.Name = "tbFechavigencia";
            this.tbFechavigencia.Size = new System.Drawing.Size(119, 22);
            this.tbFechavigencia.TabIndex = 80;
            this.tbFechavigencia.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbFechavigencia_KeyPress);
            this.tbFechavigencia.Validating += new System.ComponentModel.CancelEventHandler(this.tbFechavigencia_Validating);
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.label42.Location = new System.Drawing.Point(605, 449);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(102, 16);
            this.label42.TabIndex = 79;
            this.label42.Text = "Fecha Vigencia";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(1051, 422);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(57, 12);
            this.label39.TabIndex = 78;
            this.label39.Text = "dd-mm-yyyy";
            // 
            // tbFechaInicioUso
            // 
            this.tbFechaInicioUso.Location = new System.Drawing.Point(142, 379);
            this.tbFechaInicioUso.MaxLength = 10;
            this.tbFechaInicioUso.Name = "tbFechaInicioUso";
            this.tbFechaInicioUso.Size = new System.Drawing.Size(119, 22);
            this.tbFechaInicioUso.TabIndex = 77;
            this.tbFechaInicioUso.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbFechaInicioUso_KeyPress);
            this.tbFechaInicioUso.Validating += new System.ComponentModel.CancelEventHandler(this.tbFechaInicioUso_Validating);
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.label40.Location = new System.Drawing.Point(30, 385);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(108, 16);
            this.label40.TabIndex = 76;
            this.label40.Text = "Fecha Inicio Uso";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(463, 435);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(57, 12);
            this.label35.TabIndex = 75;
            this.label35.Text = "dd-mm-yyyy";
            // 
            // tbFechaconsecion
            // 
            this.tbFechaconsecion.Location = new System.Drawing.Point(440, 447);
            this.tbFechaconsecion.MaxLength = 10;
            this.tbFechaconsecion.Name = "tbFechaconsecion";
            this.tbFechaconsecion.Size = new System.Drawing.Size(119, 22);
            this.tbFechaconsecion.TabIndex = 74;
            this.tbFechaconsecion.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbFechaconsecion_KeyPress);
            this.tbFechaconsecion.Validating += new System.ComponentModel.CancelEventHandler(this.tbFechaconsecion_Validating);
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.label36.Location = new System.Drawing.Point(313, 449);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(113, 16);
            this.label36.TabIndex = 73;
            this.label36.Text = "Fecha Concesión";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(165, 364);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(57, 12);
            this.label37.TabIndex = 72;
            this.label37.Text = "dd-mm-yyyy";
            // 
            // tbFechaprobouso
            // 
            this.tbFechaprobouso.Location = new System.Drawing.Point(1046, 446);
            this.tbFechaprobouso.MaxLength = 10;
            this.tbFechaprobouso.Name = "tbFechaprobouso";
            this.tbFechaprobouso.Size = new System.Drawing.Size(119, 22);
            this.tbFechaprobouso.TabIndex = 71;
            this.tbFechaprobouso.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbFechaprobouso_KeyPress);
            this.tbFechaprobouso.Validating += new System.ComponentModel.CancelEventHandler(this.tbFechaprobouso_Validating);
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.label38.Location = new System.Drawing.Point(873, 450);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(160, 16);
            this.label38.TabIndex = 70;
            this.label38.Text = "Fecha Decla Uso Estricto";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(462, 391);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(57, 12);
            this.label33.TabIndex = 69;
            this.label33.Text = "dd-mm-yyyy";
            // 
            // tbFechalegal
            // 
            this.tbFechalegal.Location = new System.Drawing.Point(442, 412);
            this.tbFechalegal.MaxLength = 10;
            this.tbFechalegal.Name = "tbFechalegal";
            this.tbFechalegal.Size = new System.Drawing.Size(119, 22);
            this.tbFechalegal.TabIndex = 68;
            this.tbFechalegal.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbFechalegal_KeyPress);
            this.tbFechalegal.Validating += new System.ComponentModel.CancelEventHandler(this.tbFechalegal_Validating);
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.label34.Location = new System.Drawing.Point(313, 418);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(128, 16);
            this.label34.TabIndex = 67;
            this.label34.Text = "Fecha Presentación";
            this.label34.Click += new System.EventHandler(this.label34_Click);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(1051, 68);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(118, 16);
            this.label27.TabIndex = 59;
            this.label27.Text = "Casos multiples";
            this.label27.Visible = false;
            // 
            // cbMulticaso
            // 
            this.cbMulticaso.FormattingEnabled = true;
            this.cbMulticaso.Items.AddRange(new object[] {
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23",
            "24",
            "25"});
            this.cbMulticaso.Location = new System.Drawing.Point(1183, 65);
            this.cbMulticaso.Name = "cbMulticaso";
            this.cbMulticaso.Size = new System.Drawing.Size(121, 24);
            this.cbMulticaso.TabIndex = 33;
            this.cbMulticaso.Visible = false;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(171, 59);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(57, 12);
            this.label22.TabIndex = 58;
            this.label22.Text = "dd-mm-yyyy";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(557, 53);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(57, 12);
            this.label5.TabIndex = 57;
            this.label5.Text = "dd-mm-yyyy";
            // 
            // button7
            // 
            this.button7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button7.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.Location = new System.Drawing.Point(111, 205);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(267, 20);
            this.button7.TabIndex = 56;
            this.button7.Text = "Agregar contacto sobre el cliente seleccionado";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click_1);
            // 
            // tbClavepaiscaso
            // 
            this.tbClavepaiscaso.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbClavepaiscaso.Location = new System.Drawing.Point(993, 860);
            this.tbClavepaiscaso.Name = "tbClavepaiscaso";
            this.tbClavepaiscaso.Size = new System.Drawing.Size(66, 22);
            this.tbClavepaiscaso.TabIndex = 55;
            this.tbClavepaiscaso.TextChanged += new System.EventHandler(this.tbClavepaiscaso_TextChanged);
            // 
            // cbPaiscaso
            // 
            this.cbPaiscaso.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbPaiscaso.FormattingEnabled = true;
            this.cbPaiscaso.ItemHeight = 16;
            this.cbPaiscaso.Location = new System.Drawing.Point(745, 859);
            this.cbPaiscaso.Name = "cbPaiscaso";
            this.cbPaiscaso.Size = new System.Drawing.Size(242, 24);
            this.cbPaiscaso.TabIndex = 53;
            this.cbPaiscaso.SelectedIndexChanged += new System.EventHandler(this.cbPaiscaso_SelectedIndexChanged);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(711, 862);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(35, 16);
            this.label18.TabIndex = 54;
            this.label18.Text = "País";
            // 
            // button5
            // 
            this.button5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.Location = new System.Drawing.Point(372, 300);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(125, 20);
            this.button5.TabIndex = 52;
            this.button5.Text = "Agregar Nuevo Titular";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click_1);
            // 
            // button6
            // 
            this.button6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button6.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.Location = new System.Drawing.Point(111, 145);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(166, 20);
            this.button6.TabIndex = 51;
            this.button6.Text = "Agregar Nuevo Cliente y Contacto";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click_1);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(807, 278);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(54, 16);
            this.label23.TabIndex = 42;
            this.label23.Text = "Marca *";
            this.label23.Click += new System.EventHandler(this.label23_Click);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(792, 30);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(30, 16);
            this.label21.TabIndex = 40;
            this.label21.Text = "Ley";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(795, 166);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(61, 32);
            this.label20.TabIndex = 39;
            this.label20.Text = "Correos \r\nContacto";
            this.label20.Click += new System.EventHandler(this.label20_Click);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(794, 105);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(68, 32);
            this.label19.TabIndex = 38;
            this.label19.Text = "Dirección \r\nCliente";
            this.label19.Click += new System.EventHandler(this.label19_Click);
            // 
            // richTextBoxTitulo
            // 
            this.richTextBoxTitulo.Location = new System.Drawing.Point(867, 261);
            this.richTextBoxTitulo.Name = "richTextBoxTitulo";
            this.richTextBoxTitulo.Size = new System.Drawing.Size(430, 59);
            this.richTextBoxTitulo.TabIndex = 35;
            this.richTextBoxTitulo.Text = "";
            this.richTextBoxTitulo.TextChanged += new System.EventHandler(this.richTextBoxTitulo_TextChanged);
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(866, 159);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.ReadOnly = true;
            this.richTextBox1.Size = new System.Drawing.Size(430, 48);
            this.richTextBox1.TabIndex = 34;
            this.richTextBox1.Text = "";
            this.richTextBox1.TextChanged += new System.EventHandler(this.richTextBox1_TextChanged);
            // 
            // textBoxReferencia
            // 
            this.textBoxReferencia.Location = new System.Drawing.Point(111, 235);
            this.textBoxReferencia.Name = "textBoxReferencia";
            this.textBoxReferencia.Size = new System.Drawing.Size(227, 22);
            this.textBoxReferencia.TabIndex = 33;
            // 
            // richTextBoxDireccliente
            // 
            this.richTextBoxDireccliente.Location = new System.Drawing.Point(866, 97);
            this.richTextBoxDireccliente.Name = "richTextBoxDireccliente";
            this.richTextBoxDireccliente.ReadOnly = true;
            this.richTextBoxDireccliente.Size = new System.Drawing.Size(430, 48);
            this.richTextBoxDireccliente.TabIndex = 32;
            this.richTextBoxDireccliente.Text = "";
            this.richTextBoxDireccliente.TextChanged += new System.EventHandler(this.richTextBoxDireccliente_TextChanged);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(1081, 860);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(148, 23);
            this.button1.TabIndex = 30;
            this.button1.Text = "Crear Caso";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // comboBoxResponsable
            // 
            this.comboBoxResponsable.FormattingEnabled = true;
            this.comboBoxResponsable.Location = new System.Drawing.Point(490, 859);
            this.comboBoxResponsable.Name = "comboBoxResponsable";
            this.comboBoxResponsable.Size = new System.Drawing.Size(205, 24);
            this.comboBoxResponsable.TabIndex = 29;
            // 
            // comboBoxFirma
            // 
            this.comboBoxFirma.FormattingEnabled = true;
            this.comboBoxFirma.Location = new System.Drawing.Point(88, 859);
            this.comboBoxFirma.Name = "comboBoxFirma";
            this.comboBoxFirma.Size = new System.Drawing.Size(283, 24);
            this.comboBoxFirma.TabIndex = 10;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(391, 862);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(90, 16);
            this.label17.TabIndex = 28;
            this.label17.Text = "Responsable";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(34, 862);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(42, 16);
            this.label16.TabIndex = 27;
            this.label16.Text = "Firma";
            // 
            // groupPrioridades
            // 
            this.groupPrioridades.BackColor = System.Drawing.Color.WhiteSmoke;
            this.groupPrioridades.Controls.Add(this.cbCvpais);
            this.groupPrioridades.Controls.Add(this.label29);
            this.groupPrioridades.Controls.Add(this.label26);
            this.groupPrioridades.Controls.Add(this.label24);
            this.groupPrioridades.Controls.Add(this.label25);
            this.groupPrioridades.Controls.Add(this.bEliminarprioridades);
            this.groupPrioridades.Controls.Add(this.pictureBox1);
            this.groupPrioridades.Controls.Add(this.listViewPrioridades);
            this.groupPrioridades.Controls.Add(this.comboBoxTipodos);
            this.groupPrioridades.Controls.Add(this.label15);
            this.groupPrioridades.Controls.Add(this.comboBoxPais);
            this.groupPrioridades.Controls.Add(this.textBoxFecha);
            this.groupPrioridades.Controls.Add(this.textBoxNumero);
            this.groupPrioridades.Controls.Add(this.label14);
            this.groupPrioridades.Controls.Add(this.label13);
            this.groupPrioridades.Controls.Add(this.label12);
            this.groupPrioridades.Controls.Add(this.label4);
            this.groupPrioridades.Controls.Add(this.textBoxPlazolegal);
            this.groupPrioridades.Location = new System.Drawing.Point(29, 617);
            this.groupPrioridades.Name = "groupPrioridades";
            this.groupPrioridades.Size = new System.Drawing.Size(1200, 225);
            this.groupPrioridades.TabIndex = 26;
            this.groupPrioridades.TabStop = false;
            this.groupPrioridades.Text = "Prioridad";
            // 
            // cbCvpais
            // 
            this.cbCvpais.FormattingEnabled = true;
            this.cbCvpais.Location = new System.Drawing.Point(483, 27);
            this.cbCvpais.Name = "cbCvpais";
            this.cbCvpais.Size = new System.Drawing.Size(66, 24);
            this.cbCvpais.TabIndex = 60;
            this.cbCvpais.SelectedIndexChanged += new System.EventHandler(this.cbCvpais_SelectedIndexChanged_1);
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(140, 178);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(57, 12);
            this.label29.TabIndex = 56;
            this.label29.Text = "dd-mm-yyyy";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(308, 17);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(57, 12);
            this.label26.TabIndex = 59;
            this.label26.Text = "dd-mm-yyyy";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(1076, 98);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(59, 26);
            this.label24.TabIndex = 24;
            this.label24.Text = "Agregar \r\nPrioridades";
            this.label24.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(1068, 158);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(58, 26);
            this.label25.TabIndex = 22;
            this.label25.Text = "Eliminar \r\nprioridades";
            this.label25.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // bEliminarprioridades
            // 
            this.bEliminarprioridades.BackgroundImage = global::Facturador.Properties.Resources._16494;
            this.bEliminarprioridades.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.bEliminarprioridades.Location = new System.Drawing.Point(1150, 158);
            this.bEliminarprioridades.Name = "bEliminarprioridades";
            this.bEliminarprioridades.Size = new System.Drawing.Size(33, 31);
            this.bEliminarprioridades.TabIndex = 23;
            this.bEliminarprioridades.UseVisualStyleBackColor = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(1143, 87);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(40, 37);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 10;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click_1);
            // 
            // listViewPrioridades
            // 
            this.listViewPrioridades.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnNumero,
            this.columnFecha,
            this.columnPais,
            this.columnTipo});
            this.listViewPrioridades.FullRowSelect = true;
            this.listViewPrioridades.GridLines = true;
            this.listViewPrioridades.HideSelection = false;
            this.listViewPrioridades.Location = new System.Drawing.Point(11, 70);
            this.listViewPrioridades.Name = "listViewPrioridades";
            this.listViewPrioridades.Size = new System.Drawing.Size(1019, 104);
            this.listViewPrioridades.TabIndex = 9;
            this.listViewPrioridades.UseCompatibleStateImageBehavior = false;
            this.listViewPrioridades.View = System.Windows.Forms.View.Details;
            // 
            // columnNumero
            // 
            this.columnNumero.Text = "Número";
            this.columnNumero.Width = 151;
            // 
            // columnFecha
            // 
            this.columnFecha.Text = "Fecha";
            this.columnFecha.Width = 212;
            // 
            // columnPais
            // 
            this.columnPais.Text = "País";
            this.columnPais.Width = 444;
            // 
            // columnTipo
            // 
            this.columnTipo.Text = "Tipo";
            this.columnTipo.Width = 208;
            // 
            // comboBoxTipodos
            // 
            this.comboBoxTipodos.FormattingEnabled = true;
            this.comboBoxTipodos.Location = new System.Drawing.Point(1063, 27);
            this.comboBoxTipodos.Name = "comboBoxTipodos";
            this.comboBoxTipodos.Size = new System.Drawing.Size(111, 24);
            this.comboBoxTipodos.TabIndex = 8;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(1021, 33);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(36, 16);
            this.label15.TabIndex = 7;
            this.label15.Text = "Tipo";
            // 
            // comboBoxPais
            // 
            this.comboBoxPais.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxPais.FormattingEnabled = true;
            this.comboBoxPais.Location = new System.Drawing.Point(552, 27);
            this.comboBoxPais.Name = "comboBoxPais";
            this.comboBoxPais.Size = new System.Drawing.Size(424, 24);
            this.comboBoxPais.TabIndex = 6;
            // 
            // textBoxFecha
            // 
            this.textBoxFecha.Location = new System.Drawing.Point(297, 32);
            this.textBoxFecha.MaxLength = 10;
            this.textBoxFecha.Name = "textBoxFecha";
            this.textBoxFecha.Size = new System.Drawing.Size(77, 22);
            this.textBoxFecha.TabIndex = 5;
            // 
            // textBoxNumero
            // 
            this.textBoxNumero.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBoxNumero.Location = new System.Drawing.Point(70, 33);
            this.textBoxNumero.Name = "textBoxNumero";
            this.textBoxNumero.Size = new System.Drawing.Size(169, 22);
            this.textBoxNumero.TabIndex = 4;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(437, 33);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(35, 16);
            this.label14.TabIndex = 2;
            this.label14.Text = "País";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(245, 37);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(46, 16);
            this.label13.TabIndex = 1;
            this.label13.Text = "Fecha";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(8, 38);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(56, 16);
            this.label12.TabIndex = 0;
            this.label12.Text = "Número";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.label4.Location = new System.Drawing.Point(8, 185);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(86, 32);
            this.label4.TabIndex = 8;
            this.label4.Text = "Plazo legal \r\npresentación";
            // 
            // textBoxPlazolegal
            // 
            this.textBoxPlazolegal.Location = new System.Drawing.Point(121, 193);
            this.textBoxPlazolegal.MaxLength = 10;
            this.textBoxPlazolegal.Name = "textBoxPlazolegal";
            this.textBoxPlazolegal.Size = new System.Drawing.Size(100, 22);
            this.textBoxPlazolegal.TabIndex = 9;
            // 
            // comboBoxIdioma
            // 
            this.comboBoxIdioma.FormattingEnabled = true;
            this.comboBoxIdioma.Location = new System.Drawing.Point(584, 121);
            this.comboBoxIdioma.Name = "comboBoxIdioma";
            this.comboBoxIdioma.Size = new System.Drawing.Size(121, 24);
            this.comboBoxIdioma.TabIndex = 25;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(529, 124);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(49, 16);
            this.label11.TabIndex = 24;
            this.label11.Text = "Idioma";
            // 
            // comboBoxClase
            // 
            this.comboBoxClase.FormattingEnabled = true;
            this.comboBoxClase.Location = new System.Drawing.Point(1110, 30);
            this.comboBoxClase.Name = "comboBoxClase";
            this.comboBoxClase.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.comboBoxClase.Size = new System.Drawing.Size(119, 24);
            this.comboBoxClase.TabIndex = 23;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(1043, 35);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(43, 16);
            this.label10.TabIndex = 22;
            this.label10.Text = "Clase";
            // 
            // comboBoxInteresado
            // 
            this.comboBoxInteresado.FormattingEnabled = true;
            this.comboBoxInteresado.Location = new System.Drawing.Point(111, 270);
            this.comboBoxInteresado.Name = "comboBoxInteresado";
            this.comboBoxInteresado.Size = new System.Drawing.Size(386, 24);
            this.comboBoxInteresado.TabIndex = 20;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(31, 278);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(53, 16);
            this.label9.TabIndex = 19;
            this.label9.Text = "Titular *";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(31, 241);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(74, 16);
            this.label8.TabIndex = 17;
            this.label8.Text = "Referencia";
            // 
            // comboBoxContacto
            // 
            this.comboBoxContacto.FormattingEnabled = true;
            this.comboBoxContacto.Location = new System.Drawing.Point(111, 181);
            this.comboBoxContacto.Name = "comboBoxContacto";
            this.comboBoxContacto.Size = new System.Drawing.Size(386, 24);
            this.comboBoxContacto.TabIndex = 16;
            this.comboBoxContacto.SelectedIndexChanged += new System.EventHandler(this.comboBoxContacto_SelectedIndexChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(31, 189);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(69, 16);
            this.label7.TabIndex = 15;
            this.label7.Text = "Contacto *";
            // 
            // comboBoxClientes
            // 
            this.comboBoxClientes.FormattingEnabled = true;
            this.comboBoxClientes.Location = new System.Drawing.Point(111, 121);
            this.comboBoxClientes.Name = "comboBoxClientes";
            this.comboBoxClientes.Size = new System.Drawing.Size(386, 24);
            this.comboBoxClientes.TabIndex = 13;
            this.comboBoxClientes.SelectedIndexChanged += new System.EventHandler(this.comboBoxClientes_SelectedIndexChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(34, 124);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(57, 16);
            this.label6.TabIndex = 12;
            this.label6.Text = "Cliente *";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // comboTiposolicitud
            // 
            this.comboTiposolicitud.FormattingEnabled = true;
            this.comboTiposolicitud.Location = new System.Drawing.Point(153, 21);
            this.comboTiposolicitud.Name = "comboTiposolicitud";
            this.comboTiposolicitud.Size = new System.Drawing.Size(219, 24);
            this.comboTiposolicitud.TabIndex = 2;
            this.comboTiposolicitud.SelectedIndexChanged += new System.EventHandler(this.comboTiposolicitud_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(34, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(115, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Tipo de solicitud *";
            // 
            // textClientduedate
            // 
            this.textClientduedate.Location = new System.Drawing.Point(521, 68);
            this.textClientduedate.MaxLength = 10;
            this.textClientduedate.Name = "textClientduedate";
            this.textClientduedate.Size = new System.Drawing.Size(119, 22);
            this.textClientduedate.TabIndex = 7;
            this.textClientduedate.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textClientduedate_KeyPress);
            this.textClientduedate.Validating += new System.ComponentModel.CancelEventHandler(this.textClientduedate_Validating_1);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.label2.Location = new System.Drawing.Point(34, 77);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(87, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Fecha carta *";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.label3.Location = new System.Drawing.Point(406, 71);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(97, 16);
            this.label3.TabIndex = 6;
            this.label3.Text = "Client due date";
            // 
            // comboboxSubtipo
            // 
            this.comboboxSubtipo.FormattingEnabled = true;
            this.comboboxSubtipo.Location = new System.Drawing.Point(842, 27);
            this.comboboxSubtipo.Name = "comboboxSubtipo";
            this.comboboxSubtipo.Size = new System.Drawing.Size(180, 24);
            this.comboboxSubtipo.TabIndex = 3;
            this.comboboxSubtipo.SelectedIndexChanged += new System.EventHandler(this.comboboxSubtipo_SelectedIndexChanged);
            // 
            // TexboxFecha
            // 
            this.TexboxFecha.Location = new System.Drawing.Point(152, 71);
            this.TexboxFecha.MaxLength = 10;
            this.TexboxFecha.Name = "TexboxFecha";
            this.TexboxFecha.Size = new System.Drawing.Size(100, 22);
            this.TexboxFecha.TabIndex = 5;
            this.TexboxFecha.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TexboxFecha_KeyPress_1);
            this.TexboxFecha.Validating += new System.ComponentModel.CancelEventHandler(this.TexboxFecha_Validating_1);
            // 
            // casoNuevomarcas_transferido
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(1333, 948);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.groupBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "casoNuevomarcas_transferido";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Caso Nuevo Marcas Transferido";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.casoNuevomarcas_transferido_FormClosing);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupProtocolo.ResumeLayout(false);
            this.groupProtocolo.PerformLayout();
            this.groupPrioridades.ResumeLayout(false);
            this.groupPrioridades.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox tbFecharegistrointernacional;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox tbNumregistrointernacional;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.ComboBox cbMulticaso;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.TextBox tbClavepaiscaso;
        private System.Windows.Forms.ComboBox cbPaiscaso;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.RichTextBox richTextBoxTitulo;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.TextBox textBoxReferencia;
        private System.Windows.Forms.RichTextBox richTextBoxDireccliente;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ComboBox comboBoxResponsable;
        private System.Windows.Forms.ComboBox comboBoxFirma;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.GroupBox groupPrioridades;
        private System.Windows.Forms.ComboBox cbCvpais;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Button bEliminarprioridades;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ListView listViewPrioridades;
        private System.Windows.Forms.ColumnHeader columnNumero;
        private System.Windows.Forms.ColumnHeader columnFecha;
        private System.Windows.Forms.ColumnHeader columnPais;
        private System.Windows.Forms.ColumnHeader columnTipo;
        public System.Windows.Forms.ComboBox comboBoxTipodos;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.ComboBox comboBoxPais;
        private System.Windows.Forms.TextBox textBoxFecha;
        private System.Windows.Forms.TextBox textBoxNumero;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBoxPlazolegal;
        private System.Windows.Forms.ComboBox comboBoxIdioma;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox comboBoxClase;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox comboBoxInteresado;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox comboBoxContacto;
        private System.Windows.Forms.Label label7;
        public System.Windows.Forms.ComboBox comboBoxClientes;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox comboTiposolicitud;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textClientduedate;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox comboboxSubtipo;
        private System.Windows.Forms.TextBox TexboxFecha;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.TextBox tbFechavigencia;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.TextBox tbFechaInicioUso;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.TextBox tbFechaconsecion;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.TextBox tbFechaprobouso;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.TextBox tbFechalegal;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TextBox tbNumeroregistro;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.TextBox tbExpediente;
        private System.Windows.Forms.Label label43;
        public System.Windows.Forms.TextBox tbEstatus_header;
        public System.Windows.Forms.Label label61;
        private System.Windows.Forms.GroupBox groupProtocolo;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.ComboBox comboTipomarca1;
    }
}