﻿namespace Facturador
{
    partial class fTmarcas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(fTmarcas));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle25 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle26 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle28 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle27 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tabcFDatosgenerales = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.button20 = new System.Windows.Forms.Button();
            this.button37 = new System.Windows.Forms.Button();
            this.rtbDLeyendasfiguras = new System.Windows.Forms.RichTextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.rtbDDenominacion = new System.Windows.Forms.RichTextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.dGVProductos = new System.Windows.Forms.DataGridView();
            this.casoproductoid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clasedescript = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.descripcionclase = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btModificaciones = new System.Windows.Forms.Button();
            this.lProductosdelcaso = new System.Windows.Forms.Label();
            this.lDescrip = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.button7 = new System.Windows.Forms.Button();
            this.tbNumprod = new System.Windows.Forms.TextBox();
            this.rtbDProductossidiomaorig = new System.Windows.Forms.RichTextBox();
            this.button5 = new System.Windows.Forms.Button();
            this.rtDescripciondelproducto = new System.Windows.Forms.RichTextBox();
            this.rtbdescripcionclase = new System.Windows.Forms.RichTextBox();
            this.cbClasemarca = new System.Windows.Forms.ComboBox();
            this.label22 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tb_contdocelect = new System.Windows.Forms.TextBox();
            this.lvReferencias = new System.Windows.Forms.ListView();
            this.columnHeader17 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader18 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.tb_referencia = new System.Windows.Forms.TextBox();
            this.label42 = new System.Windows.Forms.Label();
            this.cbTiporeferencia = new System.Windows.Forms.ComboBox();
            this.label43 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.button40 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.lvinteresados = new System.Windows.Forms.ListView();
            this.columnHeader19 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader20 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader21 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader22 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader23 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader24 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader25 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tipopersona = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.button14 = new System.Windows.Forms.Button();
            this.label88 = new System.Windows.Forms.Label();
            this.label89 = new System.Windows.Forms.Label();
            this.label79 = new System.Windows.Forms.Label();
            this.rtNumprio = new System.Windows.Forms.RichTextBox();
            this.tbCvepais = new System.Windows.Forms.TextBox();
            this.tbfechaprio = new System.Windows.Forms.TextBox();
            this.tbNumeroprio = new System.Windows.Forms.TextBox();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.cbTiposolprio = new System.Windows.Forms.ComboBox();
            this.label46 = new System.Windows.Forms.Label();
            this.cbNombrepais = new System.Windows.Forms.ComboBox();
            this.label45 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.bEliminarprioridades = new System.Windows.Forms.Button();
            this.lvPrioridades = new System.Windows.Forms.ListView();
            this.idPrioridad = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.numeroprioridad = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.fechaprioridad = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clavepais = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.pais = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Tipoprioridad = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.button16 = new System.Windows.Forms.Button();
            this.bAgregarplazo = new System.Windows.Forms.Button();
            this.label59 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.tbDSigpruebauso_plazos = new System.Windows.Forms.TextBox();
            this.label63 = new System.Windows.Forms.Label();
            this.tbDFechavigencia_plazos = new System.Windows.Forms.TextBox();
            this.label72 = new System.Windows.Forms.Label();
            this.tbDfecharecepcion_plazos = new System.Windows.Forms.TextBox();
            this.label73 = new System.Windows.Forms.Label();
            this.button46 = new System.Windows.Forms.Button();
            this.button45 = new System.Windows.Forms.Button();
            this.dgPlazos = new System.Windows.Forms.DataGridView();
            this.plazoid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.plazosidetalle = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.usuario_id_plazo_impi = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.documentoid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.documentodescrip = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tipoplazoid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tipoplazodescrip = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.estatusplazouno = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fechaplazo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fechavencimientoplazouno = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fechaprorrogaplazouno = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fechavencimiento4meses = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fechaatendioplazouno = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Usuarioid_atendio_plazo_impi = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sDoc_atendio = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.motivocancelaciondesc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fechacancelacionimpi = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.usuariocancelo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.button21 = new System.Windows.Forms.Button();
            this.lvPlazos = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader8 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader9 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader10 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader11 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader12 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader13 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader14 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader15 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader16 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.button22 = new System.Windows.Forms.Button();
            this.dGV_docimentos_IMPI = new System.Windows.Forms.DataGridView();
            this.lnk = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tipo_documento = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cod_barras = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.folio = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fecha_notificacion = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vencimiento = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vencimiento_3_meses = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vencimiento_4_meses = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mes_antiguedad_plazo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Fecha_Impi = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.escrito_doc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.documento = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.estatus_documentos_impi = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.plazo_final = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.observacion_documento = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.aviso_cliente_documento = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mot_cancelacion = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.usr_prorrogo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fecha_firma = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.documento_relacion = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.subtipodocumentoid_documento = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.documentoidmarcas = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lvdocumentosimpi = new System.Windows.Forms.ListView();
            this.link = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Tipo = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Codgbarras = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.cFolio = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.cFechanotific = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.cVencimiento = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.cVencimiento2mese = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.cVencimiento3mese = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.cMes = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.cFechaimpi = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.cFechaescrito = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.cDocumento = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.cEstatus = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.cPlazofinal = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.cObservacion = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.cAvisocliente = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.cMotCancelacion = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.cUsuarioprorrogo = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.cFechafirma = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.cDocumentorelaciona = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.subtipodocumentoid = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.button44 = new System.Windows.Forms.Button();
            this.button43 = new System.Windows.Forms.Button();
            this.button42 = new System.Windows.Forms.Button();
            this.button41 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.button18 = new System.Windows.Forms.Button();
            this.lvDocumentosmarcas = new System.Windows.Forms.ListView();
            this.columnHeader35 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader36 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader37 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader38 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader39 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader40 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader41 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader42 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader43 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader44 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader45 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader46 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader47 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader48 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader49 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader50 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader51 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader52 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tabPage9 = new System.Windows.Forms.TabPage();
            this.listView8 = new System.Windows.Forms.ListView();
            this.columnHeader58 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader59 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader60 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader61 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader62 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader63 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader64 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader65 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader66 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader67 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tabPage10 = new System.Windows.Forms.TabPage();
            this.listView9 = new System.Windows.Forms.ListView();
            this.columnHeader68 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader69 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader70 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader71 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader72 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader73 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader74 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.button23 = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.button25 = new System.Windows.Forms.Button();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.label51 = new System.Windows.Forms.Label();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.label50 = new System.Windows.Forms.Label();
            this.richTextBox6 = new System.Windows.Forms.RichTextBox();
            this.label49 = new System.Windows.Forms.Label();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.label48 = new System.Windows.Forms.Label();
            this.comboBox5 = new System.Windows.Forms.ComboBox();
            this.label52 = new System.Windows.Forms.Label();
            this.tabPage11 = new System.Windows.Forms.TabPage();
            this.listView10 = new System.Windows.Forms.ListView();
            this.columnHeader75 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader76 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader77 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.button26 = new System.Windows.Forms.Button();
            this.button27 = new System.Windows.Forms.Button();
            this.button28 = new System.Windows.Forms.Button();
            this.richTextBox7 = new System.Windows.Forms.RichTextBox();
            this.label54 = new System.Windows.Forms.Label();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.label53 = new System.Windows.Forms.Label();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.label55 = new System.Windows.Forms.Label();
            this.tabPage12 = new System.Windows.Forms.TabPage();
            this.button29 = new System.Windows.Forms.Button();
            this.dgDocumentoselectronicos = new System.Windows.Forms.DataGridView();
            this.documentoelectronicoid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fecha = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.usuario = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tipo_doc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Descripcion = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ruta = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tb_contdocelect_ = new System.Windows.Forms.TextBox();
            this.button6 = new System.Windows.Forms.Button();
            this.tb_filename = new System.Windows.Forms.TextBox();
            this.tb_descripdocelec = new System.Windows.Forms.TextBox();
            this.button15 = new System.Windows.Forms.Button();
            this.label66 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.cb_tipodocelect = new System.Windows.Forms.ComboBox();
            this.tabPage13 = new System.Windows.Forms.TabPage();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label47 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label75 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.cbIdiomacarta = new System.Windows.Forms.ComboBox();
            this.label104 = new System.Windows.Forms.Label();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.button31 = new System.Windows.Forms.Button();
            this.cbCartas = new System.Windows.Forms.ComboBox();
            this.label68 = new System.Windows.Forms.Label();
            this.cbOficiosEscritos = new System.Windows.Forms.ComboBox();
            this.label67 = new System.Windows.Forms.Label();
            this.tabPage14 = new System.Windows.Forms.TabPage();
            this.cbidiomaescrito = new System.Windows.Forms.ComboBox();
            this.label103 = new System.Windows.Forms.Label();
            this.checkBox6 = new System.Windows.Forms.CheckBox();
            this.button32 = new System.Windows.Forms.Button();
            this.cbDocEscritos = new System.Windows.Forms.ComboBox();
            this.label70 = new System.Windows.Forms.Label();
            this.cbOficiosparaescritos = new System.Windows.Forms.ComboBox();
            this.label69 = new System.Windows.Forms.Label();
            this.tabPage15 = new System.Windows.Forms.TabPage();
            this.cbIdiomadoc = new System.Windows.Forms.ComboBox();
            this.label82 = new System.Windows.Forms.Label();
            this.btnGenerarcesion = new System.Windows.Forms.Button();
            this.cbCesiones = new System.Windows.Forms.ComboBox();
            this.label80 = new System.Windows.Forms.Label();
            this.btnGenerarpoder = new System.Windows.Forms.Button();
            this.cbPoder = new System.Windows.Forms.ComboBox();
            this.label81 = new System.Windows.Forms.Label();
            this.button33 = new System.Windows.Forms.Button();
            this.label71 = new System.Windows.Forms.Label();
            this.CB_formatoscc = new System.Windows.Forms.ComboBox();
            this.tabPage17 = new System.Windows.Forms.TabPage();
            this.dgview_facturas = new System.Windows.Forms.DataGridView();
            this.fac_pdf = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.facturano = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fecha_emision = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fecha_pago = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dias_sin_pagar = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.status_pago = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.foliofeps = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.total_mer = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Numero_de_servicios = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Servicio_uno = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Servicio_dos = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Servicio_tres = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.button30 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.dgViewOposiciones = new System.Windows.Forms.DataGridView();
            this.opoCasoid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Feataca = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.opocasonumero = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.opomarcaimitadora = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.opoclase = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.oponombredelimitador = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.opoExpedienteimitador = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.opoFechapublicacion = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.opofechapresentacion = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.opoFechaInterponemosEscrito = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lCasoID = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.richTextBox4 = new System.Windows.Forms.RichTextBox();
            this.label40 = new System.Windows.Forms.Label();
            this.lCotaccorresponsal = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.lResponsable = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.rtCorreocontacto = new System.Windows.Forms.RichTextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.lCorresponsal = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.lReferencia = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.lTitular = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.lPais = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.lRegistro = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.lExpediente = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.lContacto = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.lCliente = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.lCasoNumero = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.label41 = new System.Windows.Forms.Label();
            this.cbIdiomaCliente = new System.Windows.Forms.ComboBox();
            this.tbEstatus_header = new System.Windows.Forms.TextBox();
            this.label61 = new System.Windows.Forms.Label();
            this.button39 = new System.Windows.Forms.Button();
            this.button38 = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.tbCasoNumero = new System.Windows.Forms.TextBox();
            this.tbCasoid = new System.Windows.Forms.TextBox();
            this.tbExpediente = new System.Windows.Forms.TextBox();
            this.tbRegistro = new System.Windows.Forms.TextBox();
            this.tbl_pais = new System.Windows.Forms.TextBox();
            this.tblCliente = new System.Windows.Forms.TextBox();
            this.tblTitular = new System.Windows.Forms.TextBox();
            this.tblCorresponsal = new System.Windows.Forms.TextBox();
            this.tblCotaccorresponsal = new System.Windows.Forms.TextBox();
            this.tblContacto = new System.Windows.Forms.TextBox();
            this.tblRefencia = new System.Windows.Forms.TextBox();
            this.label74 = new System.Windows.Forms.Label();
            this.rtbDDenominacion_general = new System.Windows.Forms.RichTextBox();
            this.tblResponsable = new System.Windows.Forms.TextBox();
            this.tbAvisoprueba = new System.Windows.Forms.TextBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.Ley = new System.Windows.Forms.ComboBox();
            this.tbDtipo = new System.Windows.Forms.ComboBox();
            this.dgVProductosheader = new System.Windows.Forms.DataGridView();
            this.casproductoidheader = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.claseheader = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.descripcionheader = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label78 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label77 = new System.Windows.Forms.Label();
            this.cbDTipomarca = new System.Windows.Forms.ComboBox();
            this.tbNumeroregistrointernacional = new System.Windows.Forms.TextBox();
            this.label39 = new System.Windows.Forms.Label();
            this.label76 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.tbFechaRegistrointernacional = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.tbEstatusfactura = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tbSubtipo1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.tbDSigpruebauso = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.tbDFechacarta = new System.Windows.Forms.TextBox();
            this.tbDFechavigencia = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.cbDIdioma = new System.Windows.Forms.ComboBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tbDFechaconcesion = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.tbclase = new System.Windows.Forms.TextBox();
            this.label56 = new System.Windows.Forms.Label();
            this.tbDNumeroReg = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.tbDExpediente = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tbDfecharecepcion = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.tbDFechainiciouso = new System.Windows.Forms.TextBox();
            this.cbDNoseausado = new System.Windows.Forms.CheckBox();
            this.label11 = new System.Windows.Forms.Label();
            this.tbSubtipo = new System.Windows.Forms.ComboBox();
            this.pbDimage = new System.Windows.Forms.PictureBox();
            this.tabcFDatosgenerales.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGVProductos)).BeginInit();
            this.tabPage3.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.tabPage7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgPlazos)).BeginInit();
            this.tabPage6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGV_docimentos_IMPI)).BeginInit();
            this.tabPage9.SuspendLayout();
            this.tabPage10.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tabPage11.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.tabPage12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgDocumentoselectronicos)).BeginInit();
            this.tabPage13.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.tabPage14.SuspendLayout();
            this.tabPage15.SuspendLayout();
            this.tabPage17.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgview_facturas)).BeginInit();
            this.tabPage8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgViewOposiciones)).BeginInit();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgVProductosheader)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbDimage)).BeginInit();
            this.SuspendLayout();
            // 
            // tabcFDatosgenerales
            // 
            this.tabcFDatosgenerales.Controls.Add(this.tabPage1);
            this.tabcFDatosgenerales.Controls.Add(this.tabPage2);
            this.tabcFDatosgenerales.Controls.Add(this.tabPage3);
            this.tabcFDatosgenerales.Controls.Add(this.tabPage4);
            this.tabcFDatosgenerales.Controls.Add(this.tabPage5);
            this.tabcFDatosgenerales.Controls.Add(this.tabPage7);
            this.tabcFDatosgenerales.Controls.Add(this.tabPage6);
            this.tabcFDatosgenerales.Controls.Add(this.tabPage9);
            this.tabcFDatosgenerales.Controls.Add(this.tabPage10);
            this.tabcFDatosgenerales.Controls.Add(this.tabPage11);
            this.tabcFDatosgenerales.Controls.Add(this.tabPage12);
            this.tabcFDatosgenerales.Controls.Add(this.tabPage13);
            this.tabcFDatosgenerales.Controls.Add(this.tabPage14);
            this.tabcFDatosgenerales.Controls.Add(this.tabPage15);
            this.tabcFDatosgenerales.Controls.Add(this.tabPage17);
            this.tabcFDatosgenerales.Controls.Add(this.tabPage8);
            this.tabcFDatosgenerales.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.tabcFDatosgenerales.Location = new System.Drawing.Point(0, 532);
            this.tabcFDatosgenerales.Name = "tabcFDatosgenerales";
            this.tabcFDatosgenerales.SelectedIndex = 0;
            this.tabcFDatosgenerales.Size = new System.Drawing.Size(1603, 475);
            this.tabcFDatosgenerales.TabIndex = 0;
            this.tabcFDatosgenerales.Resize += new System.EventHandler(this.tabcFDatosgenerales_Resize);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.button20);
            this.tabPage1.Controls.Add(this.button37);
            this.tabPage1.Controls.Add(this.rtbDLeyendasfiguras);
            this.tabPage1.Controls.Add(this.label15);
            this.tabPage1.Controls.Add(this.rtbDDenominacion);
            this.tabPage1.Controls.Add(this.label14);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1595, 449);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Datos Generales";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // button20
            // 
            this.button20.Location = new System.Drawing.Point(1091, 137);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(109, 23);
            this.button20.TabIndex = 177;
            this.button20.Text = "Eliminar imagen";
            this.button20.UseVisualStyleBackColor = true;
            this.button20.Click += new System.EventHandler(this.button20_Click);
            // 
            // button37
            // 
            this.button37.Location = new System.Drawing.Point(970, 137);
            this.button37.Name = "button37";
            this.button37.Size = new System.Drawing.Size(94, 23);
            this.button37.TabIndex = 72;
            this.button37.Text = "Cargar Imagen";
            this.button37.UseVisualStyleBackColor = true;
            this.button37.Click += new System.EventHandler(this.button37_Click);
            // 
            // rtbDLeyendasfiguras
            // 
            this.rtbDLeyendasfiguras.Location = new System.Drawing.Point(158, 142);
            this.rtbDLeyendasfiguras.Name = "rtbDLeyendasfiguras";
            this.rtbDLeyendasfiguras.Size = new System.Drawing.Size(641, 36);
            this.rtbDLeyendasfiguras.TabIndex = 30;
            this.rtbDLeyendasfiguras.Text = "";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(27, 142);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(98, 26);
            this.label15.TabIndex = 29;
            this.label15.Text = "Leyendas y figuras \r\nno reservables";
            // 
            // rtbDDenominacion
            // 
            this.rtbDDenominacion.Location = new System.Drawing.Point(158, 95);
            this.rtbDDenominacion.Name = "rtbDDenominacion";
            this.rtbDDenominacion.Size = new System.Drawing.Size(641, 39);
            this.rtbDDenominacion.TabIndex = 28;
            this.rtbDDenominacion.Text = "";
            this.rtbDDenominacion.TextChanged += new System.EventHandler(this.rtbDDenominacion_TextChanged);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(43, 98);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(75, 13);
            this.label14.TabIndex = 27;
            this.label14.Text = "Denominación";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.dGVProductos);
            this.tabPage2.Controls.Add(this.btModificaciones);
            this.tabPage2.Controls.Add(this.lProductosdelcaso);
            this.tabPage2.Controls.Add(this.lDescrip);
            this.tabPage2.Controls.Add(this.label58);
            this.tabPage2.Controls.Add(this.label16);
            this.tabPage2.Controls.Add(this.label57);
            this.tabPage2.Controls.Add(this.button7);
            this.tabPage2.Controls.Add(this.tbNumprod);
            this.tabPage2.Controls.Add(this.rtbDProductossidiomaorig);
            this.tabPage2.Controls.Add(this.button5);
            this.tabPage2.Controls.Add(this.rtDescripciondelproducto);
            this.tabPage2.Controls.Add(this.rtbdescripcionclase);
            this.tabPage2.Controls.Add(this.cbClasemarca);
            this.tabPage2.Controls.Add(this.label22);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1595, 449);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Productos / Servicios";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // dGVProductos
            // 
            this.dGVProductos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dGVProductos.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.casoproductoid,
            this.clasedescript,
            this.descripcionclase});
            this.dGVProductos.Location = new System.Drawing.Point(44, 169);
            this.dGVProductos.Name = "dGVProductos";
            this.dGVProductos.Size = new System.Drawing.Size(749, 210);
            this.dGVProductos.TabIndex = 33;
            this.dGVProductos.DoubleClick += new System.EventHandler(this.dGVProductos_DoubleClick);
            // 
            // casoproductoid
            // 
            this.casoproductoid.DividerWidth = 100;
            this.casoproductoid.FillWeight = 200F;
            this.casoproductoid.HeaderText = "casoproductoid";
            this.casoproductoid.MinimumWidth = 40;
            this.casoproductoid.Name = "casoproductoid";
            this.casoproductoid.Visible = false;
            this.casoproductoid.Width = 105;
            // 
            // clasedescript
            // 
            this.clasedescript.FillWeight = 200F;
            this.clasedescript.HeaderText = "Clase";
            this.clasedescript.MinimumWidth = 40;
            this.clasedescript.Name = "clasedescript";
            // 
            // descripcionclase
            // 
            this.descripcionclase.FillWeight = 200F;
            this.descripcionclase.HeaderText = "Descripción";
            this.descripcionclase.MinimumWidth = 40;
            this.descripcionclase.Name = "descripcionclase";
            this.descripcionclase.Width = 600;
            // 
            // btModificaciones
            // 
            this.btModificaciones.Enabled = false;
            this.btModificaciones.Font = new System.Drawing.Font("Cambria", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btModificaciones.Location = new System.Drawing.Point(877, 103);
            this.btModificaciones.Name = "btModificaciones";
            this.btModificaciones.Size = new System.Drawing.Size(82, 38);
            this.btModificaciones.TabIndex = 14;
            this.btModificaciones.Text = "Guardar \r\nmodificaciones";
            this.btModificaciones.UseVisualStyleBackColor = true;
            this.btModificaciones.Click += new System.EventHandler(this.button3_Click_1);
            // 
            // lProductosdelcaso
            // 
            this.lProductosdelcaso.AutoSize = true;
            this.lProductosdelcaso.Location = new System.Drawing.Point(47, 153);
            this.lProductosdelcaso.Name = "lProductosdelcaso";
            this.lProductosdelcaso.Size = new System.Drawing.Size(101, 13);
            this.lProductosdelcaso.TabIndex = 13;
            this.lProductosdelcaso.Text = "Productos del caso:";
            // 
            // lDescrip
            // 
            this.lDescrip.AutoSize = true;
            this.lDescrip.Location = new System.Drawing.Point(41, 84);
            this.lDescrip.Name = "lDescrip";
            this.lDescrip.Size = new System.Drawing.Size(125, 13);
            this.lDescrip.TabIndex = 12;
            this.lDescrip.Text = "Descripción del producto";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(20, 30);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(143, 13);
            this.label58.TabIndex = 11;
            this.label58.Text = "Seleccione la clase deseada";
            this.label58.Click += new System.EventHandler(this.label58_Click);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(824, 153);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(91, 26);
            this.label16.TabIndex = 32;
            this.label16.Text = "Productos idioma \r\noriginal";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(202, 14);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(191, 13);
            this.label57.TabIndex = 10;
            this.label57.Text = "Encabezado de la clasificación de niza";
            // 
            // button7
            // 
            this.button7.Font = new System.Drawing.Font("Cambria", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.Location = new System.Drawing.Point(979, 111);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(62, 23);
            this.button7.TabIndex = 9;
            this.button7.Text = "Eliminar";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // tbNumprod
            // 
            this.tbNumprod.Location = new System.Drawing.Point(12, 161);
            this.tbNumprod.Name = "tbNumprod";
            this.tbNumprod.ReadOnly = true;
            this.tbNumprod.Size = new System.Drawing.Size(29, 20);
            this.tbNumprod.TabIndex = 8;
            this.tbNumprod.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // rtbDProductossidiomaorig
            // 
            this.rtbDProductossidiomaorig.Location = new System.Drawing.Point(816, 182);
            this.rtbDProductossidiomaorig.Name = "rtbDProductossidiomaorig";
            this.rtbDProductossidiomaorig.Size = new System.Drawing.Size(601, 197);
            this.rtbDProductossidiomaorig.TabIndex = 31;
            this.rtbDProductossidiomaorig.Text = "";
            // 
            // button5
            // 
            this.button5.Font = new System.Drawing.Font("Cambria", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.Location = new System.Drawing.Point(799, 94);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(62, 56);
            this.button5.TabIndex = 6;
            this.button5.Text = "Agregar \r\nProducto ó \r\nservicio";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // rtDescripciondelproducto
            // 
            this.rtDescripciondelproducto.Location = new System.Drawing.Point(44, 100);
            this.rtDescripciondelproducto.Name = "rtDescripciondelproducto";
            this.rtDescripciondelproducto.Size = new System.Drawing.Size(749, 50);
            this.rtDescripciondelproducto.TabIndex = 3;
            this.rtDescripciondelproducto.Text = "";
            // 
            // rtbdescripcionclase
            // 
            this.rtbdescripcionclase.Location = new System.Drawing.Point(205, 30);
            this.rtbdescripcionclase.Name = "rtbdescripcionclase";
            this.rtbdescripcionclase.ReadOnly = true;
            this.rtbdescripcionclase.Size = new System.Drawing.Size(1016, 48);
            this.rtbdescripcionclase.TabIndex = 2;
            this.rtbdescripcionclase.Text = "";
            // 
            // cbClasemarca
            // 
            this.cbClasemarca.FormattingEnabled = true;
            this.cbClasemarca.Location = new System.Drawing.Point(78, 57);
            this.cbClasemarca.Name = "cbClasemarca";
            this.cbClasemarca.Size = new System.Drawing.Size(77, 21);
            this.cbClasemarca.TabIndex = 1;
            this.cbClasemarca.SelectedIndexChanged += new System.EventHandler(this.cbClasemarca_SelectedIndexChanged);
            this.cbClasemarca.TextChanged += new System.EventHandler(this.cbClasemarca_TextChanged);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(36, 60);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(33, 13);
            this.label22.TabIndex = 0;
            this.label22.Text = "Clase";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.groupBox1);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1595, 449);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Referencias";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.tb_contdocelect);
            this.groupBox1.Controls.Add(this.lvReferencias);
            this.groupBox1.Controls.Add(this.button8);
            this.groupBox1.Controls.Add(this.button9);
            this.groupBox1.Controls.Add(this.tb_referencia);
            this.groupBox1.Controls.Add(this.label42);
            this.groupBox1.Controls.Add(this.cbTiporeferencia);
            this.groupBox1.Controls.Add(this.label43);
            this.groupBox1.Location = new System.Drawing.Point(80, 25);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1071, 319);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Referencias";
            // 
            // tb_contdocelect
            // 
            this.tb_contdocelect.Location = new System.Drawing.Point(939, 173);
            this.tb_contdocelect.Name = "tb_contdocelect";
            this.tb_contdocelect.ReadOnly = true;
            this.tb_contdocelect.Size = new System.Drawing.Size(50, 20);
            this.tb_contdocelect.TabIndex = 7;
            // 
            // lvReferencias
            // 
            this.lvReferencias.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader17,
            this.columnHeader18});
            this.lvReferencias.FullRowSelect = true;
            this.lvReferencias.GridLines = true;
            this.lvReferencias.HideSelection = false;
            this.lvReferencias.Location = new System.Drawing.Point(31, 101);
            this.lvReferencias.Name = "lvReferencias";
            this.lvReferencias.Size = new System.Drawing.Size(808, 195);
            this.lvReferencias.TabIndex = 6;
            this.lvReferencias.UseCompatibleStateImageBehavior = false;
            this.lvReferencias.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader17
            // 
            this.columnHeader17.Text = "Tipo";
            this.columnHeader17.Width = 226;
            // 
            // columnHeader18
            // 
            this.columnHeader18.Text = "Referencia";
            this.columnHeader18.Width = 571;
            // 
            // button8
            // 
            this.button8.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button8.BackgroundImage")));
            this.button8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button8.Location = new System.Drawing.Point(939, 243);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(50, 53);
            this.button8.TabIndex = 5;
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button9
            // 
            this.button9.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button9.BackgroundImage")));
            this.button9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button9.Location = new System.Drawing.Point(939, 101);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(50, 45);
            this.button9.TabIndex = 4;
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // tb_referencia
            // 
            this.tb_referencia.Location = new System.Drawing.Point(477, 38);
            this.tb_referencia.Name = "tb_referencia";
            this.tb_referencia.Size = new System.Drawing.Size(242, 20);
            this.tb_referencia.TabIndex = 3;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(357, 45);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(59, 13);
            this.label42.TabIndex = 2;
            this.label42.Text = "Referencia";
            // 
            // cbTiporeferencia
            // 
            this.cbTiporeferencia.FormattingEnabled = true;
            this.cbTiporeferencia.Location = new System.Drawing.Point(94, 37);
            this.cbTiporeferencia.Name = "cbTiporeferencia";
            this.cbTiporeferencia.Size = new System.Drawing.Size(176, 21);
            this.cbTiporeferencia.TabIndex = 1;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(28, 40);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(28, 13);
            this.label43.TabIndex = 0;
            this.label43.Text = "Tipo";
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.button40);
            this.tabPage4.Controls.Add(this.button11);
            this.tabPage4.Controls.Add(this.button10);
            this.tabPage4.Controls.Add(this.button12);
            this.tabPage4.Controls.Add(this.button13);
            this.tabPage4.Controls.Add(this.lvinteresados);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(1595, 449);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Interesados";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // button40
            // 
            this.button40.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button40.Location = new System.Drawing.Point(93, 16);
            this.button40.Name = "button40";
            this.button40.Size = new System.Drawing.Size(73, 31);
            this.button40.TabIndex = 10;
            this.button40.Text = "Agregar \r\nInteresado\r\nExistente";
            this.button40.UseVisualStyleBackColor = true;
            this.button40.Click += new System.EventHandler(this.button40_Click);
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(331, 16);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(75, 31);
            this.button11.TabIndex = 9;
            this.button11.Text = "Actualizar";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(251, 16);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(75, 31);
            this.button10.TabIndex = 8;
            this.button10.Text = "Eliminar";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(171, 16);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(75, 31);
            this.button12.TabIndex = 7;
            this.button12.Text = "Nuevo Interesado";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click_1);
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(13, 16);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(75, 31);
            this.button13.TabIndex = 6;
            this.button13.Text = "ver \r\ninteresado";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // lvinteresados
            // 
            this.lvinteresados.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader19,
            this.columnHeader20,
            this.columnHeader21,
            this.columnHeader22,
            this.columnHeader23,
            this.columnHeader24,
            this.columnHeader25,
            this.tipopersona});
            this.lvinteresados.GridLines = true;
            this.lvinteresados.HideSelection = false;
            this.lvinteresados.Location = new System.Drawing.Point(13, 53);
            this.lvinteresados.Name = "lvinteresados";
            this.lvinteresados.Size = new System.Drawing.Size(1279, 409);
            this.lvinteresados.TabIndex = 5;
            this.lvinteresados.UseCompatibleStateImageBehavior = false;
            this.lvinteresados.View = System.Windows.Forms.View.Details;
            this.lvinteresados.SelectedIndexChanged += new System.EventHandler(this.lvinteresados_SelectedIndexChanged);
            this.lvinteresados.DoubleClick += new System.EventHandler(this.lvinteresados_DoubleClick);
            // 
            // columnHeader19
            // 
            this.columnHeader19.Text = "Relación";
            this.columnHeader19.Width = 63;
            // 
            // columnHeader20
            // 
            this.columnHeader20.Text = "ID";
            this.columnHeader20.Width = 47;
            // 
            // columnHeader21
            // 
            this.columnHeader21.Text = "Nombre";
            this.columnHeader21.Width = 136;
            // 
            // columnHeader22
            // 
            this.columnHeader22.Text = "Nacionalidad";
            this.columnHeader22.Width = 195;
            // 
            // columnHeader23
            // 
            this.columnHeader23.Text = "Domicilio";
            this.columnHeader23.Width = 234;
            // 
            // columnHeader24
            // 
            this.columnHeader24.Text = "Original del poder";
            this.columnHeader24.Width = 175;
            // 
            // columnHeader25
            // 
            this.columnHeader25.Text = "RGP";
            this.columnHeader25.Width = 133;
            // 
            // tipopersona
            // 
            this.tipopersona.Text = "Tipo de Persona";
            this.tipopersona.Width = 98;
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.button14);
            this.tabPage5.Controls.Add(this.label88);
            this.tabPage5.Controls.Add(this.label89);
            this.tabPage5.Controls.Add(this.label79);
            this.tabPage5.Controls.Add(this.rtNumprio);
            this.tabPage5.Controls.Add(this.tbCvepais);
            this.tabPage5.Controls.Add(this.tbfechaprio);
            this.tabPage5.Controls.Add(this.tbNumeroprio);
            this.tabPage5.Controls.Add(this.button3);
            this.tabPage5.Controls.Add(this.button4);
            this.tabPage5.Controls.Add(this.cbTiposolprio);
            this.tabPage5.Controls.Add(this.label46);
            this.tabPage5.Controls.Add(this.cbNombrepais);
            this.tabPage5.Controls.Add(this.label45);
            this.tabPage5.Controls.Add(this.label44);
            this.tabPage5.Controls.Add(this.label5);
            this.tabPage5.Controls.Add(this.bEliminarprioridades);
            this.tabPage5.Controls.Add(this.lvPrioridades);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(1595, 449);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Prioridades";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // button14
            // 
            this.button14.BackgroundImage = global::Facturador.Properties.Resources.mas;
            this.button14.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button14.Location = new System.Drawing.Point(1152, 127);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(36, 36);
            this.button14.TabIndex = 84;
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.label88.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label88.Location = new System.Drawing.Point(1198, 244);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(58, 26);
            this.label88.TabIndex = 83;
            this.label88.Text = "Eliminar \r\nprioridades";
            this.label88.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label89
            // 
            this.label89.AutoSize = true;
            this.label89.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label89.Location = new System.Drawing.Point(1194, 137);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(59, 26);
            this.label89.TabIndex = 82;
            this.label89.Text = "Agregar \r\nPrioridades";
            this.label89.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label79.Location = new System.Drawing.Point(464, 86);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(66, 12);
            this.label79.TabIndex = 81;
            this.label79.Text = "día / mes  /Año";
            // 
            // rtNumprio
            // 
            this.rtNumprio.Location = new System.Drawing.Point(1193, 336);
            this.rtNumprio.Name = "rtNumprio";
            this.rtNumprio.ReadOnly = true;
            this.rtNumprio.Size = new System.Drawing.Size(25, 28);
            this.rtNumprio.TabIndex = 80;
            this.rtNumprio.Text = "";
            // 
            // tbCvepais
            // 
            this.tbCvepais.Location = new System.Drawing.Point(606, 65);
            this.tbCvepais.Name = "tbCvepais";
            this.tbCvepais.ReadOnly = true;
            this.tbCvepais.Size = new System.Drawing.Size(34, 20);
            this.tbCvepais.TabIndex = 74;
            // 
            // tbfechaprio
            // 
            this.tbfechaprio.Location = new System.Drawing.Point(445, 63);
            this.tbfechaprio.Name = "tbfechaprio";
            this.tbfechaprio.Size = new System.Drawing.Size(88, 20);
            this.tbfechaprio.TabIndex = 72;
            this.tbfechaprio.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbfechaprio.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbfechaprio_KeyPress);
            this.tbfechaprio.MouseLeave += new System.EventHandler(this.tbfechaprio_MouseLeave);
            this.tbfechaprio.Validating += new System.ComponentModel.CancelEventHandler(this.tbfechaprio_Validating);
            // 
            // tbNumeroprio
            // 
            this.tbNumeroprio.Location = new System.Drawing.Point(122, 63);
            this.tbNumeroprio.Name = "tbNumeroprio";
            this.tbNumeroprio.Size = new System.Drawing.Size(248, 20);
            this.tbNumeroprio.TabIndex = 70;
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(1152, 49);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(88, 37);
            this.button3.TabIndex = 79;
            this.button3.Text = "Guardar\r\nModificaciones";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click_2);
            // 
            // button4
            // 
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Location = new System.Drawing.Point(1162, 13);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(56, 23);
            this.button4.TabIndex = 78;
            this.button4.Text = "Limpiar";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click_1);
            // 
            // cbTiposolprio
            // 
            this.cbTiposolprio.FormattingEnabled = true;
            this.cbTiposolprio.Location = new System.Drawing.Point(1031, 65);
            this.cbTiposolprio.Name = "cbTiposolprio";
            this.cbTiposolprio.Size = new System.Drawing.Size(97, 21);
            this.cbTiposolprio.TabIndex = 77;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label46.Location = new System.Drawing.Point(992, 68);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(31, 15);
            this.label46.TabIndex = 76;
            this.label46.Text = "Tipo";
            // 
            // cbNombrepais
            // 
            this.cbNombrepais.FormattingEnabled = true;
            this.cbNombrepais.Location = new System.Drawing.Point(655, 65);
            this.cbNombrepais.Name = "cbNombrepais";
            this.cbNombrepais.Size = new System.Drawing.Size(280, 21);
            this.cbNombrepais.TabIndex = 75;
            this.cbNombrepais.SelectedIndexChanged += new System.EventHandler(this.cbNombrepais_SelectedIndexChanged);
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.Location = new System.Drawing.Point(559, 66);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(31, 15);
            this.label45.TabIndex = 73;
            this.label45.Text = "País";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.Location = new System.Drawing.Point(388, 66);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(41, 15);
            this.label44.TabIndex = 71;
            this.label44.Text = "Fecha";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(64, 66);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(52, 15);
            this.label5.TabIndex = 69;
            this.label5.Text = "Número";
            // 
            // bEliminarprioridades
            // 
            this.bEliminarprioridades.BackgroundImage = global::Facturador.Properties.Resources._16494;
            this.bEliminarprioridades.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.bEliminarprioridades.Location = new System.Drawing.Point(1155, 239);
            this.bEliminarprioridades.Name = "bEliminarprioridades";
            this.bEliminarprioridades.Size = new System.Drawing.Size(33, 31);
            this.bEliminarprioridades.TabIndex = 85;
            this.bEliminarprioridades.UseVisualStyleBackColor = true;
            this.bEliminarprioridades.Click += new System.EventHandler(this.bEliminarprioridades_Click);
            // 
            // lvPrioridades
            // 
            this.lvPrioridades.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.idPrioridad,
            this.numeroprioridad,
            this.fechaprioridad,
            this.clavepais,
            this.pais,
            this.Tipoprioridad});
            this.lvPrioridades.FullRowSelect = true;
            this.lvPrioridades.GridLines = true;
            this.lvPrioridades.HideSelection = false;
            this.lvPrioridades.Location = new System.Drawing.Point(67, 101);
            this.lvPrioridades.MultiSelect = false;
            this.lvPrioridades.Name = "lvPrioridades";
            this.lvPrioridades.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lvPrioridades.Size = new System.Drawing.Size(1061, 370);
            this.lvPrioridades.TabIndex = 68;
            this.lvPrioridades.UseCompatibleStateImageBehavior = false;
            this.lvPrioridades.View = System.Windows.Forms.View.Details;
            this.lvPrioridades.DoubleClick += new System.EventHandler(this.lvPrioridades_DoubleClick);
            // 
            // idPrioridad
            // 
            this.idPrioridad.Text = "Id Prioridad";
            this.idPrioridad.Width = 73;
            // 
            // numeroprioridad
            // 
            this.numeroprioridad.Text = "Número";
            this.numeroprioridad.Width = 205;
            // 
            // fechaprioridad
            // 
            this.fechaprioridad.Text = "Fecha";
            this.fechaprioridad.Width = 121;
            // 
            // clavepais
            // 
            this.clavepais.Text = "Clave País";
            this.clavepais.Width = 84;
            // 
            // pais
            // 
            this.pais.Text = "País";
            this.pais.Width = 397;
            // 
            // Tipoprioridad
            // 
            this.Tipoprioridad.Text = "Tipo";
            this.Tipoprioridad.Width = 175;
            // 
            // tabPage7
            // 
            this.tabPage7.Controls.Add(this.button16);
            this.tabPage7.Controls.Add(this.bAgregarplazo);
            this.tabPage7.Controls.Add(this.label59);
            this.tabPage7.Controls.Add(this.label60);
            this.tabPage7.Controls.Add(this.label62);
            this.tabPage7.Controls.Add(this.tbDSigpruebauso_plazos);
            this.tabPage7.Controls.Add(this.label63);
            this.tabPage7.Controls.Add(this.tbDFechavigencia_plazos);
            this.tabPage7.Controls.Add(this.label72);
            this.tabPage7.Controls.Add(this.tbDfecharecepcion_plazos);
            this.tabPage7.Controls.Add(this.label73);
            this.tabPage7.Controls.Add(this.button46);
            this.tabPage7.Controls.Add(this.button45);
            this.tabPage7.Controls.Add(this.dgPlazos);
            this.tabPage7.Controls.Add(this.button21);
            this.tabPage7.Controls.Add(this.lvPlazos);
            this.tabPage7.Location = new System.Drawing.Point(4, 22);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage7.Size = new System.Drawing.Size(1595, 449);
            this.tabPage7.TabIndex = 6;
            this.tabPage7.Text = "Plazos";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // button16
            // 
            this.button16.Location = new System.Drawing.Point(1189, 37);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(102, 23);
            this.button16.TabIndex = 82;
            this.button16.Text = "Eliminar plazo";
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Click += new System.EventHandler(this.button16_Click);
            // 
            // bAgregarplazo
            // 
            this.bAgregarplazo.Location = new System.Drawing.Point(12, 24);
            this.bAgregarplazo.Name = "bAgregarplazo";
            this.bAgregarplazo.Size = new System.Drawing.Size(116, 23);
            this.bAgregarplazo.TabIndex = 81;
            this.bAgregarplazo.Text = "Agregar plazo";
            this.bAgregarplazo.UseVisualStyleBackColor = true;
            this.bAgregarplazo.Visible = false;
            this.bAgregarplazo.Click += new System.EventHandler(this.bAgregarplazo_Click);
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label59.Location = new System.Drawing.Point(765, 47);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(66, 12);
            this.label59.TabIndex = 80;
            this.label59.Text = "día / mes  /Año";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label60.Location = new System.Drawing.Point(506, 46);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(66, 12);
            this.label60.TabIndex = 79;
            this.label60.Text = "día / mes  /Año";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label62.Location = new System.Drawing.Point(269, 43);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(66, 12);
            this.label62.TabIndex = 78;
            this.label62.Text = "día / mes  /Año";
            // 
            // tbDSigpruebauso_plazos
            // 
            this.tbDSigpruebauso_plazos.Location = new System.Drawing.Point(748, 24);
            this.tbDSigpruebauso_plazos.Name = "tbDSigpruebauso_plazos";
            this.tbDSigpruebauso_plazos.ReadOnly = true;
            this.tbDSigpruebauso_plazos.Size = new System.Drawing.Size(100, 20);
            this.tbDSigpruebauso_plazos.TabIndex = 77;
            this.tbDSigpruebauso_plazos.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Location = new System.Drawing.Point(646, 27);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(78, 13);
            this.label63.TabIndex = 76;
            this.label63.Text = "Sig. Decla Uso";
            // 
            // tbDFechavigencia_plazos
            // 
            this.tbDFechavigencia_plazos.Location = new System.Drawing.Point(488, 23);
            this.tbDFechavigencia_plazos.Name = "tbDFechavigencia_plazos";
            this.tbDFechavigencia_plazos.ReadOnly = true;
            this.tbDFechavigencia_plazos.Size = new System.Drawing.Size(100, 20);
            this.tbDFechavigencia_plazos.TabIndex = 75;
            this.tbDFechavigencia_plazos.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Location = new System.Drawing.Point(389, 26);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(81, 13);
            this.label72.TabIndex = 74;
            this.label72.Text = "Fecha Vigencia";
            // 
            // tbDfecharecepcion_plazos
            // 
            this.tbDfecharecepcion_plazos.Location = new System.Drawing.Point(252, 20);
            this.tbDfecharecepcion_plazos.Name = "tbDfecharecepcion_plazos";
            this.tbDfecharecepcion_plazos.ReadOnly = true;
            this.tbDfecharecepcion_plazos.Size = new System.Drawing.Size(100, 20);
            this.tbDfecharecepcion_plazos.TabIndex = 73;
            this.tbDfecharecepcion_plazos.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Location = new System.Drawing.Point(154, 26);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(92, 13);
            this.label73.TabIndex = 72;
            this.label73.Text = "Fecha Recepción";
            // 
            // button46
            // 
            this.button46.Location = new System.Drawing.Point(869, 38);
            this.button46.Name = "button46";
            this.button46.Size = new System.Drawing.Size(75, 23);
            this.button46.TabIndex = 9;
            this.button46.Text = "Subir correo";
            this.button46.UseVisualStyleBackColor = true;
            this.button46.Click += new System.EventHandler(this.button46_Click);
            // 
            // button45
            // 
            this.button45.Location = new System.Drawing.Point(1081, 24);
            this.button45.Name = "button45";
            this.button45.Size = new System.Drawing.Size(102, 37);
            this.button45.TabIndex = 7;
            this.button45.Text = "Atender o Cancelar plazo";
            this.button45.UseVisualStyleBackColor = true;
            this.button45.Click += new System.EventHandler(this.button45_Click);
            // 
            // dgPlazos
            // 
            this.dgPlazos.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgPlazos.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgPlazos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgPlazos.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.plazoid,
            this.plazosidetalle,
            this.usuario_id_plazo_impi,
            this.documentoid,
            this.documentodescrip,
            this.tipoplazoid,
            this.tipoplazodescrip,
            this.estatusplazouno,
            this.fechaplazo,
            this.fechavencimientoplazouno,
            this.fechaprorrogaplazouno,
            this.fechavencimiento4meses,
            this.fechaatendioplazouno,
            this.Usuarioid_atendio_plazo_impi,
            this.sDoc_atendio,
            this.motivocancelaciondesc,
            this.fechacancelacionimpi,
            this.usuariocancelo});
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgPlazos.DefaultCellStyle = dataGridViewCellStyle8;
            this.dgPlazos.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dgPlazos.Location = new System.Drawing.Point(3, 133);
            this.dgPlazos.Name = "dgPlazos";
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgPlazos.RowHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.dgPlazos.RowHeadersWidth = 62;
            this.dgPlazos.Size = new System.Drawing.Size(1589, 313);
            this.dgPlazos.TabIndex = 6;
            // 
            // plazoid
            // 
            this.plazoid.HeaderText = "Plazo id ";
            this.plazoid.MinimumWidth = 8;
            this.plazoid.Name = "plazoid";
            this.plazoid.Width = 40;
            // 
            // plazosidetalle
            // 
            this.plazosidetalle.HeaderText = "plazosdetalleid";
            this.plazosidetalle.MinimumWidth = 8;
            this.plazosidetalle.Name = "plazosidetalle";
            this.plazosidetalle.Visible = false;
            this.plazosidetalle.Width = 150;
            // 
            // usuario_id_plazo_impi
            // 
            this.usuario_id_plazo_impi.HeaderText = "Capturó";
            this.usuario_id_plazo_impi.MinimumWidth = 8;
            this.usuario_id_plazo_impi.Name = "usuario_id_plazo_impi";
            this.usuario_id_plazo_impi.Width = 50;
            // 
            // documentoid
            // 
            this.documentoid.HeaderText = "documentoid";
            this.documentoid.MinimumWidth = 8;
            this.documentoid.Name = "documentoid";
            this.documentoid.Visible = false;
            this.documentoid.Width = 150;
            // 
            // documentodescrip
            // 
            this.documentodescrip.HeaderText = "Documento";
            this.documentodescrip.MinimumWidth = 8;
            this.documentodescrip.Name = "documentodescrip";
            this.documentodescrip.ReadOnly = true;
            this.documentodescrip.Width = 200;
            // 
            // tipoplazoid
            // 
            this.tipoplazoid.HeaderText = "tipoplazoid";
            this.tipoplazoid.MinimumWidth = 8;
            this.tipoplazoid.Name = "tipoplazoid";
            this.tipoplazoid.Visible = false;
            this.tipoplazoid.Width = 150;
            // 
            // tipoplazodescrip
            // 
            this.tipoplazodescrip.HeaderText = "Tipo plazo";
            this.tipoplazodescrip.MinimumWidth = 8;
            this.tipoplazodescrip.Name = "tipoplazodescrip";
            this.tipoplazodescrip.Width = 200;
            // 
            // estatusplazouno
            // 
            this.estatusplazouno.HeaderText = "Estatus plazo";
            this.estatusplazouno.MinimumWidth = 8;
            this.estatusplazouno.Name = "estatusplazouno";
            this.estatusplazouno.Width = 70;
            // 
            // fechaplazo
            // 
            dataGridViewCellStyle2.Format = "d";
            dataGridViewCellStyle2.NullValue = null;
            this.fechaplazo.DefaultCellStyle = dataGridViewCellStyle2;
            this.fechaplazo.HeaderText = "Fecha Notificación";
            this.fechaplazo.MinimumWidth = 8;
            this.fechaplazo.Name = "fechaplazo";
            this.fechaplazo.ReadOnly = true;
            this.fechaplazo.Width = 150;
            // 
            // fechavencimientoplazouno
            // 
            dataGridViewCellStyle3.Format = "d";
            dataGridViewCellStyle3.NullValue = null;
            this.fechavencimientoplazouno.DefaultCellStyle = dataGridViewCellStyle3;
            this.fechavencimientoplazouno.HeaderText = "Fecha Vencimiento Regular";
            this.fechavencimientoplazouno.MinimumWidth = 8;
            this.fechavencimientoplazouno.Name = "fechavencimientoplazouno";
            this.fechavencimientoplazouno.ReadOnly = true;
            this.fechavencimientoplazouno.Width = 150;
            // 
            // fechaprorrogaplazouno
            // 
            dataGridViewCellStyle4.Format = "d";
            this.fechaprorrogaplazouno.DefaultCellStyle = dataGridViewCellStyle4;
            this.fechaprorrogaplazouno.HeaderText = "Fecha Vencimiento 3 meses";
            this.fechaprorrogaplazouno.MinimumWidth = 8;
            this.fechaprorrogaplazouno.Name = "fechaprorrogaplazouno";
            this.fechaprorrogaplazouno.ReadOnly = true;
            this.fechaprorrogaplazouno.Width = 150;
            // 
            // fechavencimiento4meses
            // 
            dataGridViewCellStyle5.Format = "d";
            this.fechavencimiento4meses.DefaultCellStyle = dataGridViewCellStyle5;
            this.fechavencimiento4meses.HeaderText = "Fecha Vencimineto 4 meses";
            this.fechavencimiento4meses.MinimumWidth = 8;
            this.fechavencimiento4meses.Name = "fechavencimiento4meses";
            this.fechavencimiento4meses.Width = 150;
            // 
            // fechaatendioplazouno
            // 
            dataGridViewCellStyle6.Format = "d";
            this.fechaatendioplazouno.DefaultCellStyle = dataGridViewCellStyle6;
            this.fechaatendioplazouno.HeaderText = "Fecha atendió plazo";
            this.fechaatendioplazouno.MinimumWidth = 8;
            this.fechaatendioplazouno.Name = "fechaatendioplazouno";
            this.fechaatendioplazouno.ReadOnly = true;
            this.fechaatendioplazouno.Width = 150;
            // 
            // Usuarioid_atendio_plazo_impi
            // 
            this.Usuarioid_atendio_plazo_impi.HeaderText = "Usuario atendió plazo";
            this.Usuarioid_atendio_plazo_impi.MinimumWidth = 8;
            this.Usuarioid_atendio_plazo_impi.Name = "Usuarioid_atendio_plazo_impi";
            this.Usuarioid_atendio_plazo_impi.Width = 150;
            // 
            // sDoc_atendio
            // 
            this.sDoc_atendio.HeaderText = "Documento Atendió";
            this.sDoc_atendio.MinimumWidth = 8;
            this.sDoc_atendio.Name = "sDoc_atendio";
            this.sDoc_atendio.Width = 150;
            // 
            // motivocancelaciondesc
            // 
            this.motivocancelaciondesc.HeaderText = "Motivo Canelación Plazo";
            this.motivocancelaciondesc.MinimumWidth = 8;
            this.motivocancelaciondesc.Name = "motivocancelaciondesc";
            this.motivocancelaciondesc.Width = 150;
            // 
            // fechacancelacionimpi
            // 
            dataGridViewCellStyle7.Format = "d";
            this.fechacancelacionimpi.DefaultCellStyle = dataGridViewCellStyle7;
            this.fechacancelacionimpi.HeaderText = "Fecha Cancelación Plazo";
            this.fechacancelacionimpi.MinimumWidth = 8;
            this.fechacancelacionimpi.Name = "fechacancelacionimpi";
            this.fechacancelacionimpi.Width = 150;
            // 
            // usuariocancelo
            // 
            this.usuariocancelo.HeaderText = "Usuario canceló";
            this.usuariocancelo.MinimumWidth = 8;
            this.usuariocancelo.Name = "usuariocancelo";
            this.usuariocancelo.Width = 150;
            // 
            // button21
            // 
            this.button21.BackgroundImage = global::Facturador.Properties.Resources.descarga;
            this.button21.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button21.Location = new System.Drawing.Point(965, 21);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(48, 40);
            this.button21.TabIndex = 5;
            this.button21.UseVisualStyleBackColor = true;
            this.button21.Click += new System.EventHandler(this.button21_Click);
            // 
            // lvPlazos
            // 
            this.lvPlazos.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader5,
            this.columnHeader6,
            this.columnHeader7,
            this.columnHeader8,
            this.columnHeader9,
            this.columnHeader10,
            this.columnHeader11,
            this.columnHeader12,
            this.columnHeader13,
            this.columnHeader14,
            this.columnHeader15,
            this.columnHeader16});
            this.lvPlazos.HideSelection = false;
            this.lvPlazos.Location = new System.Drawing.Point(1274, 15);
            this.lvPlazos.Name = "lvPlazos";
            this.lvPlazos.Size = new System.Drawing.Size(14, 17);
            this.lvPlazos.TabIndex = 3;
            this.lvPlazos.UseCompatibleStateImageBehavior = false;
            this.lvPlazos.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Plazoid";
            this.columnHeader1.Width = 52;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Capturó";
            this.columnHeader2.Width = 53;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Tipo de Plazo";
            this.columnHeader3.Width = 81;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Descripción tarea";
            this.columnHeader4.Width = 105;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Documento";
            this.columnHeader5.Width = 75;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Notificado en";
            this.columnHeader6.Width = 81;
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "Vencimiento Original";
            this.columnHeader7.Width = 84;
            // 
            // columnHeader8
            // 
            this.columnHeader8.Text = "Fecha Escrito";
            this.columnHeader8.Width = 90;
            // 
            // columnHeader9
            // 
            this.columnHeader9.Text = "Aviso cliente";
            this.columnHeader9.Width = 83;
            // 
            // columnHeader10
            // 
            this.columnHeader10.Text = "Estatus";
            // 
            // columnHeader11
            // 
            this.columnHeader11.Text = "Mes";
            this.columnHeader11.Width = 46;
            // 
            // columnHeader12
            // 
            this.columnHeader12.Text = "Plazo Final";
            this.columnHeader12.Width = 78;
            // 
            // columnHeader13
            // 
            this.columnHeader13.Text = "Fecha atención";
            this.columnHeader13.Width = 99;
            // 
            // columnHeader14
            // 
            this.columnHeader14.Text = "Fecha prorroga";
            this.columnHeader14.Width = 95;
            // 
            // columnHeader15
            // 
            this.columnHeader15.Text = "Prorrogó o canceló";
            this.columnHeader15.Width = 111;
            // 
            // columnHeader16
            // 
            this.columnHeader16.Text = "Motivo cancelación";
            this.columnHeader16.Width = 112;
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.button22);
            this.tabPage6.Controls.Add(this.dGV_docimentos_IMPI);
            this.tabPage6.Controls.Add(this.lvdocumentosimpi);
            this.tabPage6.Controls.Add(this.button44);
            this.tabPage6.Controls.Add(this.button43);
            this.tabPage6.Controls.Add(this.button42);
            this.tabPage6.Controls.Add(this.button41);
            this.tabPage6.Controls.Add(this.button19);
            this.tabPage6.Controls.Add(this.checkBox2);
            this.tabPage6.Controls.Add(this.textBox19);
            this.tabPage6.Controls.Add(this.button18);
            this.tabPage6.Controls.Add(this.lvDocumentosmarcas);
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(1595, 449);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "Documentos IMPI";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // button22
            // 
            this.button22.Location = new System.Drawing.Point(1197, 26);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(75, 38);
            this.button22.TabIndex = 16;
            this.button22.Text = "Eliminar \r\nDocumento";
            this.button22.UseVisualStyleBackColor = true;
            this.button22.Click += new System.EventHandler(this.button22_Click);
            // 
            // dGV_docimentos_IMPI
            // 
            this.dGV_docimentos_IMPI.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dGV_docimentos_IMPI.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle10;
            this.dGV_docimentos_IMPI.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dGV_docimentos_IMPI.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.lnk,
            this.tipo_documento,
            this.cod_barras,
            this.folio,
            this.fecha_notificacion,
            this.vencimiento,
            this.vencimiento_3_meses,
            this.vencimiento_4_meses,
            this.mes_antiguedad_plazo,
            this.Fecha_Impi,
            this.escrito_doc,
            this.documento,
            this.estatus_documentos_impi,
            this.plazo_final,
            this.observacion_documento,
            this.aviso_cliente_documento,
            this.mot_cancelacion,
            this.usr_prorrogo,
            this.fecha_firma,
            this.documento_relacion,
            this.subtipodocumentoid_documento,
            this.documentoidmarcas});
            dataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle22.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle22.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle22.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle22.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle22.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle22.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dGV_docimentos_IMPI.DefaultCellStyle = dataGridViewCellStyle22;
            this.dGV_docimentos_IMPI.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dGV_docimentos_IMPI.Location = new System.Drawing.Point(3, 164);
            this.dGV_docimentos_IMPI.Name = "dGV_docimentos_IMPI";
            dataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle23.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle23.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle23.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle23.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle23.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle23.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dGV_docimentos_IMPI.RowHeadersDefaultCellStyle = dataGridViewCellStyle23;
            this.dGV_docimentos_IMPI.RowHeadersWidth = 62;
            this.dGV_docimentos_IMPI.Size = new System.Drawing.Size(1589, 282);
            this.dGV_docimentos_IMPI.TabIndex = 15;
            this.dGV_docimentos_IMPI.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dGV_docimentos_IMPI_CellContentClick);
            this.dGV_docimentos_IMPI.DoubleClick += new System.EventHandler(this.dGV_docimentos_IMPI_DoubleClick);
            // 
            // lnk
            // 
            this.lnk.HeaderText = "lnk";
            this.lnk.MinimumWidth = 8;
            this.lnk.Name = "lnk";
            this.lnk.Visible = false;
            this.lnk.Width = 150;
            // 
            // tipo_documento
            // 
            this.tipo_documento.HeaderText = "Tipo";
            this.tipo_documento.MinimumWidth = 8;
            this.tipo_documento.Name = "tipo_documento";
            this.tipo_documento.Width = 80;
            // 
            // cod_barras
            // 
            dataGridViewCellStyle11.Font = new System.Drawing.Font("Cambria", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cod_barras.DefaultCellStyle = dataGridViewCellStyle11;
            this.cod_barras.HeaderText = "CodBarras";
            this.cod_barras.MinimumWidth = 8;
            this.cod_barras.Name = "cod_barras";
            this.cod_barras.Width = 110;
            // 
            // folio
            // 
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Cambria", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.folio.DefaultCellStyle = dataGridViewCellStyle12;
            this.folio.HeaderText = "Folio";
            this.folio.MinimumWidth = 8;
            this.folio.Name = "folio";
            this.folio.Width = 110;
            // 
            // fecha_notificacion
            // 
            dataGridViewCellStyle13.Format = "d";
            this.fecha_notificacion.DefaultCellStyle = dataGridViewCellStyle13;
            this.fecha_notificacion.HeaderText = "Fecha Notificación";
            this.fecha_notificacion.MinimumWidth = 8;
            this.fecha_notificacion.Name = "fecha_notificacion";
            this.fecha_notificacion.Width = 150;
            // 
            // vencimiento
            // 
            dataGridViewCellStyle14.Format = "d";
            this.vencimiento.DefaultCellStyle = dataGridViewCellStyle14;
            this.vencimiento.HeaderText = "Vencimiento";
            this.vencimiento.MinimumWidth = 8;
            this.vencimiento.Name = "vencimiento";
            this.vencimiento.Width = 150;
            // 
            // vencimiento_3_meses
            // 
            dataGridViewCellStyle15.Format = "d";
            this.vencimiento_3_meses.DefaultCellStyle = dataGridViewCellStyle15;
            this.vencimiento_3_meses.HeaderText = "Vencimiento 3 Meses";
            this.vencimiento_3_meses.MinimumWidth = 8;
            this.vencimiento_3_meses.Name = "vencimiento_3_meses";
            this.vencimiento_3_meses.Visible = false;
            this.vencimiento_3_meses.Width = 150;
            // 
            // vencimiento_4_meses
            // 
            dataGridViewCellStyle16.Format = "d";
            this.vencimiento_4_meses.DefaultCellStyle = dataGridViewCellStyle16;
            this.vencimiento_4_meses.HeaderText = "Vencimiento 4 meses";
            this.vencimiento_4_meses.MinimumWidth = 8;
            this.vencimiento_4_meses.Name = "vencimiento_4_meses";
            this.vencimiento_4_meses.Width = 150;
            // 
            // mes_antiguedad_plazo
            // 
            this.mes_antiguedad_plazo.HeaderText = "Mes";
            this.mes_antiguedad_plazo.MinimumWidth = 8;
            this.mes_antiguedad_plazo.Name = "mes_antiguedad_plazo";
            this.mes_antiguedad_plazo.Width = 150;
            // 
            // Fecha_Impi
            // 
            dataGridViewCellStyle17.Format = "d";
            this.Fecha_Impi.DefaultCellStyle = dataGridViewCellStyle17;
            this.Fecha_Impi.HeaderText = "Fecha Impi";
            this.Fecha_Impi.MinimumWidth = 8;
            this.Fecha_Impi.Name = "Fecha_Impi";
            this.Fecha_Impi.Width = 150;
            // 
            // escrito_doc
            // 
            this.escrito_doc.HeaderText = "Escrito";
            this.escrito_doc.MinimumWidth = 8;
            this.escrito_doc.Name = "escrito_doc";
            this.escrito_doc.Width = 150;
            // 
            // documento
            // 
            dataGridViewCellStyle18.Font = new System.Drawing.Font("Cambria", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.documento.DefaultCellStyle = dataGridViewCellStyle18;
            this.documento.HeaderText = "Documento";
            this.documento.MinimumWidth = 8;
            this.documento.Name = "documento";
            this.documento.Width = 150;
            // 
            // estatus_documentos_impi
            // 
            this.estatus_documentos_impi.HeaderText = "Estatus";
            this.estatus_documentos_impi.MinimumWidth = 8;
            this.estatus_documentos_impi.Name = "estatus_documentos_impi";
            this.estatus_documentos_impi.Width = 150;
            // 
            // plazo_final
            // 
            dataGridViewCellStyle19.Format = "d";
            this.plazo_final.DefaultCellStyle = dataGridViewCellStyle19;
            this.plazo_final.HeaderText = "Plazo Final";
            this.plazo_final.MinimumWidth = 8;
            this.plazo_final.Name = "plazo_final";
            this.plazo_final.Width = 150;
            // 
            // observacion_documento
            // 
            dataGridViewCellStyle20.Font = new System.Drawing.Font("Cambria", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.observacion_documento.DefaultCellStyle = dataGridViewCellStyle20;
            this.observacion_documento.HeaderText = "Observación";
            this.observacion_documento.MinimumWidth = 8;
            this.observacion_documento.Name = "observacion_documento";
            this.observacion_documento.Width = 150;
            // 
            // aviso_cliente_documento
            // 
            this.aviso_cliente_documento.HeaderText = "Aviso Cliente";
            this.aviso_cliente_documento.MinimumWidth = 8;
            this.aviso_cliente_documento.Name = "aviso_cliente_documento";
            this.aviso_cliente_documento.Width = 150;
            // 
            // mot_cancelacion
            // 
            this.mot_cancelacion.HeaderText = "Motivo cancelación";
            this.mot_cancelacion.MinimumWidth = 8;
            this.mot_cancelacion.Name = "mot_cancelacion";
            this.mot_cancelacion.Width = 150;
            // 
            // usr_prorrogo
            // 
            this.usr_prorrogo.HeaderText = "Usuario Prorrogo";
            this.usr_prorrogo.MinimumWidth = 8;
            this.usr_prorrogo.Name = "usr_prorrogo";
            this.usr_prorrogo.Width = 150;
            // 
            // fecha_firma
            // 
            dataGridViewCellStyle21.Format = "d";
            this.fecha_firma.DefaultCellStyle = dataGridViewCellStyle21;
            this.fecha_firma.HeaderText = "Fecha Sistema";
            this.fecha_firma.MinimumWidth = 8;
            this.fecha_firma.Name = "fecha_firma";
            this.fecha_firma.Width = 150;
            // 
            // documento_relacion
            // 
            this.documento_relacion.HeaderText = "documento_relaciona";
            this.documento_relacion.MinimumWidth = 8;
            this.documento_relacion.Name = "documento_relacion";
            this.documento_relacion.Visible = false;
            this.documento_relacion.Width = 150;
            // 
            // subtipodocumentoid_documento
            // 
            this.subtipodocumentoid_documento.HeaderText = "subtipodocumentoid_documento";
            this.subtipodocumentoid_documento.MinimumWidth = 8;
            this.subtipodocumentoid_documento.Name = "subtipodocumentoid_documento";
            this.subtipodocumentoid_documento.Visible = false;
            this.subtipodocumentoid_documento.Width = 150;
            // 
            // documentoidmarcas
            // 
            this.documentoidmarcas.HeaderText = "documentoidmarcas";
            this.documentoidmarcas.Name = "documentoidmarcas";
            this.documentoidmarcas.Visible = false;
            // 
            // lvdocumentosimpi
            // 
            this.lvdocumentosimpi.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.link,
            this.Tipo,
            this.Codgbarras,
            this.cFolio,
            this.cFechanotific,
            this.cVencimiento,
            this.cVencimiento2mese,
            this.cVencimiento3mese,
            this.cMes,
            this.cFechaimpi,
            this.cFechaescrito,
            this.cDocumento,
            this.cEstatus,
            this.cPlazofinal,
            this.cObservacion,
            this.cAvisocliente,
            this.cMotCancelacion,
            this.cUsuarioprorrogo,
            this.cFechafirma,
            this.cDocumentorelaciona,
            this.subtipodocumentoid});
            this.lvdocumentosimpi.GridLines = true;
            this.lvdocumentosimpi.HideSelection = false;
            this.lvdocumentosimpi.Location = new System.Drawing.Point(1155, 182);
            this.lvdocumentosimpi.Name = "lvdocumentosimpi";
            this.lvdocumentosimpi.Size = new System.Drawing.Size(40, 46);
            this.lvdocumentosimpi.TabIndex = 14;
            this.lvdocumentosimpi.UseCompatibleStateImageBehavior = false;
            this.lvdocumentosimpi.View = System.Windows.Forms.View.Details;
            this.lvdocumentosimpi.DoubleClick += new System.EventHandler(this.lvdocumentosimpi_DoubleClick);
            // 
            // link
            // 
            this.link.Text = "Lnk                      ";
            this.link.Width = 114;
            // 
            // Tipo
            // 
            this.Tipo.Text = "Tipo";
            this.Tipo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Tipo.Width = 44;
            // 
            // Codgbarras
            // 
            this.Codgbarras.Text = "CodBarras                                        ";
            this.Codgbarras.Width = 199;
            // 
            // cFolio
            // 
            this.cFolio.Text = "Folio                           ";
            this.cFolio.Width = 133;
            // 
            // cFechanotific
            // 
            this.cFechanotific.Text = "Fecha notificación";
            this.cFechanotific.Width = 113;
            // 
            // cVencimiento
            // 
            this.cVencimiento.Text = "Vencimiento";
            this.cVencimiento.Width = 126;
            // 
            // cVencimiento2mese
            // 
            this.cVencimiento2mese.Text = "Vencimiento 3 meses";
            this.cVencimiento2mese.Width = 129;
            // 
            // cVencimiento3mese
            // 
            this.cVencimiento3mese.Text = "Vencimiento 4 meses";
            this.cVencimiento3mese.Width = 129;
            // 
            // cMes
            // 
            this.cMes.Text = "Mes ";
            this.cMes.Width = 46;
            // 
            // cFechaimpi
            // 
            this.cFechaimpi.Text = "Fecha sello IMPI";
            this.cFechaimpi.Width = 97;
            // 
            // cFechaescrito
            // 
            this.cFechaescrito.Text = "Fecha Escrito";
            this.cFechaescrito.Width = 0;
            // 
            // cDocumento
            // 
            this.cDocumento.Text = "Documento                               ";
            this.cDocumento.Width = 184;
            // 
            // cEstatus
            // 
            this.cEstatus.Text = "Estatus";
            this.cEstatus.Width = 52;
            // 
            // cPlazofinal
            // 
            this.cPlazofinal.Text = "Plazo Final";
            this.cPlazofinal.Width = 78;
            // 
            // cObservacion
            // 
            this.cObservacion.Text = "Observación";
            this.cObservacion.Width = 75;
            // 
            // cAvisocliente
            // 
            this.cAvisocliente.Text = "Aviso cliente";
            this.cAvisocliente.Width = 79;
            // 
            // cMotCancelacion
            // 
            this.cMotCancelacion.Text = "Motivo Cancelación";
            this.cMotCancelacion.Width = 114;
            // 
            // cUsuarioprorrogo
            // 
            this.cUsuarioprorrogo.Text = "Usuario prorrogó o canceló";
            this.cUsuarioprorrogo.Width = 142;
            // 
            // cFechafirma
            // 
            this.cFechafirma.Text = "Fecha Firma";
            this.cFechafirma.Width = 73;
            // 
            // cDocumentorelaciona
            // 
            this.cDocumentorelaciona.Text = "Documento relacionado";
            this.cDocumentorelaciona.Width = 129;
            // 
            // subtipodocumentoid
            // 
            this.subtipodocumentoid.Text = "subtipodocumentoid";
            this.subtipodocumentoid.Width = 0;
            // 
            // button44
            // 
            this.button44.Location = new System.Drawing.Point(15, 6);
            this.button44.Name = "button44";
            this.button44.Size = new System.Drawing.Size(110, 23);
            this.button44.TabIndex = 13;
            this.button44.Text = "Captura Solicitud";
            this.button44.UseVisualStyleBackColor = true;
            this.button44.Click += new System.EventHandler(this.button44_Click);
            // 
            // button43
            // 
            this.button43.Location = new System.Drawing.Point(17, 92);
            this.button43.Name = "button43";
            this.button43.Size = new System.Drawing.Size(108, 23);
            this.button43.TabIndex = 12;
            this.button43.Text = "Captura Título";
            this.button43.UseVisualStyleBackColor = true;
            this.button43.Click += new System.EventHandler(this.button43_Click_1);
            // 
            // button42
            // 
            this.button42.Location = new System.Drawing.Point(15, 63);
            this.button42.Name = "button42";
            this.button42.Size = new System.Drawing.Size(110, 23);
            this.button42.TabIndex = 11;
            this.button42.Text = "Captura Oficios";
            this.button42.UseVisualStyleBackColor = true;
            this.button42.Click += new System.EventHandler(this.button42_Click_1);
            // 
            // button41
            // 
            this.button41.Location = new System.Drawing.Point(15, 34);
            this.button41.Name = "button41";
            this.button41.Size = new System.Drawing.Size(110, 23);
            this.button41.TabIndex = 10;
            this.button41.Text = "Captura Escritos";
            this.button41.UseVisualStyleBackColor = true;
            this.button41.Click += new System.EventHandler(this.button41_Click_1);
            // 
            // button19
            // 
            this.button19.Location = new System.Drawing.Point(1009, 64);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(75, 23);
            this.button19.TabIndex = 8;
            this.button19.Text = "Subir correo";
            this.button19.UseVisualStyleBackColor = true;
            this.button19.Click += new System.EventHandler(this.button19_Click);
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(898, 69);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(100, 17);
            this.checkBox2.TabIndex = 7;
            this.checkBox2.Text = "Mostrar Correos";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // textBox19
            // 
            this.textBox19.Enabled = false;
            this.textBox19.Location = new System.Drawing.Point(808, 68);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(60, 20);
            this.textBox19.TabIndex = 6;
            // 
            // button18
            // 
            this.button18.BackgroundImage = global::Facturador.Properties.Resources.descarga;
            this.button18.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button18.Location = new System.Drawing.Point(1114, 34);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(62, 51);
            this.button18.TabIndex = 9;
            this.button18.UseVisualStyleBackColor = true;
            this.button18.Click += new System.EventHandler(this.button18_Click);
            // 
            // lvDocumentosmarcas
            // 
            this.lvDocumentosmarcas.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader35,
            this.columnHeader36,
            this.columnHeader37,
            this.columnHeader38,
            this.columnHeader39,
            this.columnHeader40,
            this.columnHeader41,
            this.columnHeader42,
            this.columnHeader43,
            this.columnHeader44,
            this.columnHeader45,
            this.columnHeader46,
            this.columnHeader47,
            this.columnHeader48,
            this.columnHeader49,
            this.columnHeader50,
            this.columnHeader51,
            this.columnHeader52});
            this.lvDocumentosmarcas.GridLines = true;
            this.lvDocumentosmarcas.HideSelection = false;
            this.lvDocumentosmarcas.Location = new System.Drawing.Point(1114, 48);
            this.lvDocumentosmarcas.Name = "lvDocumentosmarcas";
            this.lvDocumentosmarcas.Size = new System.Drawing.Size(51, 22);
            this.lvDocumentosmarcas.TabIndex = 5;
            this.lvDocumentosmarcas.UseCompatibleStateImageBehavior = false;
            this.lvDocumentosmarcas.View = System.Windows.Forms.View.Details;
            this.lvDocumentosmarcas.DoubleClick += new System.EventHandler(this.lvDocumentosmarcas_DoubleClick);
            // 
            // columnHeader35
            // 
            this.columnHeader35.Text = "Lnk";
            // 
            // columnHeader36
            // 
            this.columnHeader36.Text = "Tipo";
            this.columnHeader36.Width = 44;
            // 
            // columnHeader37
            // 
            this.columnHeader37.Text = "CodBarras";
            this.columnHeader37.Width = 68;
            // 
            // columnHeader38
            // 
            this.columnHeader38.Text = "Folio";
            this.columnHeader38.Width = 40;
            // 
            // columnHeader39
            // 
            this.columnHeader39.Text = "Fecha notificación";
            this.columnHeader39.Width = 113;
            // 
            // columnHeader40
            // 
            this.columnHeader40.Text = "Vencimiento";
            this.columnHeader40.Width = 74;
            // 
            // columnHeader41
            // 
            this.columnHeader41.Text = "Fecha sello IMPI";
            this.columnHeader41.Width = 97;
            // 
            // columnHeader42
            // 
            this.columnHeader42.Text = "Fecha Escrito";
            this.columnHeader42.Width = 87;
            // 
            // columnHeader43
            // 
            this.columnHeader43.Text = "Documento";
            this.columnHeader43.Width = 78;
            // 
            // columnHeader44
            // 
            this.columnHeader44.Text = "Estatus";
            this.columnHeader44.Width = 52;
            // 
            // columnHeader45
            // 
            this.columnHeader45.Text = "Mes ";
            this.columnHeader45.Width = 46;
            // 
            // columnHeader46
            // 
            this.columnHeader46.Text = "Plazo Final";
            this.columnHeader46.Width = 78;
            // 
            // columnHeader47
            // 
            this.columnHeader47.Text = "Observación";
            this.columnHeader47.Width = 75;
            // 
            // columnHeader48
            // 
            this.columnHeader48.Text = "Aviso cliente";
            this.columnHeader48.Width = 79;
            // 
            // columnHeader49
            // 
            this.columnHeader49.Text = "Motivo Cancelación";
            this.columnHeader49.Width = 114;
            // 
            // columnHeader50
            // 
            this.columnHeader50.Text = "Usuario prorrogó o canceló";
            this.columnHeader50.Width = 142;
            // 
            // columnHeader51
            // 
            this.columnHeader51.Text = "Fecha Firma";
            this.columnHeader51.Width = 73;
            // 
            // columnHeader52
            // 
            this.columnHeader52.Text = "Documento relacionado";
            this.columnHeader52.Width = 129;
            // 
            // tabPage9
            // 
            this.tabPage9.Controls.Add(this.listView8);
            this.tabPage9.Location = new System.Drawing.Point(4, 22);
            this.tabPage9.Name = "tabPage9";
            this.tabPage9.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage9.Size = new System.Drawing.Size(1595, 449);
            this.tabPage9.TabIndex = 8;
            this.tabPage9.Text = "Traducciones";
            this.tabPage9.UseVisualStyleBackColor = true;
            // 
            // listView8
            // 
            this.listView8.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader58,
            this.columnHeader59,
            this.columnHeader60,
            this.columnHeader61,
            this.columnHeader62,
            this.columnHeader63,
            this.columnHeader64,
            this.columnHeader65,
            this.columnHeader66,
            this.columnHeader67});
            this.listView8.HideSelection = false;
            this.listView8.Location = new System.Drawing.Point(40, 49);
            this.listView8.Name = "listView8";
            this.listView8.Size = new System.Drawing.Size(1166, 275);
            this.listView8.TabIndex = 1;
            this.listView8.UseCompatibleStateImageBehavior = false;
            this.listView8.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader58
            // 
            this.columnHeader58.Text = "Folio";
            this.columnHeader58.Width = 79;
            // 
            // columnHeader59
            // 
            this.columnHeader59.Text = "Traductor";
            this.columnHeader59.Width = 111;
            // 
            // columnHeader60
            // 
            this.columnHeader60.Text = "Usuario";
            this.columnHeader60.Width = 106;
            // 
            // columnHeader61
            // 
            this.columnHeader61.Text = "Fecha Sol";
            this.columnHeader61.Width = 121;
            // 
            // columnHeader62
            // 
            this.columnHeader62.Text = "Fecha Due";
            this.columnHeader62.Width = 109;
            // 
            // columnHeader63
            // 
            this.columnHeader63.Text = "Fecha Ent";
            this.columnHeader63.Width = 131;
            // 
            // columnHeader64
            // 
            this.columnHeader64.Text = "Fecha Pago";
            this.columnHeader64.Width = 129;
            // 
            // columnHeader65
            // 
            this.columnHeader65.Text = "Costo";
            this.columnHeader65.Width = 118;
            // 
            // columnHeader66
            // 
            this.columnHeader66.Text = "Precio";
            this.columnHeader66.Width = 123;
            // 
            // columnHeader67
            // 
            this.columnHeader67.Text = "Moneda";
            this.columnHeader67.Width = 85;
            // 
            // tabPage10
            // 
            this.tabPage10.Controls.Add(this.listView9);
            this.tabPage10.Controls.Add(this.groupBox2);
            this.tabPage10.Location = new System.Drawing.Point(4, 22);
            this.tabPage10.Name = "tabPage10";
            this.tabPage10.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage10.Size = new System.Drawing.Size(1595, 449);
            this.tabPage10.TabIndex = 9;
            this.tabPage10.Text = "Instrucciones";
            this.tabPage10.UseVisualStyleBackColor = true;
            // 
            // listView9
            // 
            this.listView9.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader68,
            this.columnHeader69,
            this.columnHeader70,
            this.columnHeader71,
            this.columnHeader72,
            this.columnHeader73,
            this.columnHeader74});
            this.listView9.HideSelection = false;
            this.listView9.Location = new System.Drawing.Point(31, 208);
            this.listView9.Name = "listView9";
            this.listView9.Size = new System.Drawing.Size(1185, 136);
            this.listView9.TabIndex = 5;
            this.listView9.UseCompatibleStateImageBehavior = false;
            this.listView9.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader68
            // 
            this.columnHeader68.Text = "ID";
            this.columnHeader68.Width = 129;
            // 
            // columnHeader69
            // 
            this.columnHeader69.Text = "Tipo";
            this.columnHeader69.Width = 155;
            // 
            // columnHeader70
            // 
            this.columnHeader70.Text = "Instrucción";
            this.columnHeader70.Width = 179;
            // 
            // columnHeader71
            // 
            this.columnHeader71.Text = "Usuario";
            this.columnHeader71.Width = 168;
            // 
            // columnHeader72
            // 
            this.columnHeader72.Text = "Fecha";
            this.columnHeader72.Width = 172;
            // 
            // columnHeader73
            // 
            this.columnHeader73.Text = "Registrada";
            this.columnHeader73.Width = 222;
            // 
            // columnHeader74
            // 
            this.columnHeader74.Text = "Activa";
            this.columnHeader74.Width = 130;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.button23);
            this.groupBox2.Controls.Add(this.button24);
            this.groupBox2.Controls.Add(this.button25);
            this.groupBox2.Controls.Add(this.textBox23);
            this.groupBox2.Controls.Add(this.label51);
            this.groupBox2.Controls.Add(this.checkBox3);
            this.groupBox2.Controls.Add(this.textBox22);
            this.groupBox2.Controls.Add(this.label50);
            this.groupBox2.Controls.Add(this.richTextBox6);
            this.groupBox2.Controls.Add(this.label49);
            this.groupBox2.Controls.Add(this.textBox21);
            this.groupBox2.Controls.Add(this.label48);
            this.groupBox2.Controls.Add(this.comboBox5);
            this.groupBox2.Controls.Add(this.label52);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(31, 28);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1185, 174);
            this.groupBox2.TabIndex = 4;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Introducción";
            // 
            // button23
            // 
            this.button23.Location = new System.Drawing.Point(1078, 138);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(75, 23);
            this.button23.TabIndex = 13;
            this.button23.Text = "Actualizar";
            this.button23.UseVisualStyleBackColor = true;
            // 
            // button24
            // 
            this.button24.Location = new System.Drawing.Point(1078, 87);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(75, 23);
            this.button24.TabIndex = 12;
            this.button24.Text = "Agregar";
            this.button24.UseVisualStyleBackColor = true;
            // 
            // button25
            // 
            this.button25.Location = new System.Drawing.Point(1078, 33);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(75, 23);
            this.button25.TabIndex = 11;
            this.button25.Text = "Limpiar";
            this.button25.UseVisualStyleBackColor = true;
            // 
            // textBox23
            // 
            this.textBox23.Enabled = false;
            this.textBox23.Location = new System.Drawing.Point(660, 81);
            this.textBox23.Name = "textBox23";
            this.textBox23.Size = new System.Drawing.Size(123, 21);
            this.textBox23.TabIndex = 10;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(535, 87);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(85, 15);
            this.label51.TabIndex = 9;
            this.label51.Text = "Fecha registro";
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Location = new System.Drawing.Point(870, 29);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(57, 19);
            this.checkBox3.TabIndex = 8;
            this.checkBox3.Text = "Activo";
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // textBox22
            // 
            this.textBox22.Location = new System.Drawing.Point(660, 30);
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(123, 21);
            this.textBox22.TabIndex = 7;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(517, 33);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(103, 15);
            this.label50.TabIndex = 6;
            this.label50.Text = "Fecha Instrucción";
            // 
            // richTextBox6
            // 
            this.richTextBox6.Location = new System.Drawing.Point(133, 123);
            this.richTextBox6.Name = "richTextBox6";
            this.richTextBox6.Size = new System.Drawing.Size(794, 40);
            this.richTextBox6.TabIndex = 5;
            this.richTextBox6.Text = "";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(29, 134);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(74, 15);
            this.label49.TabIndex = 4;
            this.label49.Text = "Introducción";
            // 
            // textBox21
            // 
            this.textBox21.Location = new System.Drawing.Point(133, 81);
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(287, 21);
            this.textBox21.TabIndex = 3;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(29, 81);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(50, 15);
            this.label48.TabIndex = 2;
            this.label48.Text = "Usuario";
            // 
            // comboBox5
            // 
            this.comboBox5.FormattingEnabled = true;
            this.comboBox5.Location = new System.Drawing.Point(133, 33);
            this.comboBox5.Name = "comboBox5";
            this.comboBox5.Size = new System.Drawing.Size(287, 23);
            this.comboBox5.TabIndex = 1;
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(29, 33);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(31, 15);
            this.label52.TabIndex = 0;
            this.label52.Text = "Tipo";
            // 
            // tabPage11
            // 
            this.tabPage11.Controls.Add(this.listView10);
            this.tabPage11.Controls.Add(this.textBox26);
            this.tabPage11.Controls.Add(this.groupBox3);
            this.tabPage11.Location = new System.Drawing.Point(4, 22);
            this.tabPage11.Name = "tabPage11";
            this.tabPage11.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage11.Size = new System.Drawing.Size(1595, 449);
            this.tabPage11.TabIndex = 10;
            this.tabPage11.Text = "Observaciones";
            this.tabPage11.UseVisualStyleBackColor = true;
            // 
            // listView10
            // 
            this.listView10.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader75,
            this.columnHeader76,
            this.columnHeader77});
            this.listView10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listView10.HideSelection = false;
            this.listView10.Location = new System.Drawing.Point(41, 191);
            this.listView10.Name = "listView10";
            this.listView10.Size = new System.Drawing.Size(1164, 157);
            this.listView10.TabIndex = 5;
            this.listView10.UseCompatibleStateImageBehavior = false;
            this.listView10.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader75
            // 
            this.columnHeader75.Text = "Observación";
            this.columnHeader75.Width = 539;
            // 
            // columnHeader76
            // 
            this.columnHeader76.Text = "Usuario";
            this.columnHeader76.Width = 434;
            // 
            // columnHeader77
            // 
            this.columnHeader77.Text = "Fecha";
            this.columnHeader77.Width = 132;
            // 
            // textBox26
            // 
            this.textBox26.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox26.Location = new System.Drawing.Point(1170, 151);
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new System.Drawing.Size(35, 22);
            this.textBox26.TabIndex = 4;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.button26);
            this.groupBox3.Controls.Add(this.button27);
            this.groupBox3.Controls.Add(this.button28);
            this.groupBox3.Controls.Add(this.richTextBox7);
            this.groupBox3.Controls.Add(this.label54);
            this.groupBox3.Controls.Add(this.textBox25);
            this.groupBox3.Controls.Add(this.label53);
            this.groupBox3.Controls.Add(this.textBox24);
            this.groupBox3.Controls.Add(this.label55);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(41, 25);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(1104, 148);
            this.groupBox3.TabIndex = 3;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Observación";
            // 
            // button26
            // 
            this.button26.Location = new System.Drawing.Point(1008, 102);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(75, 23);
            this.button26.TabIndex = 8;
            this.button26.Text = "Actualizar";
            this.button26.UseVisualStyleBackColor = true;
            // 
            // button27
            // 
            this.button27.Location = new System.Drawing.Point(1008, 59);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(75, 23);
            this.button27.TabIndex = 7;
            this.button27.Text = "Agregar";
            this.button27.UseVisualStyleBackColor = true;
            // 
            // button28
            // 
            this.button28.Location = new System.Drawing.Point(1008, 20);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(75, 23);
            this.button28.TabIndex = 6;
            this.button28.Text = "Limpiar";
            this.button28.UseVisualStyleBackColor = true;
            // 
            // richTextBox7
            // 
            this.richTextBox7.Location = new System.Drawing.Point(104, 75);
            this.richTextBox7.Name = "richTextBox7";
            this.richTextBox7.Size = new System.Drawing.Size(830, 52);
            this.richTextBox7.TabIndex = 5;
            this.richTextBox7.Text = "";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(12, 84);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(75, 15);
            this.label54.TabIndex = 4;
            this.label54.Text = "Observación";
            // 
            // textBox25
            // 
            this.textBox25.Enabled = false;
            this.textBox25.Location = new System.Drawing.Point(834, 32);
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(100, 21);
            this.textBox25.TabIndex = 3;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(710, 32);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(90, 15);
            this.label53.TabIndex = 2;
            this.label53.Text = "Fecha Registro";
            // 
            // textBox24
            // 
            this.textBox24.Enabled = false;
            this.textBox24.Location = new System.Drawing.Point(104, 29);
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(353, 21);
            this.textBox24.TabIndex = 1;
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(37, 32);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(50, 15);
            this.label55.TabIndex = 0;
            this.label55.Text = "Usuario";
            // 
            // tabPage12
            // 
            this.tabPage12.Controls.Add(this.button29);
            this.tabPage12.Controls.Add(this.dgDocumentoselectronicos);
            this.tabPage12.Controls.Add(this.tb_contdocelect_);
            this.tabPage12.Controls.Add(this.button6);
            this.tabPage12.Controls.Add(this.tb_filename);
            this.tabPage12.Controls.Add(this.tb_descripdocelec);
            this.tabPage12.Controls.Add(this.button15);
            this.tabPage12.Controls.Add(this.label66);
            this.tabPage12.Controls.Add(this.label65);
            this.tabPage12.Controls.Add(this.label64);
            this.tabPage12.Controls.Add(this.cb_tipodocelect);
            this.tabPage12.Location = new System.Drawing.Point(4, 22);
            this.tabPage12.Name = "tabPage12";
            this.tabPage12.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage12.Size = new System.Drawing.Size(1595, 449);
            this.tabPage12.TabIndex = 11;
            this.tabPage12.Text = "Edocs";
            this.tabPage12.UseVisualStyleBackColor = true;
            // 
            // button29
            // 
            this.button29.Location = new System.Drawing.Point(1306, 13);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(119, 31);
            this.button29.TabIndex = 21;
            this.button29.Text = "Eliminar Documento";
            this.button29.UseVisualStyleBackColor = true;
            this.button29.Click += new System.EventHandler(this.button29_Click);
            // 
            // dgDocumentoselectronicos
            // 
            dataGridViewCellStyle24.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle24.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle24.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle24.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle24.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle24.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle24.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgDocumentoselectronicos.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle24;
            this.dgDocumentoselectronicos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgDocumentoselectronicos.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.documentoelectronicoid,
            this.fecha,
            this.usuario,
            this.tipo_doc,
            this.Descripcion,
            this.ruta});
            dataGridViewCellStyle25.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle25.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle25.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle25.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle25.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle25.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle25.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgDocumentoselectronicos.DefaultCellStyle = dataGridViewCellStyle25;
            this.dgDocumentoselectronicos.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dgDocumentoselectronicos.Location = new System.Drawing.Point(3, 125);
            this.dgDocumentoselectronicos.Name = "dgDocumentoselectronicos";
            dataGridViewCellStyle26.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle26.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle26.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle26.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle26.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle26.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle26.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgDocumentoselectronicos.RowHeadersDefaultCellStyle = dataGridViewCellStyle26;
            this.dgDocumentoselectronicos.Size = new System.Drawing.Size(1589, 321);
            this.dgDocumentoselectronicos.TabIndex = 20;
            this.dgDocumentoselectronicos.DoubleClick += new System.EventHandler(this.dgDocumentoselectronicos_DoubleClick);
            // 
            // documentoelectronicoid
            // 
            this.documentoelectronicoid.HeaderText = "documentoelectronicoid";
            this.documentoelectronicoid.Name = "documentoelectronicoid";
            this.documentoelectronicoid.Visible = false;
            // 
            // fecha
            // 
            this.fecha.HeaderText = "Fecha";
            this.fecha.Name = "fecha";
            // 
            // usuario
            // 
            this.usuario.HeaderText = "Usuario";
            this.usuario.Name = "usuario";
            // 
            // tipo_doc
            // 
            this.tipo_doc.HeaderText = "Tipo";
            this.tipo_doc.Name = "tipo_doc";
            // 
            // Descripcion
            // 
            this.Descripcion.HeaderText = "Descripción";
            this.Descripcion.Name = "Descripcion";
            this.Descripcion.Width = 300;
            // 
            // ruta
            // 
            this.ruta.HeaderText = "Ruta";
            this.ruta.Name = "ruta";
            this.ruta.Width = 800;
            // 
            // tb_contdocelect_
            // 
            this.tb_contdocelect_.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_contdocelect_.Location = new System.Drawing.Point(1049, 99);
            this.tb_contdocelect_.Name = "tb_contdocelect_";
            this.tb_contdocelect_.ReadOnly = true;
            this.tb_contdocelect_.Size = new System.Drawing.Size(73, 20);
            this.tb_contdocelect_.TabIndex = 19;
            this.tb_contdocelect_.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(1139, 16);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(119, 23);
            this.button6.TabIndex = 18;
            this.button6.Text = "Limpiar";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // tb_filename
            // 
            this.tb_filename.Enabled = false;
            this.tb_filename.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_filename.Location = new System.Drawing.Point(170, 65);
            this.tb_filename.Name = "tb_filename";
            this.tb_filename.ReadOnly = true;
            this.tb_filename.Size = new System.Drawing.Size(765, 21);
            this.tb_filename.TabIndex = 15;
            // 
            // tb_descripdocelec
            // 
            this.tb_descripdocelec.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_descripdocelec.Location = new System.Drawing.Point(546, 21);
            this.tb_descripdocelec.Name = "tb_descripdocelec";
            this.tb_descripdocelec.Size = new System.Drawing.Size(389, 21);
            this.tb_descripdocelec.TabIndex = 13;
            // 
            // button15
            // 
            this.button15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button15.Location = new System.Drawing.Point(1139, 55);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(119, 31);
            this.button15.TabIndex = 16;
            this.button15.Text = "Subir Documneto";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label66.Location = new System.Drawing.Point(62, 72);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(59, 15);
            this.label66.TabIndex = 14;
            this.label66.Text = "Filename";
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label65.Location = new System.Drawing.Point(433, 24);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(72, 15);
            this.label65.TabIndex = 12;
            this.label65.Text = "Descripción";
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label64.Location = new System.Drawing.Point(62, 24);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(96, 15);
            this.label64.TabIndex = 11;
            this.label64.Text = "Tipo documento";
            // 
            // cb_tipodocelect
            // 
            this.cb_tipodocelect.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_tipodocelect.FormattingEnabled = true;
            this.cb_tipodocelect.Location = new System.Drawing.Point(170, 21);
            this.cb_tipodocelect.Name = "cb_tipodocelect";
            this.cb_tipodocelect.Size = new System.Drawing.Size(196, 23);
            this.cb_tipodocelect.TabIndex = 10;
            // 
            // tabPage13
            // 
            this.tabPage13.Controls.Add(this.groupBox4);
            this.tabPage13.Controls.Add(this.cbIdiomacarta);
            this.tabPage13.Controls.Add(this.label104);
            this.tabPage13.Controls.Add(this.checkBox4);
            this.tabPage13.Controls.Add(this.button31);
            this.tabPage13.Controls.Add(this.cbCartas);
            this.tabPage13.Controls.Add(this.label68);
            this.tabPage13.Controls.Add(this.cbOficiosEscritos);
            this.tabPage13.Controls.Add(this.label67);
            this.tabPage13.Location = new System.Drawing.Point(4, 22);
            this.tabPage13.Name = "tabPage13";
            this.tabPage13.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage13.Size = new System.Drawing.Size(1595, 449);
            this.tabPage13.TabIndex = 12;
            this.tabPage13.Text = "Cartas";
            this.tabPage13.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.textBox2);
            this.groupBox4.Controls.Add(this.label18);
            this.groupBox4.Controls.Add(this.label30);
            this.groupBox4.Controls.Add(this.textBox5);
            this.groupBox4.Controls.Add(this.label47);
            this.groupBox4.Controls.Add(this.textBox4);
            this.groupBox4.Controls.Add(this.label75);
            this.groupBox4.Controls.Add(this.textBox3);
            this.groupBox4.Location = new System.Drawing.Point(263, 89);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(907, 44);
            this.groupBox4.TabIndex = 48;
            this.groupBox4.TabStop = false;
            this.groupBox4.Visible = false;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(109, 18);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 20);
            this.textBox2.TabIndex = 16;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(18, 21);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(88, 13);
            this.label18.TabIndex = 12;
            this.label18.Text = "Fecha Sello IMPI";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(234, 21);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(67, 13);
            this.label30.TabIndex = 13;
            this.label30.Text = "Fecha Calce";
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(779, 18);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(100, 20);
            this.textBox5.TabIndex = 19;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(443, 21);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(96, 13);
            this.label47.TabIndex = 14;
            this.label47.Text = "Fecha Notificación";
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(545, 18);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(100, 20);
            this.textBox4.TabIndex = 18;
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Location = new System.Drawing.Point(675, 21);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(98, 13);
            this.label75.TabIndex = 15;
            this.label75.Text = "Fecha Vencimiento";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(303, 18);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 20);
            this.textBox3.TabIndex = 17;
            // 
            // cbIdiomacarta
            // 
            this.cbIdiomacarta.FormattingEnabled = true;
            this.cbIdiomacarta.Location = new System.Drawing.Point(1150, 58);
            this.cbIdiomacarta.Name = "cbIdiomacarta";
            this.cbIdiomacarta.Size = new System.Drawing.Size(121, 21);
            this.cbIdiomacarta.TabIndex = 47;
            // 
            // label104
            // 
            this.label104.AutoSize = true;
            this.label104.Location = new System.Drawing.Point(1072, 63);
            this.label104.Name = "label104";
            this.label104.Size = new System.Drawing.Size(65, 13);
            this.label104.TabIndex = 46;
            this.label104.Text = "Idioma carta";
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox4.Location = new System.Drawing.Point(1075, 214);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(170, 20);
            this.checkBox4.TabIndex = 11;
            this.checkBox4.Text = "Mostrar todas las cartas";
            this.checkBox4.UseVisualStyleBackColor = true;
            // 
            // button31
            // 
            this.button31.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button31.Location = new System.Drawing.Point(1075, 173);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(131, 23);
            this.button31.TabIndex = 10;
            this.button31.Text = "Generar Carta";
            this.button31.UseVisualStyleBackColor = true;
            this.button31.Click += new System.EventHandler(this.button31_Click);
            // 
            // cbCartas
            // 
            this.cbCartas.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbCartas.FormattingEnabled = true;
            this.cbCartas.Location = new System.Drawing.Point(263, 177);
            this.cbCartas.Name = "cbCartas";
            this.cbCartas.Size = new System.Drawing.Size(762, 24);
            this.cbCartas.TabIndex = 9;
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label68.Location = new System.Drawing.Point(146, 180);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(47, 16);
            this.label68.TabIndex = 8;
            this.label68.Text = "Cartas";
            // 
            // cbOficiosEscritos
            // 
            this.cbOficiosEscritos.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbOficiosEscritos.FormattingEnabled = true;
            this.cbOficiosEscritos.Location = new System.Drawing.Point(263, 59);
            this.cbOficiosEscritos.Name = "cbOficiosEscritos";
            this.cbOficiosEscritos.Size = new System.Drawing.Size(762, 24);
            this.cbOficiosEscritos.TabIndex = 7;
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label67.Location = new System.Drawing.Point(114, 59);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(100, 32);
            this.label67.TabIndex = 6;
            this.label67.Text = "Oficio o Escrito \r\na reportar";
            // 
            // tabPage14
            // 
            this.tabPage14.Controls.Add(this.cbidiomaescrito);
            this.tabPage14.Controls.Add(this.label103);
            this.tabPage14.Controls.Add(this.checkBox6);
            this.tabPage14.Controls.Add(this.button32);
            this.tabPage14.Controls.Add(this.cbDocEscritos);
            this.tabPage14.Controls.Add(this.label70);
            this.tabPage14.Controls.Add(this.cbOficiosparaescritos);
            this.tabPage14.Controls.Add(this.label69);
            this.tabPage14.Location = new System.Drawing.Point(4, 22);
            this.tabPage14.Name = "tabPage14";
            this.tabPage14.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage14.Size = new System.Drawing.Size(1595, 449);
            this.tabPage14.TabIndex = 13;
            this.tabPage14.Text = "Escritos";
            this.tabPage14.UseVisualStyleBackColor = true;
            // 
            // cbidiomaescrito
            // 
            this.cbidiomaescrito.FormattingEnabled = true;
            this.cbidiomaescrito.Location = new System.Drawing.Point(999, 94);
            this.cbidiomaescrito.Name = "cbidiomaescrito";
            this.cbidiomaescrito.Size = new System.Drawing.Size(121, 21);
            this.cbidiomaescrito.TabIndex = 45;
            // 
            // label103
            // 
            this.label103.AutoSize = true;
            this.label103.Location = new System.Drawing.Point(921, 99);
            this.label103.Name = "label103";
            this.label103.Size = new System.Drawing.Size(72, 13);
            this.label103.TabIndex = 44;
            this.label103.Text = "Idioma escrito";
            // 
            // checkBox6
            // 
            this.checkBox6.AutoSize = true;
            this.checkBox6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox6.Location = new System.Drawing.Point(999, 215);
            this.checkBox6.Name = "checkBox6";
            this.checkBox6.Size = new System.Drawing.Size(180, 20);
            this.checkBox6.TabIndex = 13;
            this.checkBox6.Text = "Mostrar todos los escritos";
            this.checkBox6.UseVisualStyleBackColor = true;
            // 
            // button32
            // 
            this.button32.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button32.Location = new System.Drawing.Point(999, 169);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(145, 23);
            this.button32.TabIndex = 12;
            this.button32.Text = "Generar Escrito";
            this.button32.UseVisualStyleBackColor = true;
            this.button32.Click += new System.EventHandler(this.button32_Click);
            // 
            // cbDocEscritos
            // 
            this.cbDocEscritos.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbDocEscritos.FormattingEnabled = true;
            this.cbDocEscritos.Location = new System.Drawing.Point(161, 171);
            this.cbDocEscritos.Name = "cbDocEscritos";
            this.cbDocEscritos.Size = new System.Drawing.Size(717, 24);
            this.cbDocEscritos.TabIndex = 11;
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label70.Location = new System.Drawing.Point(54, 179);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(56, 16);
            this.label70.TabIndex = 10;
            this.label70.Text = "Escritos";
            // 
            // cbOficiosparaescritos
            // 
            this.cbOficiosparaescritos.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbOficiosparaescritos.FormattingEnabled = true;
            this.cbOficiosparaescritos.Location = new System.Drawing.Point(161, 94);
            this.cbOficiosparaescritos.Name = "cbOficiosparaescritos";
            this.cbOficiosparaescritos.Size = new System.Drawing.Size(717, 24);
            this.cbOficiosparaescritos.TabIndex = 8;
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label69.Location = new System.Drawing.Point(64, 103);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(42, 16);
            this.label69.TabIndex = 7;
            this.label69.Text = "Oficio";
            // 
            // tabPage15
            // 
            this.tabPage15.Controls.Add(this.cbIdiomadoc);
            this.tabPage15.Controls.Add(this.label82);
            this.tabPage15.Controls.Add(this.btnGenerarcesion);
            this.tabPage15.Controls.Add(this.cbCesiones);
            this.tabPage15.Controls.Add(this.label80);
            this.tabPage15.Controls.Add(this.btnGenerarpoder);
            this.tabPage15.Controls.Add(this.cbPoder);
            this.tabPage15.Controls.Add(this.label81);
            this.tabPage15.Controls.Add(this.button33);
            this.tabPage15.Controls.Add(this.label71);
            this.tabPage15.Controls.Add(this.CB_formatoscc);
            this.tabPage15.Location = new System.Drawing.Point(4, 22);
            this.tabPage15.Name = "tabPage15";
            this.tabPage15.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage15.Size = new System.Drawing.Size(1595, 449);
            this.tabPage15.TabIndex = 14;
            this.tabPage15.Text = "Formatos";
            this.tabPage15.UseVisualStyleBackColor = true;
            this.tabPage15.Click += new System.EventHandler(this.tabPage15_Click);
            // 
            // cbIdiomadoc
            // 
            this.cbIdiomadoc.FormattingEnabled = true;
            this.cbIdiomadoc.Location = new System.Drawing.Point(816, 167);
            this.cbIdiomadoc.Name = "cbIdiomadoc";
            this.cbIdiomadoc.Size = new System.Drawing.Size(121, 21);
            this.cbIdiomadoc.TabIndex = 59;
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Location = new System.Drawing.Point(760, 175);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(38, 13);
            this.label82.TabIndex = 58;
            this.label82.Text = "Idioma";
            // 
            // btnGenerarcesion
            // 
            this.btnGenerarcesion.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGenerarcesion.Location = new System.Drawing.Point(823, 368);
            this.btnGenerarcesion.Name = "btnGenerarcesion";
            this.btnGenerarcesion.Size = new System.Drawing.Size(114, 23);
            this.btnGenerarcesion.TabIndex = 57;
            this.btnGenerarcesion.Text = "Generar Cesion";
            this.btnGenerarcesion.UseVisualStyleBackColor = true;
            this.btnGenerarcesion.Click += new System.EventHandler(this.btnGenerarcesion_Click);
            // 
            // cbCesiones
            // 
            this.cbCesiones.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbCesiones.FormattingEnabled = true;
            this.cbCesiones.Location = new System.Drawing.Point(175, 327);
            this.cbCesiones.Name = "cbCesiones";
            this.cbCesiones.Size = new System.Drawing.Size(762, 24);
            this.cbCesiones.TabIndex = 56;
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label80.Location = new System.Drawing.Point(79, 330);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(65, 16);
            this.label80.TabIndex = 55;
            this.label80.Text = "Cesiones";
            // 
            // btnGenerarpoder
            // 
            this.btnGenerarpoder.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGenerarpoder.Location = new System.Drawing.Point(823, 246);
            this.btnGenerarpoder.Name = "btnGenerarpoder";
            this.btnGenerarpoder.Size = new System.Drawing.Size(114, 23);
            this.btnGenerarpoder.TabIndex = 54;
            this.btnGenerarpoder.Text = "Generar Poder";
            this.btnGenerarpoder.UseVisualStyleBackColor = true;
            this.btnGenerarpoder.Click += new System.EventHandler(this.btnGenerarpoder_Click);
            // 
            // cbPoder
            // 
            this.cbPoder.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbPoder.FormattingEnabled = true;
            this.cbPoder.Location = new System.Drawing.Point(175, 216);
            this.cbPoder.Name = "cbPoder";
            this.cbPoder.Size = new System.Drawing.Size(762, 24);
            this.cbPoder.TabIndex = 53;
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label81.Location = new System.Drawing.Point(79, 219);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(60, 16);
            this.label81.TabIndex = 52;
            this.label81.Text = "Poderes";
            // 
            // button33
            // 
            this.button33.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button33.Location = new System.Drawing.Point(974, 36);
            this.button33.Name = "button33";
            this.button33.Size = new System.Drawing.Size(102, 23);
            this.button33.TabIndex = 5;
            this.button33.Text = "Generar";
            this.button33.UseVisualStyleBackColor = true;
            this.button33.Click += new System.EventHandler(this.button33_Click);
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label71.Location = new System.Drawing.Point(37, 39);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(58, 16);
            this.label71.TabIndex = 4;
            this.label71.Text = "Formato";
            // 
            // CB_formatoscc
            // 
            this.CB_formatoscc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CB_formatoscc.FormattingEnabled = true;
            this.CB_formatoscc.Location = new System.Drawing.Point(120, 36);
            this.CB_formatoscc.Name = "CB_formatoscc";
            this.CB_formatoscc.Size = new System.Drawing.Size(795, 24);
            this.CB_formatoscc.TabIndex = 3;
            // 
            // tabPage17
            // 
            this.tabPage17.Controls.Add(this.dgview_facturas);
            this.tabPage17.Location = new System.Drawing.Point(4, 22);
            this.tabPage17.Name = "tabPage17";
            this.tabPage17.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage17.Size = new System.Drawing.Size(1595, 449);
            this.tabPage17.TabIndex = 16;
            this.tabPage17.Text = "Facturas";
            this.tabPage17.UseVisualStyleBackColor = true;
            // 
            // dgview_facturas
            // 
            this.dgview_facturas.AllowUserToAddRows = false;
            this.dgview_facturas.AllowUserToDeleteRows = false;
            this.dgview_facturas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgview_facturas.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.fac_pdf,
            this.facturano,
            this.fecha_emision,
            this.fecha_pago,
            this.dias_sin_pagar,
            this.status_pago,
            this.foliofeps,
            this.total_mer,
            this.Numero_de_servicios,
            this.Servicio_uno,
            this.Servicio_dos,
            this.Servicio_tres});
            this.dgview_facturas.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dgview_facturas.Location = new System.Drawing.Point(3, 72);
            this.dgview_facturas.Name = "dgview_facturas";
            this.dgview_facturas.RowHeadersWidth = 62;
            this.dgview_facturas.Size = new System.Drawing.Size(1589, 374);
            this.dgview_facturas.TabIndex = 0;
            this.dgview_facturas.DoubleClick += new System.EventHandler(this.dgview_facturas_DoubleClick);
            // 
            // fac_pdf
            // 
            this.fac_pdf.HeaderText = "PDF";
            this.fac_pdf.MinimumWidth = 8;
            this.fac_pdf.Name = "fac_pdf";
            this.fac_pdf.Visible = false;
            this.fac_pdf.Width = 150;
            // 
            // facturano
            // 
            this.facturano.HeaderText = "Invoice #/\n    Factura no.";
            this.facturano.MinimumWidth = 8;
            this.facturano.Name = "facturano";
            this.facturano.Width = 150;
            // 
            // fecha_emision
            // 
            this.fecha_emision.HeaderText = "Date of Issue/\n    Fecha Emision";
            this.fecha_emision.MinimumWidth = 8;
            this.fecha_emision.Name = "fecha_emision";
            this.fecha_emision.Width = 150;
            // 
            // fecha_pago
            // 
            this.fecha_pago.HeaderText = "Fecha Pago";
            this.fecha_pago.MinimumWidth = 8;
            this.fecha_pago.Name = "fecha_pago";
            this.fecha_pago.Width = 150;
            // 
            // dias_sin_pagar
            // 
            this.dias_sin_pagar.HeaderText = "Days past due/\n    Dias sin pagar";
            this.dias_sin_pagar.MinimumWidth = 8;
            this.dias_sin_pagar.Name = "dias_sin_pagar";
            this.dias_sin_pagar.Width = 150;
            // 
            // status_pago
            // 
            this.status_pago.HeaderText = "Payment Status/ Status pago";
            this.status_pago.MinimumWidth = 8;
            this.status_pago.Name = "status_pago";
            this.status_pago.Width = 150;
            // 
            // foliofeps
            // 
            this.foliofeps.HeaderText = "Folio Feps";
            this.foliofeps.MinimumWidth = 8;
            this.foliofeps.Name = "foliofeps";
            this.foliofeps.Width = 150;
            // 
            // total_mer
            // 
            this.total_mer.HeaderText = "Total (MER)";
            this.total_mer.MinimumWidth = 8;
            this.total_mer.Name = "total_mer";
            this.total_mer.Width = 150;
            // 
            // Numero_de_servicios
            // 
            this.Numero_de_servicios.HeaderText = "No Servicios";
            this.Numero_de_servicios.MinimumWidth = 8;
            this.Numero_de_servicios.Name = "Numero_de_servicios";
            this.Numero_de_servicios.Width = 150;
            // 
            // Servicio_uno
            // 
            this.Servicio_uno.HeaderText = "Servicio Uno";
            this.Servicio_uno.MinimumWidth = 8;
            this.Servicio_uno.Name = "Servicio_uno";
            this.Servicio_uno.Width = 150;
            // 
            // Servicio_dos
            // 
            this.Servicio_dos.HeaderText = "Servicio Dos";
            this.Servicio_dos.MinimumWidth = 8;
            this.Servicio_dos.Name = "Servicio_dos";
            this.Servicio_dos.Width = 150;
            // 
            // Servicio_tres
            // 
            this.Servicio_tres.HeaderText = "Servicio Tres";
            this.Servicio_tres.MinimumWidth = 8;
            this.Servicio_tres.Name = "Servicio_tres";
            this.Servicio_tres.Width = 150;
            // 
            // tabPage8
            // 
            this.tabPage8.Controls.Add(this.button30);
            this.tabPage8.Controls.Add(this.button17);
            this.tabPage8.Controls.Add(this.dgViewOposiciones);
            this.tabPage8.Location = new System.Drawing.Point(4, 22);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage8.Size = new System.Drawing.Size(1595, 449);
            this.tabPage8.TabIndex = 17;
            this.tabPage8.Text = "Oposiciones";
            this.tabPage8.UseVisualStyleBackColor = true;
            // 
            // button30
            // 
            this.button30.Location = new System.Drawing.Point(1110, 95);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(150, 38);
            this.button30.TabIndex = 2;
            this.button30.Text = "Crear Caso Donde Atacan  Nuestra Solicitud";
            this.button30.UseVisualStyleBackColor = true;
            this.button30.Click += new System.EventHandler(this.button30_Click);
            // 
            // button17
            // 
            this.button17.Location = new System.Drawing.Point(1110, 42);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(150, 38);
            this.button17.TabIndex = 1;
            this.button17.Text = "Crear Caso Interponemos Oposición";
            this.button17.UseVisualStyleBackColor = true;
            this.button17.Click += new System.EventHandler(this.button17_Click);
            // 
            // dgViewOposiciones
            // 
            this.dgViewOposiciones.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgViewOposiciones.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.opoCasoid,
            this.Feataca,
            this.opocasonumero,
            this.opomarcaimitadora,
            this.opoclase,
            this.oponombredelimitador,
            this.opoExpedienteimitador,
            this.opoFechapublicacion,
            this.opofechapresentacion,
            this.opoFechaInterponemosEscrito});
            this.dgViewOposiciones.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dgViewOposiciones.Location = new System.Drawing.Point(3, 156);
            this.dgViewOposiciones.Name = "dgViewOposiciones";
            this.dgViewOposiciones.Size = new System.Drawing.Size(1589, 290);
            this.dgViewOposiciones.TabIndex = 0;
            this.dgViewOposiciones.DoubleClick += new System.EventHandler(this.dgViewOposiciones_DoubleClick);
            // 
            // opoCasoid
            // 
            this.opoCasoid.HeaderText = "Casoid";
            this.opoCasoid.Name = "opoCasoid";
            // 
            // Feataca
            // 
            this.Feataca.HeaderText = "Fecha Atacan Nuestra Marca";
            this.Feataca.Name = "Feataca";
            // 
            // opocasonumero
            // 
            this.opocasonumero.HeaderText = "Caso Numero";
            this.opocasonumero.Name = "opocasonumero";
            // 
            // opomarcaimitadora
            // 
            this.opomarcaimitadora.HeaderText = "Marca Imitadora";
            this.opomarcaimitadora.Name = "opomarcaimitadora";
            // 
            // opoclase
            // 
            this.opoclase.HeaderText = "Clase";
            this.opoclase.Name = "opoclase";
            // 
            // oponombredelimitador
            // 
            this.oponombredelimitador.HeaderText = "Nombre del Imitador";
            this.oponombredelimitador.Name = "oponombredelimitador";
            // 
            // opoExpedienteimitador
            // 
            this.opoExpedienteimitador.HeaderText = "Expediente Imitador";
            this.opoExpedienteimitador.Name = "opoExpedienteimitador";
            // 
            // opoFechapublicacion
            // 
            this.opoFechapublicacion.HeaderText = "Fecha publicación";
            this.opoFechapublicacion.Name = "opoFechapublicacion";
            // 
            // opofechapresentacion
            // 
            this.opofechapresentacion.HeaderText = "Fecha Presentación";
            this.opofechapresentacion.Name = "opofechapresentacion";
            // 
            // opoFechaInterponemosEscrito
            // 
            this.opoFechaInterponemosEscrito.HeaderText = "Fecha Interponemos Escrito oposición";
            this.opoFechaInterponemosEscrito.Name = "opoFechaInterponemosEscrito";
            // 
            // lCasoID
            // 
            this.lCasoID.AutoSize = true;
            this.lCasoID.Location = new System.Drawing.Point(159, 95);
            this.lCasoID.Name = "lCasoID";
            this.lCasoID.Size = new System.Drawing.Size(0, 13);
            this.lCasoID.TabIndex = 66;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(99, 95);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(42, 13);
            this.label26.TabIndex = 65;
            this.label26.Text = "CasoID";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(16, 34);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 61;
            this.button2.Text = "Menú";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // richTextBox4
            // 
            this.richTextBox4.Location = new System.Drawing.Point(892, 176);
            this.richTextBox4.Name = "richTextBox4";
            this.richTextBox4.ReadOnly = true;
            this.richTextBox4.Size = new System.Drawing.Size(384, 40);
            this.richTextBox4.TabIndex = 60;
            this.richTextBox4.Text = "";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(814, 176);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(68, 26);
            this.label40.TabIndex = 59;
            this.label40.Text = "Correo \r\nCorresponsal";
            // 
            // lCotaccorresponsal
            // 
            this.lCotaccorresponsal.AutoSize = true;
            this.lCotaccorresponsal.Location = new System.Drawing.Point(578, 197);
            this.lCotaccorresponsal.Name = "lCotaccorresponsal";
            this.lCotaccorresponsal.Size = new System.Drawing.Size(0, 13);
            this.lCotaccorresponsal.TabIndex = 58;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(494, 184);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(68, 26);
            this.label38.TabIndex = 57;
            this.label38.Text = "Contacto \r\nCorresponsal";
            // 
            // lResponsable
            // 
            this.lResponsable.AutoSize = true;
            this.lResponsable.Location = new System.Drawing.Point(889, 148);
            this.lResponsable.Name = "lResponsable";
            this.lResponsable.Size = new System.Drawing.Size(0, 13);
            this.lResponsable.TabIndex = 56;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.Location = new System.Drawing.Point(797, 149);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(96, 13);
            this.label36.TabIndex = 55;
            this.label36.Text = "  Responsable  ";
            this.label36.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label36.Click += new System.EventHandler(this.label36_Click);
            this.label36.DoubleClick += new System.EventHandler(this.label36_DoubleClick);
            this.label36.MouseLeave += new System.EventHandler(this.label36_MouseLeave);
            this.label36.MouseMove += new System.Windows.Forms.MouseEventHandler(this.label36_MouseMove);
            // 
            // rtCorreocontacto
            // 
            this.rtCorreocontacto.Location = new System.Drawing.Point(892, 84);
            this.rtCorreocontacto.Name = "rtCorreocontacto";
            this.rtCorreocontacto.ReadOnly = true;
            this.rtCorreocontacto.Size = new System.Drawing.Size(384, 50);
            this.rtCorreocontacto.TabIndex = 54;
            this.rtCorreocontacto.Text = "";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(828, 86);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(50, 26);
            this.label35.TabIndex = 53;
            this.label35.Text = "Correos \r\nContacto";
            // 
            // lCorresponsal
            // 
            this.lCorresponsal.AutoSize = true;
            this.lCorresponsal.Location = new System.Drawing.Point(577, 146);
            this.lCorresponsal.Name = "lCorresponsal";
            this.lCorresponsal.Size = new System.Drawing.Size(0, 13);
            this.lCorresponsal.TabIndex = 52;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.label33.Location = new System.Drawing.Point(482, 153);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(80, 13);
            this.label33.TabIndex = 51;
            this.label33.Text = "Corresponsal";
            this.label33.DoubleClick += new System.EventHandler(this.label33_DoubleClick);
            this.label33.MouseLeave += new System.EventHandler(this.label33_MouseLeave);
            this.label33.MouseMove += new System.Windows.Forms.MouseEventHandler(this.label33_MouseMove);
            // 
            // lReferencia
            // 
            this.lReferencia.AutoSize = true;
            this.lReferencia.Location = new System.Drawing.Point(578, 112);
            this.lReferencia.Name = "lReferencia";
            this.lReferencia.Size = new System.Drawing.Size(0, 13);
            this.lReferencia.TabIndex = 50;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(503, 112);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(59, 13);
            this.label31.TabIndex = 49;
            this.label31.Text = "Referencia";
            // 
            // lTitular
            // 
            this.lTitular.AutoSize = true;
            this.lTitular.Location = new System.Drawing.Point(575, 82);
            this.lTitular.Name = "lTitular";
            this.lTitular.Size = new System.Drawing.Size(0, 13);
            this.lTitular.TabIndex = 48;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.label29.Location = new System.Drawing.Point(507, 82);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(48, 13);
            this.label29.TabIndex = 47;
            this.label29.Text = "  Titular  ";
            this.label29.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lPais
            // 
            this.lPais.AutoSize = true;
            this.lPais.Location = new System.Drawing.Point(125, 192);
            this.lPais.Name = "lPais";
            this.lPais.Size = new System.Drawing.Size(0, 13);
            this.lPais.TabIndex = 46;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(92, 196);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(49, 13);
            this.label27.TabIndex = 45;
            this.label27.Text = "  País  ";
            this.label27.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label27.DoubleClick += new System.EventHandler(this.label27_DoubleClick);
            this.label27.MouseLeave += new System.EventHandler(this.label27_MouseLeave);
            this.label27.MouseMove += new System.Windows.Forms.MouseEventHandler(this.label27_MouseMove);
            // 
            // lRegistro
            // 
            this.lRegistro.AutoSize = true;
            this.lRegistro.Location = new System.Drawing.Point(159, 154);
            this.lRegistro.Name = "lRegistro";
            this.lRegistro.Size = new System.Drawing.Size(0, 13);
            this.lRegistro.TabIndex = 44;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(95, 154);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(46, 13);
            this.label25.TabIndex = 43;
            this.label25.Text = "Registro";
            // 
            // lExpediente
            // 
            this.lExpediente.AutoSize = true;
            this.lExpediente.Location = new System.Drawing.Point(159, 120);
            this.lExpediente.Name = "lExpediente";
            this.lExpediente.Size = new System.Drawing.Size(0, 13);
            this.lExpediente.TabIndex = 42;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(81, 120);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(60, 13);
            this.label23.TabIndex = 41;
            this.label23.Text = "Expediente";
            // 
            // lContacto
            // 
            this.lContacto.AutoSize = true;
            this.lContacto.Location = new System.Drawing.Point(878, 51);
            this.lContacto.Name = "lContacto";
            this.lContacto.Size = new System.Drawing.Size(0, 13);
            this.lContacto.TabIndex = 40;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(812, 52);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(74, 13);
            this.label21.TabIndex = 39;
            this.label21.Text = "  Contacto  ";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label21.DoubleClick += new System.EventHandler(this.label21_DoubleClick);
            this.label21.MouseLeave += new System.EventHandler(this.label21_MouseLeave);
            this.label21.MouseMove += new System.Windows.Forms.MouseEventHandler(this.label21_MouseMove);
            // 
            // lCliente
            // 
            this.lCliente.AutoSize = true;
            this.lCliente.Location = new System.Drawing.Point(577, 54);
            this.lCliente.Name = "lCliente";
            this.lCliente.Size = new System.Drawing.Size(0, 13);
            this.lCliente.TabIndex = 38;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(500, 53);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(62, 13);
            this.label19.TabIndex = 37;
            this.label19.Text = "  Cliente  ";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label19.DoubleClick += new System.EventHandler(this.label19_DoubleClick);
            this.label19.MouseLeave += new System.EventHandler(this.label19_MouseLeave);
            this.label19.MouseMove += new System.Windows.Forms.MouseEventHandler(this.label19_MouseMove);
            // 
            // lCasoNumero
            // 
            this.lCasoNumero.AutoSize = true;
            this.lCasoNumero.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lCasoNumero.Location = new System.Drawing.Point(156, 62);
            this.lCasoNumero.Name = "lCasoNumero";
            this.lCasoNumero.Size = new System.Drawing.Size(0, 16);
            this.lCasoNumero.TabIndex = 36;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(106, 64);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(35, 15);
            this.label17.TabIndex = 35;
            this.label17.Text = "Caso";
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(123, 23);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(1017, 10);
            this.progressBar1.TabIndex = 67;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(1075, 98);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(73, 13);
            this.label41.TabIndex = 68;
            this.label41.Text = "Idioma Cliente";
            // 
            // cbIdiomaCliente
            // 
            this.cbIdiomaCliente.FormattingEnabled = true;
            this.cbIdiomaCliente.Location = new System.Drawing.Point(1154, 95);
            this.cbIdiomaCliente.Name = "cbIdiomaCliente";
            this.cbIdiomaCliente.Size = new System.Drawing.Size(88, 21);
            this.cbIdiomaCliente.TabIndex = 69;
            this.cbIdiomaCliente.TextChanged += new System.EventHandler(this.cbIdiomaCliente_TextChanged);
            // 
            // tbEstatus_header
            // 
            this.tbEstatus_header.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbEstatus_header.Location = new System.Drawing.Point(931, 223);
            this.tbEstatus_header.Name = "tbEstatus_header";
            this.tbEstatus_header.ReadOnly = true;
            this.tbEstatus_header.Size = new System.Drawing.Size(345, 21);
            this.tbEstatus_header.TabIndex = 73;
            this.tbEstatus_header.TextChanged += new System.EventHandler(this.tbEstatus_header_TextChanged_1);
            this.tbEstatus_header.DoubleClick += new System.EventHandler(this.tbEstatus_header_DoubleClick);
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label61.Location = new System.Drawing.Point(872, 226);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(54, 15);
            this.label61.TabIndex = 72;
            this.label61.Text = "Estatus";
            this.label61.DoubleClick += new System.EventHandler(this.tbEstatus_header_DoubleClick);
            this.label61.MouseLeave += new System.EventHandler(this.label61_MouseLeave);
            this.label61.MouseMove += new System.Windows.Forms.MouseEventHandler(this.label61_MouseMove);
            // 
            // button39
            // 
            this.button39.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button39.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button39.Location = new System.Drawing.Point(16, 98);
            this.button39.Name = "button39";
            this.button39.Size = new System.Drawing.Size(34, 25);
            this.button39.TabIndex = 64;
            this.button39.Text = "-";
            this.button39.UseVisualStyleBackColor = true;
            this.button39.Click += new System.EventHandler(this.button39_Click);
            // 
            // button38
            // 
            this.button38.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button38.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button38.Location = new System.Drawing.Point(16, 64);
            this.button38.Name = "button38";
            this.button38.Size = new System.Drawing.Size(34, 25);
            this.button38.TabIndex = 63;
            this.button38.Text = "+";
            this.button38.UseVisualStyleBackColor = true;
            this.button38.Click += new System.EventHandler(this.button38_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // tbCasoNumero
            // 
            this.tbCasoNumero.Location = new System.Drawing.Point(159, 59);
            this.tbCasoNumero.Name = "tbCasoNumero";
            this.tbCasoNumero.ReadOnly = true;
            this.tbCasoNumero.Size = new System.Drawing.Size(93, 20);
            this.tbCasoNumero.TabIndex = 74;
            // 
            // tbCasoid
            // 
            this.tbCasoid.Location = new System.Drawing.Point(159, 88);
            this.tbCasoid.Name = "tbCasoid";
            this.tbCasoid.ReadOnly = true;
            this.tbCasoid.Size = new System.Drawing.Size(93, 20);
            this.tbCasoid.TabIndex = 75;
            // 
            // tbExpediente
            // 
            this.tbExpediente.Location = new System.Drawing.Point(159, 117);
            this.tbExpediente.Name = "tbExpediente";
            this.tbExpediente.ReadOnly = true;
            this.tbExpediente.Size = new System.Drawing.Size(144, 20);
            this.tbExpediente.TabIndex = 76;
            // 
            // tbRegistro
            // 
            this.tbRegistro.Location = new System.Drawing.Point(159, 148);
            this.tbRegistro.Name = "tbRegistro";
            this.tbRegistro.ReadOnly = true;
            this.tbRegistro.Size = new System.Drawing.Size(144, 20);
            this.tbRegistro.TabIndex = 77;
            // 
            // tbl_pais
            // 
            this.tbl_pais.Location = new System.Drawing.Point(159, 189);
            this.tbl_pais.Name = "tbl_pais";
            this.tbl_pais.ReadOnly = true;
            this.tbl_pais.Size = new System.Drawing.Size(74, 20);
            this.tbl_pais.TabIndex = 78;
            // 
            // tblCliente
            // 
            this.tblCliente.Location = new System.Drawing.Point(568, 47);
            this.tblCliente.Name = "tblCliente";
            this.tblCliente.ReadOnly = true;
            this.tblCliente.Size = new System.Drawing.Size(217, 20);
            this.tblCliente.TabIndex = 79;
            this.tblCliente.DoubleClick += new System.EventHandler(this.tblCliente_DoubleClick);
            // 
            // tblTitular
            // 
            this.tblTitular.Location = new System.Drawing.Point(568, 78);
            this.tblTitular.Name = "tblTitular";
            this.tblTitular.ReadOnly = true;
            this.tblTitular.Size = new System.Drawing.Size(217, 20);
            this.tblTitular.TabIndex = 80;
            // 
            // tblCorresponsal
            // 
            this.tblCorresponsal.Location = new System.Drawing.Point(568, 145);
            this.tblCorresponsal.Name = "tblCorresponsal";
            this.tblCorresponsal.ReadOnly = true;
            this.tblCorresponsal.Size = new System.Drawing.Size(217, 20);
            this.tblCorresponsal.TabIndex = 81;
            // 
            // tblCotaccorresponsal
            // 
            this.tblCotaccorresponsal.Location = new System.Drawing.Point(568, 190);
            this.tblCotaccorresponsal.Name = "tblCotaccorresponsal";
            this.tblCotaccorresponsal.ReadOnly = true;
            this.tblCotaccorresponsal.Size = new System.Drawing.Size(217, 20);
            this.tblCotaccorresponsal.TabIndex = 82;
            // 
            // tblContacto
            // 
            this.tblContacto.Location = new System.Drawing.Point(892, 49);
            this.tblContacto.Name = "tblContacto";
            this.tblContacto.ReadOnly = true;
            this.tblContacto.Size = new System.Drawing.Size(190, 20);
            this.tblContacto.TabIndex = 83;
            this.tblContacto.DoubleClick += new System.EventHandler(this.tblContacto_DoubleClick);
            // 
            // tblRefencia
            // 
            this.tblRefencia.Location = new System.Drawing.Point(568, 108);
            this.tblRefencia.Name = "tblRefencia";
            this.tblRefencia.ReadOnly = true;
            this.tblRefencia.Size = new System.Drawing.Size(217, 20);
            this.tblRefencia.TabIndex = 84;
            this.tblRefencia.TextChanged += new System.EventHandler(this.tblRefencia_TextChanged);
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Location = new System.Drawing.Point(307, 57);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(37, 13);
            this.label74.TabIndex = 85;
            this.label74.Text = "Marca";
            // 
            // rtbDDenominacion_general
            // 
            this.rtbDDenominacion_general.Location = new System.Drawing.Point(359, 50);
            this.rtbDDenominacion_general.Name = "rtbDDenominacion_general";
            this.rtbDDenominacion_general.ReadOnly = true;
            this.rtbDDenominacion_general.Size = new System.Drawing.Size(116, 75);
            this.rtbDDenominacion_general.TabIndex = 86;
            this.rtbDDenominacion_general.Text = "";
            this.rtbDDenominacion_general.TextChanged += new System.EventHandler(this.rtbDDenominacion_general_TextChanged);
            // 
            // tblResponsable
            // 
            this.tblResponsable.Location = new System.Drawing.Point(896, 146);
            this.tblResponsable.Name = "tblResponsable";
            this.tblResponsable.ReadOnly = true;
            this.tblResponsable.Size = new System.Drawing.Size(380, 20);
            this.tblResponsable.TabIndex = 87;
            this.tblResponsable.DoubleClick += new System.EventHandler(this.tblResponsable_DoubleClick);
            // 
            // tbAvisoprueba
            // 
            this.tbAvisoprueba.BackColor = System.Drawing.Color.Red;
            this.tbAvisoprueba.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbAvisoprueba.Location = new System.Drawing.Point(1217, 43);
            this.tbAvisoprueba.Name = "tbAvisoprueba";
            this.tbAvisoprueba.ReadOnly = true;
            this.tbAvisoprueba.Size = new System.Drawing.Size(100, 21);
            this.tbAvisoprueba.TabIndex = 176;
            this.tbAvisoprueba.Text = "Prueba";
            this.tbAvisoprueba.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.Ley);
            this.groupBox5.Controls.Add(this.tbDtipo);
            this.groupBox5.Controls.Add(this.dgVProductosheader);
            this.groupBox5.Controls.Add(this.label78);
            this.groupBox5.Controls.Add(this.button1);
            this.groupBox5.Controls.Add(this.label77);
            this.groupBox5.Controls.Add(this.cbDTipomarca);
            this.groupBox5.Controls.Add(this.tbNumeroregistrointernacional);
            this.groupBox5.Controls.Add(this.label39);
            this.groupBox5.Controls.Add(this.label76);
            this.groupBox5.Controls.Add(this.label13);
            this.groupBox5.Controls.Add(this.label37);
            this.groupBox5.Controls.Add(this.tbFechaRegistrointernacional);
            this.groupBox5.Controls.Add(this.label28);
            this.groupBox5.Controls.Add(this.tbEstatusfactura);
            this.groupBox5.Controls.Add(this.label6);
            this.groupBox5.Controls.Add(this.label1);
            this.groupBox5.Controls.Add(this.tbSubtipo1);
            this.groupBox5.Controls.Add(this.label2);
            this.groupBox5.Controls.Add(this.label34);
            this.groupBox5.Controls.Add(this.tbDSigpruebauso);
            this.groupBox5.Controls.Add(this.label12);
            this.groupBox5.Controls.Add(this.tbDFechacarta);
            this.groupBox5.Controls.Add(this.tbDFechavigencia);
            this.groupBox5.Controls.Add(this.label20);
            this.groupBox5.Controls.Add(this.label10);
            this.groupBox5.Controls.Add(this.label32);
            this.groupBox5.Controls.Add(this.cbDIdioma);
            this.groupBox5.Controls.Add(this.label24);
            this.groupBox5.Controls.Add(this.label3);
            this.groupBox5.Controls.Add(this.tbDFechaconcesion);
            this.groupBox5.Controls.Add(this.label9);
            this.groupBox5.Controls.Add(this.tbclase);
            this.groupBox5.Controls.Add(this.label56);
            this.groupBox5.Controls.Add(this.tbDNumeroReg);
            this.groupBox5.Controls.Add(this.label8);
            this.groupBox5.Controls.Add(this.tbDExpediente);
            this.groupBox5.Controls.Add(this.label4);
            this.groupBox5.Controls.Add(this.tbDfecharecepcion);
            this.groupBox5.Controls.Add(this.label7);
            this.groupBox5.Controls.Add(this.tbDFechainiciouso);
            this.groupBox5.Controls.Add(this.cbDNoseausado);
            this.groupBox5.Controls.Add(this.label11);
            this.groupBox5.Location = new System.Drawing.Point(12, 250);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(1423, 282);
            this.groupBox5.TabIndex = 73;
            this.groupBox5.TabStop = false;
            // 
            // Ley
            // 
            this.Ley.FormattingEnabled = true;
            this.Ley.Location = new System.Drawing.Point(745, 25);
            this.Ley.Name = "Ley";
            this.Ley.Size = new System.Drawing.Size(121, 21);
            this.Ley.TabIndex = 268;
            // 
            // tbDtipo
            // 
            this.tbDtipo.Enabled = false;
            this.tbDtipo.FormattingEnabled = true;
            this.tbDtipo.Location = new System.Drawing.Point(83, 29);
            this.tbDtipo.Name = "tbDtipo";
            this.tbDtipo.Size = new System.Drawing.Size(195, 21);
            this.tbDtipo.TabIndex = 177;
            // 
            // dgVProductosheader
            // 
            this.dgVProductosheader.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgVProductosheader.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.casproductoidheader,
            this.claseheader,
            this.descripcionheader});
            dataGridViewCellStyle28.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle28.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle28.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle28.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle28.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle28.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle28.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgVProductosheader.DefaultCellStyle = dataGridViewCellStyle28;
            this.dgVProductosheader.Location = new System.Drawing.Point(64, 179);
            this.dgVProductosheader.Name = "dgVProductosheader";
            this.dgVProductosheader.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            this.dgVProductosheader.Size = new System.Drawing.Size(994, 89);
            this.dgVProductosheader.TabIndex = 266;
            // 
            // casproductoidheader
            // 
            this.casproductoidheader.HeaderText = "casoproductiod";
            this.casproductoidheader.Name = "casproductoidheader";
            this.casproductoidheader.Visible = false;
            this.casproductoidheader.Width = 105;
            // 
            // claseheader
            // 
            this.claseheader.HeaderText = "Clase";
            this.claseheader.Name = "claseheader";
            // 
            // descripcionheader
            // 
            dataGridViewCellStyle27.Font = new System.Drawing.Font("Cambria", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.descripcionheader.DefaultCellStyle = dataGridViewCellStyle27;
            this.descripcionheader.HeaderText = "Descripción";
            this.descripcionheader.Name = "descripcionheader";
            this.descripcionheader.Width = 800;
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label78.Location = new System.Drawing.Point(1317, 102);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(66, 12);
            this.label78.TabIndex = 265;
            this.label78.Text = "día / mes  /Año";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Cambria", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(1067, 227);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(114, 23);
            this.button1.TabIndex = 248;
            this.button1.Text = "Guardar cambios";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Location = new System.Drawing.Point(963, 61);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(68, 39);
            this.label77.TabIndex = 262;
            this.label77.Text = "Número de \r\nRegistro \r\nInternacional";
            // 
            // cbDTipomarca
            // 
            this.cbDTipomarca.FormattingEnabled = true;
            this.cbDTipomarca.Location = new System.Drawing.Point(322, 29);
            this.cbDTipomarca.Name = "cbDTipomarca";
            this.cbDTipomarca.Size = new System.Drawing.Size(258, 21);
            this.cbDTipomarca.TabIndex = 247;
            // 
            // tbNumeroregistrointernacional
            // 
            this.tbNumeroregistrointernacional.Location = new System.Drawing.Point(1064, 76);
            this.tbNumeroregistrointernacional.Name = "tbNumeroregistrointernacional";
            this.tbNumeroregistrointernacional.Size = new System.Drawing.Size(100, 20);
            this.tbNumeroregistrointernacional.TabIndex = 261;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(1317, 212);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(66, 12);
            this.label39.TabIndex = 258;
            this.label39.Text = "día / mes  /Año";
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Location = new System.Drawing.Point(1197, 73);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(97, 26);
            this.label76.TabIndex = 264;
            this.label76.Text = "Fecha de Registro \r\nInternacional";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(126, 12);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(71, 13);
            this.label13.TabIndex = 246;
            this.label13.Text = "Tipo Solicitud";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(1318, 160);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(66, 12);
            this.label37.TabIndex = 256;
            this.label37.Text = "día / mes  /Año";
            // 
            // tbFechaRegistrointernacional
            // 
            this.tbFechaRegistrointernacional.Location = new System.Drawing.Point(1300, 79);
            this.tbFechaRegistrointernacional.Name = "tbFechaRegistrointernacional";
            this.tbFechaRegistrointernacional.Size = new System.Drawing.Size(100, 20);
            this.tbFechaRegistrointernacional.TabIndex = 263;
            this.tbFechaRegistrointernacional.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbFechaRegistrointernacional_KeyPress);
            this.tbFechaRegistrointernacional.Leave += new System.EventHandler(this.tbFechaRegistrointernacional_MouseLeave);
            this.tbFechaRegistrointernacional.Validating += new System.ComponentModel.CancelEventHandler(this.tbFechaRegistrointernacional_Validating);
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(1081, 161);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(66, 12);
            this.label28.TabIndex = 252;
            this.label28.Text = "día / mes  /Año";
            // 
            // tbEstatusfactura
            // 
            this.tbEstatusfactura.Location = new System.Drawing.Point(1064, 25);
            this.tbEstatusfactura.Name = "tbEstatusfactura";
            this.tbEstatusfactura.ReadOnly = true;
            this.tbEstatusfactura.Size = new System.Drawing.Size(100, 20);
            this.tbEstatusfactura.TabIndex = 260;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(963, 28);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(96, 13);
            this.label6.TabIndex = 259;
            this.label6.Text = "Estatus Factura";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(419, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(61, 13);
            this.label1.TabIndex = 225;
            this.label1.Text = "Tipo Marca";
            // 
            // tbSubtipo1
            // 
            this.tbSubtipo1.Location = new System.Drawing.Point(322, 71);
            this.tbSubtipo1.Name = "tbSubtipo1";
            this.tbSubtipo1.ReadOnly = true;
            this.tbSubtipo1.Size = new System.Drawing.Size(121, 20);
            this.tbSubtipo1.TabIndex = 228;
            this.tbSubtipo1.Visible = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(800, 12);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(24, 13);
            this.label2.TabIndex = 227;
            this.label2.Text = "Ley";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(842, 98);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(66, 12);
            this.label34.TabIndex = 254;
            this.label34.Text = "día / mes  /Año";
            // 
            // tbDSigpruebauso
            // 
            this.tbDSigpruebauso.Location = new System.Drawing.Point(1300, 189);
            this.tbDSigpruebauso.Name = "tbDSigpruebauso";
            this.tbDSigpruebauso.Size = new System.Drawing.Size(100, 20);
            this.tbDSigpruebauso.TabIndex = 245;
            this.tbDSigpruebauso.TextChanged += new System.EventHandler(this.tbDSigpruebauso_TextChanged);
            this.tbDSigpruebauso.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbDSigpruebauso_KeyPress);
            this.tbDSigpruebauso.Leave += new System.EventHandler(this.tbDSigpruebauso_MouseLeave);
            this.tbDSigpruebauso.Validating += new System.ComponentModel.CancelEventHandler(this.tbDSigpruebauso_Validating);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(1199, 195);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(78, 13);
            this.label12.TabIndex = 244;
            this.label12.Text = "Sig. Decla Uso";
            // 
            // tbDFechacarta
            // 
            this.tbDFechacarta.Location = new System.Drawing.Point(114, 71);
            this.tbDFechacarta.Name = "tbDFechacarta";
            this.tbDFechacarta.Size = new System.Drawing.Size(100, 20);
            this.tbDFechacarta.TabIndex = 230;
            this.tbDFechacarta.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbDFechacarta_KeyPress);
            this.tbDFechacarta.Leave += new System.EventHandler(this.tbDFechacarta_MouseLeave);
            this.tbDFechacarta.Validating += new System.ComponentModel.CancelEventHandler(this.tbDFechacarta_Validating);
            // 
            // tbDFechavigencia
            // 
            this.tbDFechavigencia.Location = new System.Drawing.Point(1300, 137);
            this.tbDFechavigencia.Name = "tbDFechavigencia";
            this.tbDFechavigencia.Size = new System.Drawing.Size(100, 20);
            this.tbDFechavigencia.TabIndex = 242;
            this.tbDFechavigencia.TextChanged += new System.EventHandler(this.tbDFechavigencia_TextChanged);
            this.tbDFechavigencia.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbDFechavigencia_KeyPress);
            this.tbDFechavigencia.Leave += new System.EventHandler(this.tbDFechavigencia_MouseLeave);
            this.tbDFechavigencia.Validating += new System.ComponentModel.CancelEventHandler(this.tbDFechavigencia_Validating);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(1201, 27);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(72, 13);
            this.label20.TabIndex = 250;
            this.label20.Text = "Idioma cliente";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(1201, 140);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(81, 13);
            this.label10.TabIndex = 241;
            this.label10.Text = "Fecha Vigencia";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(131, 94);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(66, 12);
            this.label32.TabIndex = 253;
            this.label32.Text = "día / mes  /Año";
            // 
            // cbDIdioma
            // 
            this.cbDIdioma.Enabled = false;
            this.cbDIdioma.FormattingEnabled = true;
            this.cbDIdioma.Location = new System.Drawing.Point(1298, 23);
            this.cbDIdioma.Name = "cbDIdioma";
            this.cbDIdioma.Size = new System.Drawing.Size(102, 21);
            this.cbDIdioma.TabIndex = 249;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(572, 154);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(66, 12);
            this.label24.TabIndex = 251;
            this.label24.Text = "día / mes  /Año";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(31, 74);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 13);
            this.label3.TabIndex = 229;
            this.label3.Text = "Fecha Carta";
            // 
            // tbDFechaconcesion
            // 
            this.tbDFechaconcesion.Location = new System.Drawing.Point(1064, 139);
            this.tbDFechaconcesion.Name = "tbDFechaconcesion";
            this.tbDFechaconcesion.Size = new System.Drawing.Size(100, 20);
            this.tbDFechaconcesion.TabIndex = 240;
            this.tbDFechaconcesion.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbDFechaconcesion_KeyPress);
            this.tbDFechaconcesion.Leave += new System.EventHandler(this.tbDFechaconcesion_MouseLeave);
            this.tbDFechaconcesion.Validating += new System.ComponentModel.CancelEventHandler(this.tbDFechaconcesion_Validating);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(968, 142);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(90, 13);
            this.label9.TabIndex = 239;
            this.label9.Text = "Fecha Concesión";
            // 
            // tbclase
            // 
            this.tbclase.Location = new System.Drawing.Point(98, 135);
            this.tbclase.Name = "tbclase";
            this.tbclase.ReadOnly = true;
            this.tbclase.Size = new System.Drawing.Size(116, 20);
            this.tbclase.TabIndex = 257;
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(50, 138);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(33, 13);
            this.label56.TabIndex = 255;
            this.label56.Text = "Clase";
            // 
            // tbDNumeroReg
            // 
            this.tbDNumeroReg.Location = new System.Drawing.Point(808, 137);
            this.tbDNumeroReg.Name = "tbDNumeroReg";
            this.tbDNumeroReg.Size = new System.Drawing.Size(121, 20);
            this.tbDNumeroReg.TabIndex = 238;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(716, 140);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(74, 13);
            this.label8.TabIndex = 237;
            this.label8.Text = "Num. Registro";
            // 
            // tbDExpediente
            // 
            this.tbDExpediente.Location = new System.Drawing.Point(310, 134);
            this.tbDExpediente.Name = "tbDExpediente";
            this.tbDExpediente.Size = new System.Drawing.Size(100, 20);
            this.tbDExpediente.TabIndex = 232;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(244, 138);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 13);
            this.label4.TabIndex = 231;
            this.label4.Text = "Expediente";
            // 
            // tbDfecharecepcion
            // 
            this.tbDfecharecepcion.Location = new System.Drawing.Point(555, 131);
            this.tbDfecharecepcion.Name = "tbDfecharecepcion";
            this.tbDfecharecepcion.Size = new System.Drawing.Size(100, 20);
            this.tbDfecharecepcion.TabIndex = 235;
            this.tbDfecharecepcion.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbDfecharecepcion_KeyPress);
            this.tbDfecharecepcion.Leave += new System.EventHandler(this.tbDfecharecepcion_MouseLeave);
            this.tbDfecharecepcion.Validating += new System.ComponentModel.CancelEventHandler(this.tbDfecharecepcion_Validating);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(457, 137);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(92, 13);
            this.label7.TabIndex = 234;
            this.label7.Text = "Fecha Recepción";
            // 
            // tbDFechainiciouso
            // 
            this.tbDFechainiciouso.Location = new System.Drawing.Point(808, 75);
            this.tbDFechainiciouso.Name = "tbDFechainiciouso";
            this.tbDFechainiciouso.Size = new System.Drawing.Size(121, 20);
            this.tbDFechainiciouso.TabIndex = 233;
            this.tbDFechainiciouso.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbDFechainiciouso_KeyPress);
            this.tbDFechainiciouso.Leave += new System.EventHandler(this.tbDFechainiciouso_MouseLeave);
            this.tbDFechainiciouso.Validating += new System.ComponentModel.CancelEventHandler(this.tbDFechainiciouso_Validating);
            // 
            // cbDNoseausado
            // 
            this.cbDNoseausado.AutoSize = true;
            this.cbDNoseausado.Location = new System.Drawing.Point(516, 71);
            this.cbDNoseausado.Name = "cbDNoseausado";
            this.cbDNoseausado.Size = new System.Drawing.Size(147, 30);
            this.cbDNoseausado.TabIndex = 236;
            this.cbDNoseausado.Text = "No se ha usado la marca \r\n antes de solicitarla";
            this.cbDNoseausado.UseVisualStyleBackColor = true;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(688, 73);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(104, 26);
            this.label11.TabIndex = 243;
            this.label11.Text = "Fecha uso por \r\nprimera vez la marca";
            // 
            // tbSubtipo
            // 
            this.tbSubtipo.FormattingEnabled = true;
            this.tbSubtipo.Location = new System.Drawing.Point(757, 227);
            this.tbSubtipo.Name = "tbSubtipo";
            this.tbSubtipo.Size = new System.Drawing.Size(121, 21);
            this.tbSubtipo.TabIndex = 267;
            this.tbSubtipo.Visible = false;
            // 
            // pbDimage
            // 
            this.pbDimage.Image = global::Facturador.Properties.Resources._16494;
            this.pbDimage.Location = new System.Drawing.Point(1291, 70);
            this.pbDimage.Name = "pbDimage";
            this.pbDimage.Size = new System.Drawing.Size(205, 178);
            this.pbDimage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbDimage.TabIndex = 38;
            this.pbDimage.TabStop = false;
            // 
            // fTmarcas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(1620, 999);
            this.Controls.Add(this.tabcFDatosgenerales);
            this.Controls.Add(this.tbSubtipo);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.pbDimage);
            this.Controls.Add(this.tbAvisoprueba);
            this.Controls.Add(this.tblResponsable);
            this.Controls.Add(this.rtbDDenominacion_general);
            this.Controls.Add(this.label74);
            this.Controls.Add(this.tblRefencia);
            this.Controls.Add(this.tblContacto);
            this.Controls.Add(this.tblCotaccorresponsal);
            this.Controls.Add(this.tblCorresponsal);
            this.Controls.Add(this.tblTitular);
            this.Controls.Add(this.tblCliente);
            this.Controls.Add(this.tbl_pais);
            this.Controls.Add(this.tbRegistro);
            this.Controls.Add(this.tbExpediente);
            this.Controls.Add(this.tbCasoid);
            this.Controls.Add(this.tbCasoNumero);
            this.Controls.Add(this.tbEstatus_header);
            this.Controls.Add(this.label61);
            this.Controls.Add(this.progressBar1);
            this.Controls.Add(this.lCasoID);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.button39);
            this.Controls.Add(this.button38);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.richTextBox4);
            this.Controls.Add(this.label40);
            this.Controls.Add(this.lCotaccorresponsal);
            this.Controls.Add(this.label38);
            this.Controls.Add(this.lResponsable);
            this.Controls.Add(this.label36);
            this.Controls.Add(this.rtCorreocontacto);
            this.Controls.Add(this.label35);
            this.Controls.Add(this.lCorresponsal);
            this.Controls.Add(this.label33);
            this.Controls.Add(this.lReferencia);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.lTitular);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.lPais);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.lRegistro);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.lExpediente);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.lContacto);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.lCliente);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.lCasoNumero);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.cbIdiomaCliente);
            this.Controls.Add(this.label41);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "fTmarcas";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = " Consulta caso (Marcas):";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.fTmarcas_FormClosing);
            this.Load += new System.EventHandler(this.fTmarcas_Load);
            this.Resize += new System.EventHandler(this.fTmarcas_Resize);
            this.tabcFDatosgenerales.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGVProductos)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.tabPage7.ResumeLayout(false);
            this.tabPage7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgPlazos)).EndInit();
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGV_docimentos_IMPI)).EndInit();
            this.tabPage9.ResumeLayout(false);
            this.tabPage10.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.tabPage11.ResumeLayout(false);
            this.tabPage11.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.tabPage12.ResumeLayout(false);
            this.tabPage12.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgDocumentoselectronicos)).EndInit();
            this.tabPage13.ResumeLayout(false);
            this.tabPage13.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.tabPage14.ResumeLayout(false);
            this.tabPage14.PerformLayout();
            this.tabPage15.ResumeLayout(false);
            this.tabPage15.PerformLayout();
            this.tabPage17.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgview_facturas)).EndInit();
            this.tabPage8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgViewOposiciones)).EndInit();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgVProductosheader)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbDimage)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.TabControl tabcFDatosgenerales;
        public System.Windows.Forms.TabPage tabPage1;
        public System.Windows.Forms.TabPage tabPage2;
        public System.Windows.Forms.Label lCasoID;
        public System.Windows.Forms.Label label26;
        public System.Windows.Forms.Button button39;
        public System.Windows.Forms.Button button38;
        public System.Windows.Forms.Button button2;
        public System.Windows.Forms.RichTextBox richTextBox4;
        public System.Windows.Forms.Label label40;
        public System.Windows.Forms.Label lCotaccorresponsal;
        public System.Windows.Forms.Label label38;
        public System.Windows.Forms.Label lResponsable;
        public System.Windows.Forms.Label label36;
        public System.Windows.Forms.RichTextBox rtCorreocontacto;
        public System.Windows.Forms.Label label35;
        public System.Windows.Forms.Label lCorresponsal;
        public System.Windows.Forms.Label label33;
        public System.Windows.Forms.Label lReferencia;
        public System.Windows.Forms.Label label31;
        public System.Windows.Forms.Label lTitular;
        public System.Windows.Forms.Label label29;
        public System.Windows.Forms.Label lPais;
        public System.Windows.Forms.Label label27;
        public System.Windows.Forms.Label lRegistro;
        public System.Windows.Forms.Label label25;
        public System.Windows.Forms.Label lExpediente;
        public System.Windows.Forms.Label label23;
        public System.Windows.Forms.Label lContacto;
        public System.Windows.Forms.Label label21;
        public System.Windows.Forms.Label lCliente;
        public System.Windows.Forms.Label label19;
        public System.Windows.Forms.Label lCasoNumero;
        public System.Windows.Forms.Label label17;
        public System.Windows.Forms.TabPage tabPage3;
        public System.Windows.Forms.TabPage tabPage4;
        public System.Windows.Forms.TabPage tabPage5;
        public System.Windows.Forms.TabPage tabPage6;
        public System.Windows.Forms.TabPage tabPage7;
        public System.Windows.Forms.TabPage tabPage9;
        public System.Windows.Forms.TabPage tabPage10;
        public System.Windows.Forms.TabPage tabPage11;
        public System.Windows.Forms.TabPage tabPage12;
        public System.Windows.Forms.TabPage tabPage13;
        public System.Windows.Forms.TabPage tabPage14;
        public System.Windows.Forms.TabPage tabPage15;
        public System.Windows.Forms.Label label16;
        public System.Windows.Forms.RichTextBox rtbDProductossidiomaorig;
        public System.Windows.Forms.RichTextBox rtbDLeyendasfiguras;
        public System.Windows.Forms.Label label15;
        public System.Windows.Forms.RichTextBox rtbDDenominacion;
        public System.Windows.Forms.Label label14;
        public System.Windows.Forms.PictureBox pbDimage;
        public System.Windows.Forms.ProgressBar progressBar1;
        public System.Windows.Forms.Button button7;
        public System.Windows.Forms.TextBox tbNumprod;
        public System.Windows.Forms.Button button5;
        public System.Windows.Forms.RichTextBox rtDescripciondelproducto;
        public System.Windows.Forms.RichTextBox rtbdescripcionclase;
        public System.Windows.Forms.ComboBox cbClasemarca;
        public System.Windows.Forms.Label label22;
        public System.Windows.Forms.Label label41;
        public System.Windows.Forms.ComboBox cbIdiomaCliente;
        public System.Windows.Forms.GroupBox groupBox1;
        public System.Windows.Forms.TextBox tb_contdocelect;
        public System.Windows.Forms.ListView lvReferencias;
        public System.Windows.Forms.ColumnHeader columnHeader17;
        public System.Windows.Forms.ColumnHeader columnHeader18;
        public System.Windows.Forms.Button button8;
        public System.Windows.Forms.Button button9;
        public System.Windows.Forms.TextBox tb_referencia;
        public System.Windows.Forms.Label label42;
        public System.Windows.Forms.ComboBox cbTiporeferencia;
        public System.Windows.Forms.Label label43;
        public System.Windows.Forms.Button button11;
        public System.Windows.Forms.Button button10;
        public System.Windows.Forms.Button button12;
        public System.Windows.Forms.Button button13;
        public System.Windows.Forms.ListView lvinteresados;
        public System.Windows.Forms.ColumnHeader columnHeader19;
        public System.Windows.Forms.ColumnHeader columnHeader20;
        public System.Windows.Forms.ColumnHeader columnHeader21;
        public System.Windows.Forms.ColumnHeader columnHeader22;
        public System.Windows.Forms.ColumnHeader columnHeader23;
        public System.Windows.Forms.ColumnHeader columnHeader24;
        public System.Windows.Forms.ColumnHeader columnHeader25;
        public System.Windows.Forms.Button button18;
        public System.Windows.Forms.Button button19;
        public System.Windows.Forms.CheckBox checkBox2;
        public System.Windows.Forms.TextBox textBox19;
        public System.Windows.Forms.ListView lvDocumentosmarcas;
        public System.Windows.Forms.ColumnHeader columnHeader35;
        public System.Windows.Forms.ColumnHeader columnHeader36;
        public System.Windows.Forms.ColumnHeader columnHeader37;
        public System.Windows.Forms.ColumnHeader columnHeader38;
        public System.Windows.Forms.ColumnHeader columnHeader39;
        public System.Windows.Forms.ColumnHeader columnHeader40;
        public System.Windows.Forms.ColumnHeader columnHeader41;
        public System.Windows.Forms.ColumnHeader columnHeader42;
        public System.Windows.Forms.ColumnHeader columnHeader43;
        public System.Windows.Forms.ColumnHeader columnHeader44;
        public System.Windows.Forms.ColumnHeader columnHeader45;
        public System.Windows.Forms.ColumnHeader columnHeader46;
        public System.Windows.Forms.ColumnHeader columnHeader47;
        public System.Windows.Forms.ColumnHeader columnHeader48;
        public System.Windows.Forms.ColumnHeader columnHeader49;
        public System.Windows.Forms.ColumnHeader columnHeader50;
        public System.Windows.Forms.ColumnHeader columnHeader51;
        public System.Windows.Forms.ColumnHeader columnHeader52;
        public System.Windows.Forms.Button button21;
        public System.Windows.Forms.ListView lvPlazos;
        public System.Windows.Forms.ColumnHeader columnHeader1;
        public System.Windows.Forms.ColumnHeader columnHeader2;
        public System.Windows.Forms.ColumnHeader columnHeader3;
        public System.Windows.Forms.ColumnHeader columnHeader4;
        public System.Windows.Forms.ColumnHeader columnHeader5;
        public System.Windows.Forms.ColumnHeader columnHeader6;
        public System.Windows.Forms.ColumnHeader columnHeader7;
        public System.Windows.Forms.ColumnHeader columnHeader8;
        public System.Windows.Forms.ColumnHeader columnHeader9;
        public System.Windows.Forms.ColumnHeader columnHeader10;
        public System.Windows.Forms.ColumnHeader columnHeader11;
        public System.Windows.Forms.ColumnHeader columnHeader12;
        public System.Windows.Forms.ColumnHeader columnHeader13;
        public System.Windows.Forms.ColumnHeader columnHeader14;
        public System.Windows.Forms.ColumnHeader columnHeader15;
        public System.Windows.Forms.ColumnHeader columnHeader16;
        public System.Windows.Forms.ListView listView8;
        public System.Windows.Forms.ColumnHeader columnHeader58;
        public System.Windows.Forms.ColumnHeader columnHeader59;
        public System.Windows.Forms.ColumnHeader columnHeader60;
        public System.Windows.Forms.ColumnHeader columnHeader61;
        public System.Windows.Forms.ColumnHeader columnHeader62;
        public System.Windows.Forms.ColumnHeader columnHeader63;
        public System.Windows.Forms.ColumnHeader columnHeader64;
        public System.Windows.Forms.ColumnHeader columnHeader65;
        public System.Windows.Forms.ColumnHeader columnHeader66;
        public System.Windows.Forms.ColumnHeader columnHeader67;
        public System.Windows.Forms.ListView listView9;
        public System.Windows.Forms.ColumnHeader columnHeader68;
        public System.Windows.Forms.ColumnHeader columnHeader69;
        public System.Windows.Forms.ColumnHeader columnHeader70;
        public System.Windows.Forms.ColumnHeader columnHeader71;
        public System.Windows.Forms.ColumnHeader columnHeader72;
        public System.Windows.Forms.ColumnHeader columnHeader73;
        public System.Windows.Forms.ColumnHeader columnHeader74;
        public System.Windows.Forms.GroupBox groupBox2;
        public System.Windows.Forms.Button button23;
        public System.Windows.Forms.Button button24;
        public System.Windows.Forms.Button button25;
        public System.Windows.Forms.TextBox textBox23;
        public System.Windows.Forms.Label label51;
        public System.Windows.Forms.CheckBox checkBox3;
        public System.Windows.Forms.TextBox textBox22;
        public System.Windows.Forms.Label label50;
        public System.Windows.Forms.RichTextBox richTextBox6;
        public System.Windows.Forms.Label label49;
        public System.Windows.Forms.TextBox textBox21;
        public System.Windows.Forms.Label label48;
        public System.Windows.Forms.ComboBox comboBox5;
        public System.Windows.Forms.Label label52;
        public System.Windows.Forms.ListView listView10;
        public System.Windows.Forms.ColumnHeader columnHeader75;
        public System.Windows.Forms.ColumnHeader columnHeader76;
        public System.Windows.Forms.ColumnHeader columnHeader77;
        public System.Windows.Forms.TextBox textBox26;
        public System.Windows.Forms.GroupBox groupBox3;
        public System.Windows.Forms.Button button26;
        public System.Windows.Forms.Button button27;
        public System.Windows.Forms.Button button28;
        public System.Windows.Forms.RichTextBox richTextBox7;
        public System.Windows.Forms.Label label54;
        public System.Windows.Forms.TextBox textBox25;
        public System.Windows.Forms.Label label53;
        public System.Windows.Forms.TextBox textBox24;
        public System.Windows.Forms.Label label55;
        public System.Windows.Forms.CheckBox checkBox4;
        public System.Windows.Forms.Button button31;
        public System.Windows.Forms.ComboBox cbCartas;
        public System.Windows.Forms.Label label68;
        public System.Windows.Forms.ComboBox cbOficiosEscritos;
        public System.Windows.Forms.Label label67;
        public System.Windows.Forms.CheckBox checkBox6;
        public System.Windows.Forms.Button button32;
        public System.Windows.Forms.ComboBox cbDocEscritos;
        public System.Windows.Forms.Label label70;
        public System.Windows.Forms.ComboBox cbOficiosparaescritos;
        public System.Windows.Forms.Label label69;
        public System.Windows.Forms.Button button33;
        public System.Windows.Forms.Label label71;
        public System.Windows.Forms.ComboBox CB_formatoscc;
        public System.Windows.Forms.Label label58;
        public System.Windows.Forms.Label label57;
        public System.Windows.Forms.Label lProductosdelcaso;
        public System.Windows.Forms.Label lDescrip;
        public System.Windows.Forms.Button button44;
        public System.Windows.Forms.Button button43;
        public System.Windows.Forms.Button button42;
        public System.Windows.Forms.Button button41;
        public System.Windows.Forms.TextBox tbEstatus_header;
        public System.Windows.Forms.Label label61;
        private System.Windows.Forms.ColumnHeader tipopersona;
        private System.Windows.Forms.Button button37;
        private System.Windows.Forms.Button button40;
        private System.Windows.Forms.DataGridView dgPlazos;
        public System.Windows.Forms.Button button46;
        public System.Windows.Forms.Button button45;
        public System.Windows.Forms.ListView lvdocumentosimpi;
        public System.Windows.Forms.ColumnHeader link;
        public System.Windows.Forms.ColumnHeader Tipo;
        public System.Windows.Forms.ColumnHeader Codgbarras;
        public System.Windows.Forms.ColumnHeader cFolio;
        public System.Windows.Forms.ColumnHeader cFechanotific;
        public System.Windows.Forms.ColumnHeader cVencimiento;
        private System.Windows.Forms.ColumnHeader cVencimiento2mese;
        private System.Windows.Forms.ColumnHeader cVencimiento3mese;
        public System.Windows.Forms.ColumnHeader cMes;
        public System.Windows.Forms.ColumnHeader cFechaimpi;
        public System.Windows.Forms.ColumnHeader cFechaescrito;
        public System.Windows.Forms.ColumnHeader cDocumento;
        public System.Windows.Forms.ColumnHeader cEstatus;
        public System.Windows.Forms.ColumnHeader cPlazofinal;
        public System.Windows.Forms.ColumnHeader cObservacion;
        public System.Windows.Forms.ColumnHeader cAvisocliente;
        public System.Windows.Forms.ColumnHeader cMotCancelacion;
        public System.Windows.Forms.ColumnHeader cUsuarioprorrogo;
        public System.Windows.Forms.ColumnHeader cFechafirma;
        public System.Windows.Forms.ColumnHeader cDocumentorelaciona;
        private System.Windows.Forms.ColumnHeader subtipodocumentoid;
        private System.Windows.Forms.DataGridView dGV_docimentos_IMPI;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.TextBox tbCasoNumero;
        private System.Windows.Forms.TextBox tbCasoid;
        private System.Windows.Forms.TextBox tbExpediente;
        private System.Windows.Forms.TextBox tbRegistro;
        private System.Windows.Forms.TextBox tbl_pais;
        private System.Windows.Forms.TextBox tblCliente;
        private System.Windows.Forms.TextBox tblTitular;
        private System.Windows.Forms.TextBox tblCorresponsal;
        private System.Windows.Forms.TextBox tblCotaccorresponsal;
        private System.Windows.Forms.TextBox tblContacto;
        private System.Windows.Forms.TextBox tblRefencia;
        private System.Windows.Forms.Button btModificaciones;
        public System.Windows.Forms.Label label59;
        public System.Windows.Forms.Label label60;
        public System.Windows.Forms.Label label62;
        public System.Windows.Forms.TextBox tbDSigpruebauso_plazos;
        public System.Windows.Forms.Label label63;
        public System.Windows.Forms.TextBox tbDFechavigencia_plazos;
        public System.Windows.Forms.Label label72;
        public System.Windows.Forms.TextBox tbDfecharecepcion_plazos;
        public System.Windows.Forms.Label label73;
        public System.Windows.Forms.Label label74;
        public System.Windows.Forms.RichTextBox rtbDDenominacion_general;
        private System.Windows.Forms.TabPage tabPage17;
        private System.Windows.Forms.DataGridView dgview_facturas;
        private System.Windows.Forms.DataGridViewTextBoxColumn fac_pdf;
        private System.Windows.Forms.DataGridViewTextBoxColumn facturano;
        private System.Windows.Forms.DataGridViewTextBoxColumn fecha_emision;
        private System.Windows.Forms.DataGridViewTextBoxColumn fecha_pago;
        private System.Windows.Forms.DataGridViewTextBoxColumn dias_sin_pagar;
        private System.Windows.Forms.DataGridViewTextBoxColumn status_pago;
        private System.Windows.Forms.DataGridViewTextBoxColumn foliofeps;
        private System.Windows.Forms.DataGridViewTextBoxColumn total_mer;
        private System.Windows.Forms.DataGridViewTextBoxColumn Numero_de_servicios;
        private System.Windows.Forms.DataGridViewTextBoxColumn Servicio_uno;
        private System.Windows.Forms.DataGridViewTextBoxColumn Servicio_dos;
        private System.Windows.Forms.DataGridViewTextBoxColumn Servicio_tres;
        private System.Windows.Forms.TextBox tblResponsable;
        public System.Windows.Forms.Button button14;
        public System.Windows.Forms.Label label88;
        public System.Windows.Forms.Label label89;
        public System.Windows.Forms.Label label79;
        public System.Windows.Forms.RichTextBox rtNumprio;
        public System.Windows.Forms.TextBox tbCvepais;
        public System.Windows.Forms.TextBox tbfechaprio;
        public System.Windows.Forms.TextBox tbNumeroprio;
        public System.Windows.Forms.Button button3;
        public System.Windows.Forms.Button button4;
        public System.Windows.Forms.ComboBox cbTiposolprio;
        public System.Windows.Forms.Label label46;
        public System.Windows.Forms.ComboBox cbNombrepais;
        public System.Windows.Forms.Label label45;
        public System.Windows.Forms.Label label44;
        public System.Windows.Forms.Label label5;
        public System.Windows.Forms.Button bEliminarprioridades;
        public System.Windows.Forms.ListView lvPrioridades;
        public System.Windows.Forms.ColumnHeader idPrioridad;
        public System.Windows.Forms.ColumnHeader numeroprioridad;
        public System.Windows.Forms.ColumnHeader fechaprioridad;
        public System.Windows.Forms.ColumnHeader clavepais;
        public System.Windows.Forms.ColumnHeader pais;
        public System.Windows.Forms.ColumnHeader Tipoprioridad;
        public System.Windows.Forms.TextBox tb_contdocelect_;
        public System.Windows.Forms.Button button6;
        public System.Windows.Forms.TextBox tb_filename;
        public System.Windows.Forms.TextBox tb_descripdocelec;
        public System.Windows.Forms.Button button15;
        public System.Windows.Forms.Label label66;
        public System.Windows.Forms.Label label65;
        public System.Windows.Forms.Label label64;
        public System.Windows.Forms.ComboBox cb_tipodocelect;
        private System.Windows.Forms.TextBox tbAvisoprueba;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.TextBox textBox3;
        public System.Windows.Forms.ComboBox cbIdiomacarta;
        public System.Windows.Forms.Label label104;
        public System.Windows.Forms.ComboBox cbidiomaescrito;
        public System.Windows.Forms.Label label103;
        private System.Windows.Forms.Button bAgregarplazo;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.DataGridViewTextBoxColumn plazoid;
        private System.Windows.Forms.DataGridViewTextBoxColumn plazosidetalle;
        private System.Windows.Forms.DataGridViewTextBoxColumn usuario_id_plazo_impi;
        private System.Windows.Forms.DataGridViewTextBoxColumn documentoid;
        private System.Windows.Forms.DataGridViewTextBoxColumn documentodescrip;
        private System.Windows.Forms.DataGridViewTextBoxColumn tipoplazoid;
        private System.Windows.Forms.DataGridViewTextBoxColumn tipoplazodescrip;
        private System.Windows.Forms.DataGridViewTextBoxColumn estatusplazouno;
        private System.Windows.Forms.DataGridViewTextBoxColumn fechaplazo;
        private System.Windows.Forms.DataGridViewTextBoxColumn fechavencimientoplazouno;
        private System.Windows.Forms.DataGridViewTextBoxColumn fechaprorrogaplazouno;
        private System.Windows.Forms.DataGridViewTextBoxColumn fechavencimiento4meses;
        private System.Windows.Forms.DataGridViewTextBoxColumn fechaatendioplazouno;
        private System.Windows.Forms.DataGridViewTextBoxColumn Usuarioid_atendio_plazo_impi;
        private System.Windows.Forms.DataGridViewTextBoxColumn sDoc_atendio;
        private System.Windows.Forms.DataGridViewTextBoxColumn motivocancelaciondesc;
        private System.Windows.Forms.DataGridViewTextBoxColumn fechacancelacionimpi;
        private System.Windows.Forms.DataGridViewTextBoxColumn usuariocancelo;
        private System.Windows.Forms.DataGridViewTextBoxColumn lnk;
        private System.Windows.Forms.DataGridViewTextBoxColumn tipo_documento;
        private System.Windows.Forms.DataGridViewTextBoxColumn cod_barras;
        private System.Windows.Forms.DataGridViewTextBoxColumn folio;
        private System.Windows.Forms.DataGridViewTextBoxColumn fecha_notificacion;
        private System.Windows.Forms.DataGridViewTextBoxColumn vencimiento;
        private System.Windows.Forms.DataGridViewTextBoxColumn vencimiento_3_meses;
        private System.Windows.Forms.DataGridViewTextBoxColumn vencimiento_4_meses;
        private System.Windows.Forms.DataGridViewTextBoxColumn mes_antiguedad_plazo;
        private System.Windows.Forms.DataGridViewTextBoxColumn Fecha_Impi;
        private System.Windows.Forms.DataGridViewTextBoxColumn escrito_doc;
        private System.Windows.Forms.DataGridViewTextBoxColumn documento;
        private System.Windows.Forms.DataGridViewTextBoxColumn estatus_documentos_impi;
        private System.Windows.Forms.DataGridViewTextBoxColumn plazo_final;
        private System.Windows.Forms.DataGridViewTextBoxColumn observacion_documento;
        private System.Windows.Forms.DataGridViewTextBoxColumn aviso_cliente_documento;
        private System.Windows.Forms.DataGridViewTextBoxColumn mot_cancelacion;
        private System.Windows.Forms.DataGridViewTextBoxColumn usr_prorrogo;
        private System.Windows.Forms.DataGridViewTextBoxColumn fecha_firma;
        private System.Windows.Forms.DataGridViewTextBoxColumn documento_relacion;
        private System.Windows.Forms.DataGridViewTextBoxColumn subtipodocumentoid_documento;
        private System.Windows.Forms.DataGridViewTextBoxColumn documentoidmarcas;
        public System.Windows.Forms.DataGridView dGVProductos;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.DataGridView dgVProductosheader;
        public System.Windows.Forms.Label label78;
        public System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label77;
        public System.Windows.Forms.ComboBox cbDTipomarca;
        private System.Windows.Forms.TextBox tbNumeroregistrointernacional;
        public System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label76;
        public System.Windows.Forms.Label label13;
        public System.Windows.Forms.Label label37;
        private System.Windows.Forms.TextBox tbFechaRegistrointernacional;
        public System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox tbEstatusfactura;
        private System.Windows.Forms.Label label6;
        public System.Windows.Forms.Label label1;
        public System.Windows.Forms.Label label2;
        public System.Windows.Forms.Label label34;
        public System.Windows.Forms.TextBox tbDSigpruebauso;
        public System.Windows.Forms.Label label12;
        public System.Windows.Forms.TextBox tbDFechacarta;
        public System.Windows.Forms.TextBox tbDFechavigencia;
        public System.Windows.Forms.Label label20;
        public System.Windows.Forms.Label label10;
        public System.Windows.Forms.Label label32;
        public System.Windows.Forms.ComboBox cbDIdioma;
        public System.Windows.Forms.Label label24;
        public System.Windows.Forms.Label label3;
        public System.Windows.Forms.TextBox tbDFechaconcesion;
        public System.Windows.Forms.Label label9;
        public System.Windows.Forms.TextBox tbclase;
        public System.Windows.Forms.Label label56;
        public System.Windows.Forms.TextBox tbDNumeroReg;
        public System.Windows.Forms.Label label8;
        public System.Windows.Forms.TextBox tbDExpediente;
        public System.Windows.Forms.Label label4;
        public System.Windows.Forms.TextBox tbDfecharecepcion;
        public System.Windows.Forms.Label label7;
        public System.Windows.Forms.TextBox tbDFechainiciouso;
        public System.Windows.Forms.CheckBox cbDNoseausado;
        public System.Windows.Forms.Label label11;
        private System.Windows.Forms.DataGridViewTextBoxColumn casproductoidheader;
        private System.Windows.Forms.DataGridViewTextBoxColumn claseheader;
        private System.Windows.Forms.DataGridViewTextBoxColumn descripcionheader;
        private System.Windows.Forms.TabPage tabPage8;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.DataGridView dgViewOposiciones;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.ComboBox tbDtipo;
        private System.Windows.Forms.DataGridViewTextBoxColumn casoproductoid;
        private System.Windows.Forms.DataGridViewTextBoxColumn clasedescript;
        private System.Windows.Forms.DataGridViewTextBoxColumn descripcionclase;
        private System.Windows.Forms.ComboBox tbSubtipo;
        public System.Windows.Forms.TextBox tbSubtipo1;
        private System.Windows.Forms.DataGridView dgDocumentoselectronicos;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.DataGridViewTextBoxColumn documentoelectronicoid;
        private System.Windows.Forms.DataGridViewTextBoxColumn fecha;
        private System.Windows.Forms.DataGridViewTextBoxColumn usuario;
        private System.Windows.Forms.DataGridViewTextBoxColumn tipo_doc;
        private System.Windows.Forms.DataGridViewTextBoxColumn Descripcion;
        private System.Windows.Forms.DataGridViewTextBoxColumn ruta;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.DataGridViewTextBoxColumn opoCasoid;
        private System.Windows.Forms.DataGridViewTextBoxColumn Feataca;
        private System.Windows.Forms.DataGridViewTextBoxColumn opocasonumero;
        private System.Windows.Forms.DataGridViewTextBoxColumn opomarcaimitadora;
        private System.Windows.Forms.DataGridViewTextBoxColumn opoclase;
        private System.Windows.Forms.DataGridViewTextBoxColumn oponombredelimitador;
        private System.Windows.Forms.DataGridViewTextBoxColumn opoExpedienteimitador;
        private System.Windows.Forms.DataGridViewTextBoxColumn opoFechapublicacion;
        private System.Windows.Forms.DataGridViewTextBoxColumn opofechapresentacion;
        private System.Windows.Forms.DataGridViewTextBoxColumn opoFechaInterponemosEscrito;
        private System.Windows.Forms.ComboBox Ley;
        public System.Windows.Forms.Button btnGenerarcesion;
        public System.Windows.Forms.ComboBox cbCesiones;
        public System.Windows.Forms.Label label80;
        public System.Windows.Forms.Button btnGenerarpoder;
        public System.Windows.Forms.ComboBox cbPoder;
        public System.Windows.Forms.Label label81;
        public System.Windows.Forms.ComboBox cbIdiomadoc;
        public System.Windows.Forms.Label label82;
    }
}